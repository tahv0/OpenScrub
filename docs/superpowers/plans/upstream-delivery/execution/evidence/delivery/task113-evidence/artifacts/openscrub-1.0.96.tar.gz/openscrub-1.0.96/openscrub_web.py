#!/usr/bin/env python3
"""
openscrub_web.py — browser interface for openscrub, usable across your LAN.

Run on an always-on machine:
    python openscrub_web.py                  # port 8384, prints access URL
    python openscrub_web.py --port 9000 --token mysecret

Then from any device on the LAN (laptop, phone), open the printed URL.
Workflow: upload a recording (or give a server-side path) -> scan runs on
the server (live preview + log) -> review every detection with thumbnails,
uncheck false positives, draw missed regions -> render -> download.

Security model: HTTPS by default (self-signed cert generated on first
run, or install your own). Pass --token <secret> to require an access
token on every request (carried in a cookie after the first visit);
without it the server runs open and trusts everyone on the network.
Either way this is *LAN-grade* protection for a trusted home/office
network — do not expose this port to the internet. Uploaded videos and
audit reports contain PII; the jobs folder inherits that sensitivity.

Jobs are processed one at a time (FIFO) so concurrent requests don't fight
over the GPU.
"""

import argparse
import json
import math
import os
import queue
import secrets
import sys
import socket
import threading
import time
import uuid

import cv2
from flask import (Flask, Response, abort, jsonify, redirect, request,
                   send_file)

import openscrub
import zones_ui


# Anchor to the script's own folder, NOT the process working directory —
# double-clicking a .py on Windows can launch with cwd=C:\Windows\system32
# Computed ONCE at import: the vault's atexit lock hook runs during
# interpreter teardown, where module globals like __file__ may already be
# gone (a real NameError silently skipped the shutdown lock and left job
# files in plaintext). A captured constant survives teardown.
_HERE = os.path.dirname(os.path.abspath(__file__))


def _data_root():
    """Writable data root. From a normal checkout/deploy: the script's own
    folder (unchanged behavior). When pip-installed (module lives inside
    site-packages) or frozen into an exe (PyInstaller under Program Files),
    use a per-user data dir instead — PII jobs and TLS keys must never be
    written into the install tree."""
    here = _HERE
    if ("site-packages" in here or "dist-packages" in here
            or getattr(sys, "frozen", False)):
        # Confine the env-derived root to the user's own profile before any
        # filesystem use: a hostile LOCALAPPDATA can't point PII job/key
        # writes at a system directory. The guard's exact shape (single
        # startswith, value adopted in its true branch) matches the engine's
        # user_data_dir — the one form CodeQL's barrier analysis recognizes.
        home = os.path.realpath(os.path.expanduser("~"))
        base = os.path.join(home, ".local", "share")
        env = os.environ.get("LOCALAPPDATA")
        if env:
            cand = os.path.realpath(env)
            if cand.startswith(home.rstrip(os.sep) + os.sep):
                base = cand
        root = os.path.join(base, "OpenScrub")
        os.makedirs(root, exist_ok=True)
        return root
    return here


JOBS_DIR = os.path.join(_data_root(), "openscrub_jobs")
# One-time migration from the pre-rebrand job store: carries over all prior
# jobs, reviews, and the learned-words allowlist.
_legacy_jobs = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            "phi_blur_jobs")
if os.path.isdir(_legacy_jobs) and not os.path.isdir(JOBS_DIR):
    try:
        os.rename(_legacy_jobs, JOBS_DIR)
    except OSError:
        pass  # e.g. cross-device or perms: fall back to fresh dir
ZONES_PATH = os.path.join(_data_root(), "zones.json")
# which optional detection model is in use per kind: {"face": id, "plate": id}
# (missing/empty = the built-in default: YuNet for faces, auto for plates)
MODEL_SELECT_PATH = os.path.join(_data_root(), "model_select.json")


def load_model_select():
    try:
        with open(MODEL_SELECT_PATH, encoding="utf-8") as f:
            d = json.load(f)
            return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def save_model_select(d):
    with open(MODEL_SELECT_PATH, "w", encoding="utf-8") as f:
        json.dump(d, f, indent=1)


def find_model_file(fname):
    """models/<fname> can live next to the code (folder deploys) or in the
    per-user data dir (pip / frozen installs download there)."""
    roots = [os.path.dirname(os.path.abspath(openscrub.__file__))]
    if openscrub.install_is_readonly():
        roots.append(openscrub.user_data_dir())
    for r in roots:
        p = os.path.join(r, "models", fname)
        if os.path.exists(p):
            return p
    return None
# One-time migration: zones.json used to live next to the code, which for
# pip installs meant site-packages (lost on upgrade) and for frozen installs
# would be read-only. Carry an existing file over to the data root.
_legacy_zones = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                             "zones.json")
if (_legacy_zones != ZONES_PATH and os.path.exists(_legacy_zones)
        and not os.path.exists(ZONES_PATH)):
    try:
        import shutil as _sh
        _sh.copy2(_legacy_zones, ZONES_PATH)
    except OSError:
        pass
CERT_DIR = os.path.join(_data_root(), "certs")
CUSTOM_CERT = os.path.join(CERT_DIR, "custom_cert.pem")
CUSTOM_KEY = os.path.join(CERT_DIR, "custom_key.pem")
AUTO_CERT = os.path.join(CERT_DIR, "auto_cert.pem")
AUTO_KEY = os.path.join(CERT_DIR, "auto_key.pem")


def ensure_self_signed():
    """Generate a long-lived self-signed certificate once, with SANs for
    localhost and this machine's LAN IP so browsers tie it to the URL used."""
    if os.path.exists(AUTO_CERT) and os.path.exists(AUTO_KEY):
        return
    from cryptography import x509
    from cryptography.x509.oid import NameOID
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    import datetime, ipaddress
    os.makedirs(CERT_DIR, exist_ok=True)
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "openscrub")])
    sans = [x509.DNSName("localhost"),
            x509.IPAddress(ipaddress.ip_address("127.0.0.1"))]
    try:
        sans.append(x509.IPAddress(ipaddress.ip_address(lan_ip())))
    except Exception:
        pass
    now = datetime.datetime.now(datetime.timezone.utc)
    cert = (x509.CertificateBuilder()
            .subject_name(name).issuer_name(name)
            .public_key(key.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(now - datetime.timedelta(days=1))
            .not_valid_after(now + datetime.timedelta(days=3650))
            .add_extension(x509.SubjectAlternativeName(sans), critical=False)
            .sign(key, hashes.SHA256()))
    with open(AUTO_KEY, "wb") as f:
        f.write(key.private_bytes(
            serialization.Encoding.PEM,
            serialization.PrivateFormat.TraditionalOpenSSL,
            serialization.NoEncryption()))
    with open(AUTO_CERT, "wb") as f:
        f.write(cert.public_bytes(serialization.Encoding.PEM))
    try:
        os.chmod(AUTO_KEY, 0o600)
    except Exception:
        pass


def active_cert_pair():
    if os.path.exists(CUSTOM_CERT) and os.path.exists(CUSTOM_KEY):
        return CUSTOM_CERT, CUSTOM_KEY, "custom"
    ensure_self_signed()
    return AUTO_CERT, AUTO_KEY, "self-signed"
app = Flask(__name__)


def _max_upload_bytes(cli_value=None):
    """Upload cap in bytes, or None for unlimited. Priority:
    --max-upload-gb > $OPENSCRUB_MAX_UPLOAD_GB > 8 GB default.
    0 (either source) = unlimited. A real 18 GB plate-removal job hit the
    hard-coded cap as a bare '413 Request Entity Too Large' with no path
    forward — the limit is now a dial, and the 413 explains the dial."""
    raw = cli_value if cli_value is not None else \
        os.environ.get("OPENSCRUB_MAX_UPLOAD_GB", "")
    try:
        gb = float(raw)
    except (TypeError, ValueError):
        gb = 8.0
    if gb == 0:
        return None                      # explicit 0 = unlimited
    if gb < 0:
        gb = 8.0
    return int(gb * 1024 ** 3)


app.config["MAX_CONTENT_LENGTH"] = _max_upload_bytes()   # default 8 GB


@app.errorhandler(413)
def _too_large(e):
    cap = app.config.get("MAX_CONTENT_LENGTH")
    gb = cap / 1024 ** 3 if cap else 0
    return jsonify({"error":
        "upload exceeds this server's %.0f GB limit. Raise it with "
        "--max-upload-gb N (or OPENSCRUB_MAX_UPLOAD_GB=N in Docker, "
        "0 = unlimited) and restart — or better for very large files: "
        "put the file where the server can read it (Docker: a mounted "
        "folder) and use the 'path on the server' box instead of "
        "uploading through the browser." % gb}), 413


def _disk_free(path):
    """Free bytes on the filesystem holding `path` (own def: tests stub it,
    and every caller shares one failure mode)."""
    import shutil as _sh
    return _sh.disk_usage(path).free


def _upload_disk_error(content_length):
    """None, or a refusal message for an upload of `content_length` bytes
    that cannot fit on disk. Uploads are spooled through the system temp
    dir by the form parser and then copied into the job dir, so BOTH
    filesystems need room — double on a shared one — plus 1 GB headroom.
    Issue #16: each retry of a failed 18 GB job re-uploaded the file into
    a fresh job dir until the disk silently filled. Unmeasurable free
    space never blocks (same rule as the scan-copy verifier: the guard
    acts only on a measured certainty)."""
    cl = int(content_length or 0)
    if cl <= 0:
        return None
    margin = 1 << 30
    import tempfile
    tmp = tempfile.gettempdir()
    try:
        same = os.stat(JOBS_DIR).st_dev == os.stat(tmp).st_dev
    except OSError:
        same = True                       # can't tell -> assume shared
    try:
        if same:
            short = _disk_free(JOBS_DIR) < 2 * cl + margin
        else:
            short = (_disk_free(JOBS_DIR) < cl + margin
                     or _disk_free(tmp) < cl + margin)
    except OSError:
        return None
    if not short:
        return None
    try:
        free_gb = _disk_free(JOBS_DIR) / 1024 ** 3
    except OSError:
        free_gb = 0.0
    return ("not enough disk space on the server for this upload "
            "(%.1f GB upload, %.1f GB free where jobs are stored — an "
            "upload needs room for a temporary copy too). Delete old "
            "jobs (each keeps its upload and output until deleted), or "
            "use the 'path on the server' box, which reads the file in "
            "place without copying it." % (cl / 1024 ** 3, free_gb))


TOKEN = None
JOBS = {}          # id -> job dict
JOBS_LOCK = threading.Lock()
WORK_Q = queue.Queue()


# ----------------------------------------------------------------------------
# Job model
# ----------------------------------------------------------------------------

MEDIA_EXTS = {".mp4", ".mov", ".mkv", ".avi", ".webm", ".m4v", ".mpg",
              ".mpeg", ".wmv", ".ts", ".mts", ".m2ts", ".flv", ".3gp"}


def server_path_error(p):
    """Validate a user-supplied server-side media path. The path picker is a
    deliberate feature (process a file already on this machine/NAS), but the
    value is request data, so it is confined BEFORE any filesystem use:
    canonicalized, restricted to a known video extension, and — when
    $OPENSCRUB_MEDIA_ROOT is set — required to live inside that directory
    tree. Returns an error string, or None if the path is acceptable."""
    # canonicalize first, then apply the containment guard up front so the
    # confinement precedes EVERY filesystem access (path-injection barrier).
    # The guard is unconditional: with $OPENSCRUB_MEDIA_ROOT set, the path
    # must live inside that tree (real confinement — set it in any deployment
    # where the browser UI shouldn't reach the whole disk). Without it, the
    # picker is deliberately unrestricted (process any video already on this
    # machine/NAS is the feature), so the allowed prefix degrades to the
    # path's own filesystem root — the canonicalize+check still runs on
    # every request path rather than only on the configured branch.
    # NOTE the guard is a SINGLE startswith with an early return — the one
    # shape CodeQL's path-injection barrier analysis recognizes; compound
    # conditions defeat its dominance check. (The media root itself is
    # correctly rejected: a directory is never a valid video file.)
    p = os.path.realpath(p)
    root = os.environ.get("OPENSCRUB_MEDIA_ROOT")
    r = os.path.realpath(root) if root else os.path.realpath(
        os.path.splitdrive(p)[0] + os.sep)
    if not p.startswith(r.rstrip(os.sep) + os.sep):
        return "server path is outside OPENSCRUB_MEDIA_ROOT"
    if os.path.splitext(p)[1].lower() not in MEDIA_EXTS:
        return ("server path must be a video file ("
                + ", ".join(sorted(MEDIA_EXTS)) + ")")
    if not os.path.isfile(p):
        return "server path not found or not a file"
    return None


OPTIONS_FILE = "options.json"


def new_job(video_path, options, name):
    jid = uuid.uuid4().hex[:12]
    jdir = os.path.join(JOBS_DIR, jid)
    os.makedirs(jdir, exist_ok=True)
    job = {
        "id": jid, "dir": jdir, "video": video_path, "name": name,
        "options": options, "phase": "queued", "progress": 0.0,
        "eta": None, "size": 0,
        "log": [], "error": None, "output": None, "created": time.time(),
        "cancel": threading.Event(), "stats": {}, "qgen": 0,
    }
    # keep the job's settings beside its upload: a scan that never finished
    # has no report to recover them from, and a Retry after a restart then
    # ran with DEFAULT settings (all categories) instead of the user's own
    try:
        with open(os.path.join(jdir, OPTIONS_FILE), "w",
                  encoding="utf-8") as f:
            json.dump(options, f)
    except (OSError, TypeError, ValueError):
        pass
    with JOBS_LOCK:
        JOBS[jid] = job
    return job


def job_public(job):
    return {k: job[k] for k in ("id", "name", "phase", "progress", "error",
                                "stats")} | {
        "eta": job.get("eta"),      # .get(): jobs rehydrated from disk lack it
        # input size: lets the editor warn before re-uploading a file that
        # is ALREADY on the server (issue #16 — each retry re-uploaded the
        # same 18 GB until the disk filled)
        "size": job.get("size") or 0,
        "log_tail": job["log"][-30:],
        "log_len": len(job["log"]),
        "has_output": bool(job["output"] and os.path.exists(job["output"])),
    }


class WebCallbacks(openscrub.Callbacks):
    wants_frames = True

    def __init__(self, job):
        self.job = job
        self._last_frame = 0.0
        self._stage = None          # ETA state: current stage,
        self._t0 = 0.0              # when it started,
        self._cur0 = 0             # its first cur value,
        self._eta = None            # and the smoothed estimate

    def log(self, msg):
        self.job["log"].append(msg)

    def progress(self, stage, cur, total):
        # scan frame loop -> first 45% of the bar; "post" (dense-track
        # smoothing after the loop — previously a silent stall) -> 45-50%;
        # render -> back half. Jobs without a post stage jump 45 -> 50,
        # which reads as instant rather than stuck.
        # Rounded to 5 decimals, not 3: on a long slow scan 3-decimal
        # quantization froze the bar for 30s+ stretches, and the old
        # client-side ETA (extrapolated from bar movement) blanked out.
        base, span = {"scan": (0, 0.45),
                      "post": (0.45, 0.05)}.get(stage, (0.5, 0.5))
        self.job["progress"] = round(base + span * cur / max(total, 1), 5)

        # Server-side per-STAGE ETA from the stage's whole-run average
        # rate (units/sec since the stage began). Each stage runs at its
        # own real speed — extrapolating one ETA across the stitched bar
        # (what the client used to do) made the estimate lurch at every
        # phase boundary. The whole-stage average is stable by
        # construction, and a light EMA on the published value keeps
        # re-estimates gliding instead of stepping when the scan hits a
        # fast-skip jump or a dense stretch.
        now = time.time()
        if stage != self._stage:
            self._stage, self._t0, self._cur0 = stage, now, cur
            self._eta = None
            self.job["eta"] = None
            return
        done, elapsed = cur - self._cur0, now - self._t0
        if cur < total and done > 0 and elapsed >= 3.0:
            rem = (total - cur) * elapsed / done
            self._eta = (rem if self._eta is None
                         else 0.75 * self._eta + 0.25 * rem)
            self.job["eta"] = round(self._eta)
        else:
            self._eta = None
            self.job["eta"] = None

    def scan_frame(self, frame, t, found):
        now = time.time()
        if now - self._last_frame < 0.4:   # throttle disk writes
            return
        self._last_frame = now
        h, w = frame.shape[:2]
        scale = 720 / w
        small = cv2.resize(frame, (720, int(h * scale)))
        cv2.imwrite(os.path.join(self.job["dir"], "preview.jpg"), small,
                    [cv2.IMWRITE_JPEG_QUALITY, 70])

    def cancelled(self):
        return self.job["cancel"].is_set()


def build_args(job, for_render=False):
    o = job["options"]
    jdir = job["dir"]
    argv = [job["video"],
            "--engine", o.get("engine", "auto"),
            "--device", o.get("device", "auto"),
            "--encoder", o.get("encoder", "auto"),
            "--mode", o.get("mode", "blur"),
            "--coverage", o.get("coverage", "tight"),
            "--mode-map", o.get("mode_map", ""),
            "--sample-interval", str(o.get("sample_interval", 0.5)),
            "--scan-trigger", str(o.get("scan_trigger", 60)),
            "--pad", str(o.get("pad", 8)),
            "--bridge-gap", str(o.get("bridge_gap", 4.0)),
            "--face-expand", str(o.get("face_expand", 0.15)),
            "--face-threshold", str(o.get("face_threshold", 0.6)),
            "--plate-threshold", _plate_threshold(o.get("plate_threshold")),
            "--detect-scale", str(o.get("detect_scale", 1.0)),
            "--skip-start", str(o.get("skip_start", 0)),
            "--skip-end", str(o.get("skip_end", 0)),
            "--clip-frac", o.get("clip_frac", "") or "",
            "--detect-windows-frac", o.get("detect_windows_frac", "") or "",
            "--mute-audio-tracks", o.get("mute_tracks", "") or "",
            *(["--audio-lane-count", str(int(o["audio_lanes"]))]
              if isinstance(o.get("audio_lanes"), int)
              and not isinstance(o.get("audio_lanes"), bool)
              and 0 < o["audio_lanes"] < 64 else []),
            "--hdr-output", (o.get("hdr_output")
                             if o.get("hdr_output") in ("match", "sdr")
                             else "match"),
            "--codec", (o.get("codec")
                        if o.get("codec") in ("h264", "hevc") else "h264"),
            "--out-quality", (o.get("out_quality")
                              if o.get("out_quality") in
                              ("archival", "balanced", "share")
                              else "archival"),
            "--face-shape", (o.get("face_shape")
                             if o.get("face_shape") in ("ellipse", "rect")
                             else "ellipse"),
            "--scan-speed", (o.get("scan_speed")
                             if o.get("scan_speed") in openscrub.SCAN_SPEEDS
                             else "thorough"),
            "--categories", o.get("categories",
                                  "name,dob,phone,ssn,email,address,card,apikey,ipaddr,plate,face,person"),
            "-o", os.path.join(jdir, "output."
                               + (o.get("out_format", "mp4")
                                  if o.get("out_format") in ("mp4", "mov", "mkv")
                                  else "mp4")),
            "--report", os.path.join(jdir, "report.json")]
    # user-defined regex categories ride along on every job; the engine only
    # activates the ones whose id is in --categories
    for c in load_custom_cats():
        argv += ["--custom-regex", "%s=%s" % (c["id"], c["regex"])]
    # selected detection models (Detection models panel). A selected id
    # whose file is missing falls back to the engine default silently-safe
    # ladder (YuNet / plate auto-search).
    sel = load_model_select()
    for kind, flag in (("face", "--face-model"), ("plate", "--plate-model"),
                       ("person", "--person-model")):
        mid = sel.get(kind)
        if mid:
            p = find_model_file("%s.onnx" % mid)
            if p:
                argv += [flag, p]
    if o.get("no_memory"):
        argv.append("--no-memory")
    if o.get("no_ner"):
        argv.append("--no-ner")
    if o.get("preview_mode"):
        argv.append("--preview")
    if o.get("dense_faces"):
        argv.append("--dense-faces")
    if o.get("face_heads"):
        argv.append("--face-heads")
    if o.get("audio_pii"):
        argv.append("--audio-pii")
    if o.get("draw_scores"):
        argv.append("--draw-scores")
    # unified Scan Setup jobs: stacked detection windows (fractions of
    # duration, resolved server-side by the engine) with per-window
    # categories + zones travel as a windows.json inside the job dir
    if o.get("windows"):
        wpath = os.path.join(jdir, "windows.json")
        with open(wpath, "w", encoding="utf-8") as f:
            json.dump({"windows": o["windows"],
                       "ignore": o.get("ignore_zones") or []}, f)
        argv += ["--windows", wpath]
    if o.get("use_zones", True) and os.path.exists(ZONES_PATH):
        try:
            with open(ZONES_PATH, encoding="utf-8") as f:
                if json.load(f):
                    argv += ["--zones", ZONES_PATH]
        except Exception:
            pass
    # "specific text" terms travel as a file in the job dir (never on the
    # command line, where process listings would show them)
    ptext = (o.get("phrases") or "")
    if isinstance(ptext, str) and ptext.strip():
        ppath = os.path.join(jdir, "phrases.txt")
        with open(ppath, "w", encoding="utf-8") as f:
            f.write(ptext.strip() + "\n")
        argv += ["--phrases", ppath]
    server_allow = os.path.join(JOBS_DIR, "allowlist.txt")
    for kind in ("allow_names", "extra_names"):
        text = (o.get(kind) or "").strip()
        if kind == "allow_names" and os.path.exists(server_allow):
            text = (text + "\n" + open(server_allow, encoding="utf-8").read()).strip()
        if text:
            p = os.path.join(jdir, kind + ".txt")
            with open(p, "w", encoding="utf-8") as f:
                f.write(text)
            argv += ["--" + kind.replace("_", "-"), p]
    # ignore zones (drawn in the zone editor) apply to every job,
    # independent of the "apply detection zones" checkbox
    try:
        if os.path.exists(ZONES_PATH):
            with open(ZONES_PATH, encoding="utf-8") as f:
                for r in (json.load(f).get("ignore") or []):
                    argv += ["--ignore-region", "%s,%s,%s,%s" % tuple(r)]
    except Exception:
        pass
    if for_render:
        argv += ["--from-report", os.path.join(jdir, "report.json")]
    parser = openscrub.build_parser()
    argv = _sanitize_argv(parser, argv, job)

    # argparse's error()/exit() call sys.exit — a SystemExit that, raised in
    # the job worker THREAD, killed that thread without a traceback: the job
    # sat at "scanning" with an empty log forever, Cancel did nothing, and
    # every later job queued behind it (a real iPhone job: Safari submitted
    # engine="" and `--engine ''` is an invalid choice). Inside the server a
    # bad setting must fail THE JOB, loudly — never the process's only worker.
    def _no_exit(message=None, *a, **k):
        raise ValueError("invalid job settings — %s" % (message or "rejected"))
    parser.error = _no_exit
    parser.exit = lambda status=0, message=None: _no_exit(message)
    return openscrub._prep_args(parser.parse_args(argv), parser)


def _plate_threshold(v):
    """Editor's plate confidence cutoff, clamped to 0.05-0.95: above that
    the detector finds (almost) nothing — a silent fail-OPEN — and below
    it everything is a plate. Unset/garbage -> the engine default."""
    try:
        f = float(v)
    except (TypeError, ValueError):
        return "0.35"
    if not math.isfinite(f):
        return "0.35"
    return str(min(0.95, max(0.05, f)))


def _sanitize_argv(parser, argv, job=None):
    """Repair option VALUES the browser sent that the engine's parser would
    reject: a choice outside its list (iOS Safari can report a <select> with
    no selection as value ""), or a number that isn't one / isn't finite
    ("None", "", "NaN" from an empty input). Each falls back to the engine's
    own default — the same thing the CLI uses when the flag is omitted —
    with a NOTE in the job log, so one odd form value can't sink a scan.
    The choice lists and defaults come from the parser itself, so this can
    never drift from the engine. Detection SCOPE is not repaired here:
    categories/windows are free-form and are validated by the engine."""
    out = list(argv)
    i = 0
    while i < len(out) - 1:
        a = parser._option_string_actions.get(out[i])
        if a is None or a.nargs is not None:     # positional / flag / list
            i += 1
            continue
        v = out[i + 1]
        bad = bool(a.choices) and v not in a.choices
        if not bad and a.type in (int, float):
            try:
                bad = not math.isfinite(a.type(v))
            except (TypeError, ValueError):
                bad = True
        if not bad:
            i += 2
            continue
        if a.default is None:          # no engine default: omit the flag
            del out[i:i + 2]
            msg = "omitted"
        else:
            out[i + 1] = str(a.default)
            msg = "using the default %r" % (a.default,)
            i += 2
        if job is not None and isinstance(job.get("log"), list):
            job["log"].append("NOTE: setting %s=%r is not valid — %s"
                              % (a.option_strings[0], v, msg))
    return out


# The single job worker. WORKER["current"] is the job it is running right
# now (read by Cancel and the watchdog); WORKER["thread"] is the live thread.
WORKER = {"current": None, "thread": None}
_ACTIVE_PHASES = ("queued", "scanning", "rendering", "queued_render")


def enqueue(job, action):
    """Queue a job action. Each enqueue bumps the job's generation, and the
    worker skips any queue entry whose generation is stale — so cancelling
    a queued job (which bumps it too) really removes it from the line, and
    a Retry after a Cancel can't run the scan twice."""
    with JOBS_LOCK:
        job["qgen"] = job.get("qgen", 0) + 1
        gen = job["qgen"]
    WORK_Q.put((job["id"], action, gen))


def worker():
    """Run queued jobs forever. NOTHING may end this loop: it is the
    server's only worker, and when it died (a SystemExit from argparse —
    which a thread swallows silently) the job froze at "scanning" with an
    empty log, Cancel was ignored and every later job queued forever until
    the container was restarted. Every per-job failure, BaseException
    included, now fails that job loudly and the loop carries on."""
    while True:
        try:
            item = WORK_Q.get()
        except BaseException:          # pragma: no cover — queue can't fail
            time.sleep(1)
            continue
        if item is None:               # explicit stop (tests); the watchdog
            WORK_Q.task_done()         # starts a fresh worker in production
            return
        try:
            jid, action = item[0], item[1]
            gen = item[2] if len(item) > 2 else None
            with JOBS_LOCK:
                job = JOBS.get(jid)
                stale = (job is None
                         or (gen is not None and gen != job.get("qgen", 0))
                         or job.get("phase") == "cancelled")
                if not stale:
                    WORKER["current"] = jid
            if not stale:
                _run_job(job, action)
        except BaseException as e:     # belt and braces: never die
            print(f"[web] worker: unexpected {type(e).__name__}: {e}",
                  flush=True)
        finally:
            WORKER["current"] = None
            WORK_Q.task_done()


def _run_job(job, action):
    jid = job["id"]
    cb = WebCallbacks(job)
    try:
        if action == "scan":
            job["phase"] = "scanning"
            job["log"].append("— scan started —")
            args = build_args(job)
            state = openscrub.run_scan(args, cb)
            openscrub.write_report(os.path.join(job["dir"], "report.json"),
                                  args, state)
            job["stats"] = state["stats"]
            def _pregen(jid=jid):
                """One pass through the video with a single decoder:
                thumbnails come out in seconds instead of minutes.
                Sorting by reference time keeps seeks short and forward-
                only, which is what codecs are fast at."""
                try:
                    jb = JOBS.get(jid)
                    doc = _load_job_report(jb)
                    rs = doc["render_state"]
                    todo = []
                    for k, d in enumerate(doc["detections"]):
                        cch = os.path.join(jb["dir"], f"thumb2_{k}.jpg")
                        if os.path.exists(cch):
                            continue
                        tref = min(max(d.get("last_seen", d["t_start"]),
                                       d["t_start"]), d["t_end"])
                        todo.append((tref, k, d, cch))
                    todo.sort()
                    cap = cv2.VideoCapture(jb["video"])
                    cur = -1
                    frame = None
                    for tref, k, d, cch in todo:
                        fidx = min(int(tref * rs["fps"]),
                                   len(rs["cum"]) - 1)
                        if fidx != cur:
                            if 0 <= fidx - cur <= 12:
                                while cur < fidx:   # cheap forward decode
                                    ok, frame = cap.read()
                                    if not ok:
                                        frame = None
                                        break
                                    cur += 1
                            else:
                                cap.set(cv2.CAP_PROP_POS_FRAMES, fidx)
                                ok, frame = cap.read()
                                cur = fidx if ok else cur
                                if not ok:
                                    frame = None
                        if frame is None:
                            continue
                        ox, oy = rs["cum"][fidx]
                        h, wd = frame.shape[:2]
                        pad = 24
                        x1 = max(0, int(d["cbox"][0] + ox) - pad)
                        y1 = max(0, int(d["cbox"][1] + oy) - pad)
                        x2 = min(wd, int(d["cbox"][2] + ox) + pad)
                        y2 = min(h, int(d["cbox"][3] + oy) + pad)
                        crop = frame[y1:y2, x1:x2].copy()
                        if crop.size == 0:
                            continue
                        inner = crop[pad:-pad or None, pad:-pad or None]
                        if not inner.size or float(inner.std()) <= 8:
                            continue   # blank: leave for the on-demand
                                       # path, which tries other moments
                        cv2.rectangle(crop, (pad, pad),
                                      (crop.shape[1] - pad,
                                       crop.shape[0] - pad),
                                      (0, 0, 255), 2)
                        cv2.imwrite(cch, crop,
                                    [cv2.IMWRITE_JPEG_QUALITY, 80])
                    cap.release()
                    jb["log"].append("thumbnails pre-generated "
                                     f"({len(todo)})")
                except Exception:
                    pass
            threading.Thread(target=_pregen, daemon=True).start()
            try:
                prov = _load_job_report(job).get("provenance", {})
                if (prov.get("vfr_normalized")
                        and os.path.exists(prov.get("input", ""))):
                    job["video"] = prov["input"]
                    job["log"].append(
                        "using CFR-normalized file for previews/thumbnails")
            except Exception:
                pass
            if job["options"].get("skip_review"):
                job["log"].append("review skipped — rendering all detections")
                job["phase"] = "queued_render"
                enqueue(job, "render")
            else:
                job["phase"] = "review"
            job["progress"] = 0.5
            job["eta"] = None
        elif action == "render":
            job["phase"] = "rendering"
            args = build_args(job, for_render=True)
            res = openscrub.run_pipeline(args, cb)
            job["output"] = res["output"]
            # refresh report with output hash
            dets, rstate, prov = openscrub.load_report(
                os.path.join(job["dir"], "report.json"))
            job["phase"] = "done"
            job["progress"] = 1.0
            job["eta"] = None
    except openscrub.PipelineCancelled:
        job["phase"] = "cancelled"
        job["error"] = "cancelled by user"
    except BaseException as e:
        # BaseException, not Exception: a SystemExit (argparse) or any other
        # non-Exception escaping here used to kill the worker thread silently
        msg = str(e) or type(e).__name__
        if isinstance(e, SystemExit):
            msg = "the job stopped unexpectedly (exit %s)" % (e.code,)
        job["phase"] = "error"
        job["error"] = msg
        job["log"].append(f"ERROR: {msg}")
    finally:
        job["eta"] = None       # a dead/paused job must not show "~N left"


def start_worker():
    t = threading.Thread(target=worker, daemon=True, name="job-worker")
    WORKER["thread"] = t
    t.start()
    return t


def check_worker():
    """Watchdog step: if the worker thread is gone, fail the job it was
    running (it can never finish now) and start a fresh worker so the
    queue keeps moving. Returns True when it had to restart one."""
    t = WORKER.get("thread")
    if t is not None and t.is_alive():
        return False
    jid = WORKER.get("current")
    with JOBS_LOCK:
        job = JOBS.get(jid) if jid else None
        if job is not None and job.get("phase") in _ACTIVE_PHASES:
            job["phase"] = "error"
            job["eta"] = None
            job["error"] = ("the job worker stopped unexpectedly — the "
                            "server restarted it; Retry re-runs the scan "
                            "with the file already on the server")
            job["log"].append("ERROR: " + job["error"])
    WORKER["current"] = None
    if t is not None:
        print("[web] job worker was not running — restarted it", flush=True)
    start_worker()
    return True


def _worker_watchdog():
    while True:
        time.sleep(5)
        try:
            check_worker()
        except Exception as e:
            print(f"[web] worker watchdog: {e}", flush=True)


# ----------------------------------------------------------------------------
# Auth
# ----------------------------------------------------------------------------

@app.before_request
def check_token():
    if TOKEN is None:          # open mode: anyone on the network is trusted
        return
    tok = (request.args.get("token") or request.cookies.get("phiblur_token")
           or request.headers.get("X-Token"))
    if tok != TOKEN:
        abort(401, "missing or wrong access token — open the URL printed "
                   "at server startup (includes ?token=...)")


@app.before_request
def _touch_activity():
    LAST_ACTIVITY["t"] = time.time()


@app.before_request
def enforce_vault_lock():
    """While the vault is locked, every job operation is refused — the
    files are ciphertext, so this fails closed rather than half-working."""
    if request.path.startswith("/api/jobs") and vault_locked():
        abort(423, "vault is locked — unlock it (Encryption panel) to "
                   "access jobs")


@app.before_request
def refuse_upload_without_disk_room():
    """Registered after auth on purpose, but still BEFORE the view runs:
    by the time create_job touches request.files, werkzeug has already
    spooled the whole upload into the temp dir — too late to protect the
    disk. Checking the Content-Length header here reads nothing."""
    if request.method == "POST" and request.path == "/api/jobs":
        err = _upload_disk_error(request.content_length)
        if err:
            return jsonify({"error": err}), 507


@app.after_request
def set_cookie(resp):
    if TOKEN is not None and request.args.get("token") == TOKEN:
        resp.set_cookie("phiblur_token", TOKEN, max_age=90 * 86400,
                        samesite="Lax")
    # the UI is a single served page whose JS/CSS is inlined: without this,
    # browsers (iOS Safari especially) keep showing a STALE cached copy
    # after the server is updated — new panels/fixes invisibly missing (a
    # user's waveform fix ran only in Private mode because the normal tab
    # served old cached JS). `no-cache` still lets Safari store and serve
    # the page; `no-store` forbids storing it at all, so the app is never
    # stale. Images (thumbnails, frames) keep their own caching.
    if resp.mimetype == "text/html":
        resp.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
        resp.headers["Pragma"] = "no-cache"          # HTTP/1.0 caches
        resp.headers["Expires"] = "0"
    elif resp.mimetype == "application/json":
        resp.headers["Cache-Control"] = "no-store"
    return resp


# ----------------------------------------------------------------------------
# API
# ----------------------------------------------------------------------------

@app.route("/api/jobs", methods=["POST"])
def create_job():
    options = json.loads(request.form.get("options", "{}"))
    jobs = []
    files = request.files.getlist("video")
    if files and files[0].filename:
        for f in files:
            name = os.path.basename(f.filename.replace("\\", "/"))
            # extension comes from the client: keep it only if it's a plain
            # known media suffix, never splice arbitrary text into the path
            ext = os.path.splitext(name)[1].lower()
            if ext not in MEDIA_EXTS:
                ext = ".mp4"
            job = new_job("", options, name)
            path = os.path.join(job["dir"], "input" + ext)
            f.save(path)
            job["video"] = path
            try:
                job["size"] = os.path.getsize(path)
            except OSError:
                pass
            enqueue(job, "scan")
            jobs.append(job["id"])
    elif request.form.get("server_path"):
        p = os.path.realpath(request.form["server_path"].strip())
        err = server_path_error(p)
        if err:
            return jsonify({"error": err}), 400
        # Containment guard REPEATED inline before the getsize() sink below:
        # server_path_error already enforces it, but CodeQL's path-injection
        # barrier analysis is function-local — without this single-startswith
        # shape in THIS function the alert opens (code-scanning #21, the
        # v1.0.83 duplicate-upload size lookup). Same as server_video.
        root = os.environ.get("OPENSCRUB_MEDIA_ROOT")
        r = os.path.realpath(root) if root else os.path.realpath(
            os.path.splitdrive(p)[0] + os.sep)
        if not p.startswith(r.rstrip(os.sep) + os.sep):
            return jsonify({"error": "server path is outside "
                                     "OPENSCRUB_MEDIA_ROOT"}), 400
        job = new_job(p, options, os.path.basename(p))
        try:
            job["size"] = os.path.getsize(p)
        except OSError:
            pass
        enqueue(job, "scan")
        jobs.append(job["id"])
    else:
        return jsonify({"error": "no file uploaded and no server path"}), 400
    return jsonify({"jobs": jobs})


@app.route("/api/jobs")
def list_jobs():
    with JOBS_LOCK:
        js = sorted(JOBS.values(), key=lambda j: -j["created"])
    return jsonify([job_public(j) for j in js])


DELETE_MARKER = ".delete_pending"


def _reap_job_dir(jdir, jid="?", retries=2, delay=0.8):
    """rmtree with retries. A just-closed review session can still hold a
    streaming handle on the video for a moment (and holds a LOCK on it on
    Windows), so the first attempt can fail transiently — a real user's
    delete failed exactly this way."""
    import shutil as _sh
    err = None
    for i in range(retries):
        try:
            _sh.rmtree(jdir)
            return True
        except OSError as e:
            err = e
            time.sleep(delay)
    # log the detail server-side only: OSError text contains filesystem
    # paths, which don't belong in an HTTP response body
    print(f"[web] job {jid} delete incomplete: {err}", flush=True)
    return False


@app.route("/api/jobs/<jid>", methods=["DELETE"])
def job_delete(jid):
    """Delete a job and every file it owns (upload, normalized video,
    report, thumbnails, output). Running jobs must be cancelled first.
    Deletion is GUARANTEED, not merely attempted: if a file is still
    held open (Windows locks, a streaming handle, a busy network share),
    a marker is written and background retries + the startup and
    retention sweeps finish the removal — the old behavior popped the
    job from the list FIRST and then failed, leaving an orphaned folder
    the UI could no longer reach, which rose from the dead as a zombie
    review job at the next restart."""
    with JOBS_LOCK:
        job = JOBS.get(jid)
        if job is None:
            abort(404)
        if job.get("phase") in ("queued", "scanning", "rendering",
                                "queued_render"):
            abort(409, "job is queued or running — cancel it first")
    if _reap_job_dir(job["dir"], jid):
        with JOBS_LOCK:
            JOBS.pop(jid, None)
        return jsonify({"ok": True})
    # couldn't remove everything now: mark the dir so every future sweep
    # (background retries below, startup, retention) knows it is condemned,
    # take it out of the UI, and keep trying quietly
    try:
        with open(os.path.join(job["dir"], DELETE_MARKER), "w") as f:
            f.write(str(time.time()))
    except OSError:
        pass
    with JOBS_LOCK:
        JOBS.pop(jid, None)

    def _retry():
        for _ in range(10):
            time.sleep(30)
            if not os.path.isdir(job["dir"]):
                return
            if _reap_job_dir(job["dir"], jid, retries=1):
                print(f"[web] job {jid} delete completed on retry",
                      flush=True)
                return
    threading.Thread(target=_retry, daemon=True).start()
    return jsonify({"ok": True, "pending": True,
                    "note": "some files were still in use; removal will "
                            "complete automatically"})


@app.route("/api/jobs/<jid>/retry", methods=["POST"])
def job_retry(jid):
    """Re-run a failed or cancelled job's SCAN, reusing the file that is
    already on the server. Before this existed, the only path after an
    error was Start scan — which uploaded the same multi-GB file into a
    fresh job dir on every attempt until the disk filled (issue #16)."""
    with JOBS_LOCK:
        job = JOBS.get(jid)
        if job is None:
            abort(404)
        if job["phase"] not in ("error", "cancelled"):
            return jsonify({"error": "only a failed or cancelled job can "
                                     "be retried"}), 409
        if not (job.get("video") and os.path.exists(job["video"])):
            return jsonify({"error": "the job's video file is no longer "
                                     "on the server — start a new "
                                     "scan"}), 410
        job["cancel"].clear()
        job["error"] = None
        job["output"] = None
        job["progress"] = 0.0
        job["eta"] = None
        job["phase"] = "queued"
        job["log"].append("— retrying scan (reusing the file already on "
                          "the server — nothing is re-uploaded) —")
    enqueue(job, "scan")
    return jsonify({"ok": True})


@app.route("/api/jobs/<jid>")
def job_status(jid):
    job = JOBS.get(jid) or abort(404)
    return jsonify(job_public(job))


@app.route("/api/jobs/<jid>/log")
def job_log(jid):
    job = JOBS.get(jid) or abort(404)
    frm = max(0, int(request.args.get("from", 0)))
    return jsonify({"from": frm, "lines": job["log"][frm:],
                    "len": len(job["log"])})


@app.route("/api/jobs/<jid>/preview.jpg")
def job_preview(jid):
    job = JOBS.get(jid) or abort(404)
    p = os.path.join(job["dir"], "preview.jpg")
    if not os.path.exists(p):
        abort(404)
    return send_file(p, mimetype="image/jpeg", max_age=0)


@app.route("/api/jobs/<jid>/cancel", methods=["POST"])
def job_cancel(jid):
    """Cancel a job. The job the worker is RUNNING stops cooperatively at
    its next checkpoint. Any other active job (still queued, or orphaned by
    a worker that died) is cancelled on the spot — before, Cancel only set
    a flag the worker checks mid-scan, so a job the worker never picked up
    could never be cancelled (or deleted: delete refuses active jobs)."""
    job = JOBS.get(jid) or abort(404)
    job["cancel"].set()
    with JOBS_LOCK:
        if (WORKER.get("current") != jid
                and job.get("phase") in _ACTIVE_PHASES):
            job["qgen"] = job.get("qgen", 0) + 1   # void its queue entry
            job["phase"] = "cancelled"
            job["error"] = "cancelled by user"
            job["eta"] = None
            job["log"].append("— cancelled —")
    return jsonify({"ok": True})


def _load_job_report(job):
    with open(os.path.join(job["dir"], "report.json"), encoding="utf-8") as f:
        return json.load(f)


def _frame_at(job, t, rstate):
    cap = cv2.VideoCapture(job["video"])
    fps = rstate["fps"]
    cap.set(cv2.CAP_PROP_POS_FRAMES, int(t * fps))
    ok, frame = cap.read()
    cap.release()
    return frame if ok else None


@app.route("/api/jobs/<jid>/mediainfo")
def job_mediainfo(jid):
    """Basic video properties straight from the file — available in every
    job phase, no scan report required."""
    job = JOBS.get(jid) or abort(404)
    cap = cv2.VideoCapture(job["video"])
    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    n = cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0
    w_ = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    h_ = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    cap.release()
    return jsonify({"duration": n / fps if fps else 0, "fps": fps,
                    "width": w_, "height": h_})


@app.route("/api/jobs/<jid>/detections")
def job_detections(jid):
    job = JOBS.get(jid) or abort(404)
    doc = _load_job_report(job)
    items = []
    for i, d in enumerate(doc["detections"]):
        items.append({"i": i, "category": d["category"], "text": d["text"],
                      "t_start": d["t_start"], "t_end": round(d["t_end"], 2),
                      "enabled": d.get("enabled", True),
                      "track": d.get("track", -1),
                      "person": d.get("person", -1),
                      "confidence": d.get("confidence", 0),
                      "zone_dropped": bool(d.get("zone_dropped"))})
    return jsonify({"detections": items,
                    "fps": doc["render_state"]["fps"],
                    "duration": len(doc["render_state"]["cum"]) /
                                doc["render_state"]["fps"]})


@app.route("/api/jobs/<jid>/detframe/<int:i>")
def job_detframe(jid, i):
    """Full video frame at a real sighting of detection i, with its box
    outlined — the review lightbox."""
    job = JOBS.get(jid) or abort(404)
    doc = _load_job_report(job)
    d = doc["detections"][i]
    rs = doc["render_state"]
    tref = min(max(d.get("last_seen", d["t_start"]), d["t_start"]), d["t_end"])
    fidx = min(int(tref * rs["fps"]), len(rs["cum"]) - 1)
    ox, oy = rs["cum"][fidx]
    frame = _frame_at(job, tref, rs)
    if frame is None:
        abort(404)
    x1, y1 = int(d["cbox"][0] + ox), int(d["cbox"][1] + oy)
    x2, y2 = int(d["cbox"][2] + ox), int(d["cbox"][3] + oy)
    cv2.rectangle(frame, (x1 - 4, y1 - 4), (x2 + 4, y2 + 4), (0, 0, 255), 3)
    ok, buf = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, 84])
    from flask import Response
    return Response(buf.tobytes(), mimetype="image/jpeg")


@app.route("/api/jobs/<jid>/boxes_at")
def job_boxes_at(jid):
    """Active blur boxes (screen coords) at time t, plus the scroll offset so
    the client can convert edited boxes back to content coordinates."""
    job = JOBS.get(jid) or abort(404)
    doc = _load_job_report(job)
    rs = doc["render_state"]
    t = float(request.args.get("t", 0))
    fidx = min(int(t * rs["fps"]), len(rs["cum"]) - 1)
    ox, oy = rs["cum"][fidx]
    boxes = []
    want_all = request.args.get("all") == "1"
    for i, d in enumerate(doc["detections"]):
        if not (d["t_start"] - 0.01 <= t <= d["t_end"] + 0.01):
            continue
        if not want_all and not d.get("enabled", True):
            continue
        if True:
            boxes.append({"i": i, "category": d["category"],
                          "enabled": d.get("enabled", True),
                          "text": d.get("text", ""),
                          "t_start": d["t_start"], "t_end": d["t_end"],
                          "box": [d["cbox"][0] + ox, d["cbox"][1] + oy,
                                  d["cbox"][2] + ox, d["cbox"][3] + oy]})
    return jsonify({"t": t, "ox": ox, "oy": oy, "boxes": boxes})


@app.route("/api/jobs/<jid>/thumb/<int:i>")
def job_thumb(jid, i):
    job = JOBS.get(jid) or abort(404)
    # i is already a Flask <int:> route var, but CodeQL doesn't trust the
    # converter — format it as an explicit non-negative integer so the
    # cache filename can never carry anything but digits.
    i = int(i)
    if i < 0:
        abort(404)
    cache = os.path.join(job["dir"], "thumb2_%d.jpg" % i)
    if not os.path.exists(cache):
        doc = _load_job_report(job)
        if i >= len(doc["detections"]):
            abort(404)
        d = doc["detections"][i]
        rs = doc["render_state"]
        # cut the thumbnail at a moment the detector actually SAW the object.
        # t_start can be earlier than the object's appearance (backtracking
        # deliberately moves it to just before onset) — a frame there shows
        # nothing and made review pictures mismatch their text.
        ls = min(max(d.get("last_seen", d["t_start"]), d["t_start"]),
                 d["t_end"])
        mid = (d["t_start"] + d["t_end"]) / 2
        crop = None
        pad = 24
        for tref in (ls, mid, min(d["t_start"] + 0.2, d["t_end"])):
            fidx = min(int(tref * rs["fps"]), len(rs["cum"]) - 1)
            ox, oy = rs["cum"][fidx]
            frame = _frame_at(job, tref, rs)
            if frame is None:
                continue
            h, w = frame.shape[:2]
            x1 = max(0, int(d["cbox"][0] + ox) - pad)
            y1 = max(0, int(d["cbox"][1] + oy) - pad)
            x2 = min(w, int(d["cbox"][2] + ox) + pad)
            y2 = min(h, int(d["cbox"][3] + oy) + pad)
            c = frame[y1:y2, x1:x2]
            if c.size == 0:
                continue
            crop = c
            inner = c[pad:-pad or None, pad:-pad or None]
            if inner.size and float(inner.std()) > 8:
                break   # crop shows real content — use this moment
        if crop is None:
            abort(404)
        cv2.rectangle(crop, (pad, pad), (crop.shape[1] - pad,
                                         crop.shape[0] - pad), (0, 0, 255), 2)
        cv2.imwrite(cache, crop, [cv2.IMWRITE_JPEG_QUALITY, 80])
    return send_file(cache, mimetype="image/jpeg", max_age=3600)


@app.route("/api/jobs/<jid>/frame_at")
def job_frame_at(jid):
    job = JOBS.get(jid) or abort(404)
    t = max(0.0, float(request.args.get("t", 0)))
    path = (job["output"] if request.args.get("src") == "output"
            and job.get("output") else job["video"])
    cap = cv2.VideoCapture(path)
    # seek by TIMESTAMP, not frame index: the original upload is often VFR
    # (iPhone), where index = t*fps drifts out of sync with the CFR output
    # and can overshoot the file entirely (broken compare pane)
    frame = None
    for tt in (t, max(0.0, t - 0.34), max(0.0, t - 1.0), 0.0):
        cap.set(cv2.CAP_PROP_POS_MSEC, tt * 1000)
        ok, fr = cap.read()
        if ok:
            frame = fr
            break   # walk back instead of 404ing at the very end of the file
        if tt == 0.0:
            break
    cap.release()
    if frame is None:
        abort(404)
    ok, buf = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, 82])
    return Response(buf.tobytes(), mimetype="image/jpeg")


@app.route("/api/jobs/<jid>/video")
def job_video_stream(jid):
    """Range-aware stream of the job's scan video so review can PLAY the
    footage with live boxes (issue #17: the box editor was scrub-only,
    'you cannot play review and see hits'). Serves the same file frame_at
    reads — for HDR/VFR jobs that is the normalized SDR scan copy, which
    every browser can decode."""
    job = JOBS.get(jid) or abort(404)
    if not (job.get("video") and os.path.exists(job["video"])):
        abort(404)
    return send_file(job["video"], conditional=True)


@app.route("/api/jobs/<jid>/detections", methods=["POST"])
def job_save_edits(jid):
    job = JOBS.get(jid) or abort(404)
    edits = request.get_json(force=True)
    path = os.path.join(job["dir"], "report.json")
    doc = _load_job_report(job)
    enabled = edits.get("enabled", {})
    for i, d in enumerate(doc["detections"]):
        if str(i) in enabled:
            d["enabled"] = bool(enabled[str(i)])
    for i, box in (edits.get("box_overrides") or {}).items():
        i = int(i)
        if 0 <= i < len(doc["detections"]) and len(box) == 4:
            doc["detections"][i]["cbox"] = [float(v) for v in box]
    for i, span in (edits.get("time_overrides") or {}).items():
        i = int(i)
        if 0 <= i < len(doc["detections"]) and len(span) == 2:
            t0, t1 = float(span[0]), float(span[1])
            if t1 > t0 >= 0:
                doc["detections"][i]["t_start"] = t0
                doc["detections"][i]["t_end"] = t1
                doc["detections"][i]["last_seen"] = min(
                    max(doc["detections"][i].get("last_seen", t0), t0), t1)
    rs = doc["render_state"]
    for m in edits.get("manual", []):
        t0 = float(m["t_start"]); t1 = float(m["t_end"])
        tref = float(m.get("t_ref", t0))
        fidx = min(int(tref * rs["fps"]), len(rs["cum"]) - 1)
        ox, oy = rs["cum"][fidx]
        b = m["screen_box"]
        doc["detections"].append({
            "t_start": t0, "t_end": t1,
            "cbox": [int(b[0] - ox), int(b[1] - oy),
                     int(b[2] - ox), int(b[3] - oy)],
            "category": "manual", "text": "user-drawn", "confidence": 1.0,
            "aoff": [ox, oy], "last_seen": t0, "enabled": True})
    if "audio" in edits:
        # audio redaction spans (mute/bleep): stored in the report so the
        # --from-report render applies them and re-renders keep them
        doc["audio_redactions"] = [
            {"t0": float(s["t0"]), "t1": float(s["t1"]),
             "mode": (s.get("mode") if s.get("mode") in ("mute", "bleep")
                      else "mute")}
            for s in (edits.get("audio") or [])
            if float(s.get("t1", 0)) > float(s.get("t0", 0)) >= 0]
    with open(path, "w", encoding="utf-8") as f:
        json.dump(doc, f, indent=1)
    # suggest allowlisting any string whose EVERY instance was disabled —
    # the review just taught us it's a recurring false positive
    per = {}
    for d in doc["detections"]:
        if d["category"] in ("name",):
            per.setdefault(d["text"], []).append(d.get("enabled", True))
    suggest = sorted(t for t, states in per.items()
                     if len(states) >= 2 and not any(states))
    return jsonify({"ok": True, "total": len(doc["detections"]),
                    "suggest_allowlist": suggest})


@app.route("/api/jobs/<jid>/track_object", methods=["POST"])
def job_track_object(jid):
    """Targeted redaction: the user circled an object on one frame and
    picked a time window on the review timeline — template-track it through
    that window and add the result as a dense track in the report, so the
    review shows one card (with fan-out) and the render blurs it wherever
    it went. Runs in a background thread; poll /track_status."""
    job = JOBS.get(jid) or abort(404)
    if job.get("trackbg", {}).get("state") == "running":
        return jsonify({"error": "tracking already in progress"}), 409
    p = request.get_json(force=True)
    try:
        box = [float(v) for v in p["box"]]
        t_ref, t0, t1 = (float(p["t_ref"]), float(p["t0"]), float(p["t1"]))
    except (KeyError, TypeError, ValueError):
        abort(400)
    if len(box) != 4 or not (t1 > t0 >= 0) or not (t0 <= t_ref <= t1):
        abort(400)
    st = {"state": "running", "added": 0, "error": None}
    job["trackbg"] = st

    def _run():
        try:
            class L(openscrub.Callbacks):
                def log(self, m):
                    job["log"].append(m)
            det = None
            try:
                # same person-model resolution the scan uses: the panel
                # selection first, then the engine's default ladder
                mid = load_model_select().get("person")
                p = find_model_file("%s.onnx" % mid) if mid else None
                det = openscrub.PersonDetector(L(), model_path=p,
                                               thresh=0.2)
                if det.net is None and det.ort is None:
                    det = None
            except Exception:
                det = None
            samples = openscrub.track_manual_region(
                job["video"], box, t_ref, t0, t1, cb=L(), person_det=det)
            if not samples:
                st.update(state="done", added=0,
                          error="could not track that region — try a "
                                "larger box or a frame where it's clearer")
                return
            doc = _load_job_report(job)
            rs = doc["render_state"]
            fps = float(rs["fps"]) or 30.0
            step = 2.0 / fps
            tid = max([d.get("track", -1) for d in doc["detections"]]
                      + [-1]) + 1
            new = []
            tcls = samples[0][4] if len(samples[0]) > 4 else None
            label = ("tracked %s" % openscrub.COCO_NAMES[tcls]
                     if tcls is not None
                     and 0 <= tcls < len(openscrub.COCO_NAMES)
                     else "tracked object")
            for s in samples:
                t, b, score = s[0], s[1], s[2]
                poly = s[3] if len(s) > 3 and s[3] else ()
                fidx = min(int(t * fps), len(rs["cum"]) - 1)
                ox, oy = rs["cum"][fidx]
                new.append({
                    "t_start": t, "t_end": t + step * 1.2,
                    "cbox": [int(b[0] - ox), int(b[1] - oy),
                             int(b[2] - ox), int(b[3] - oy)],
                    "category": "manual", "text": label,
                    "confidence": round(float(score), 3),
                    "aoff": [ox, oy], "last_seen": t,
                    "dense": True, "track": tid, "enabled": True,
                    "poly": [[[float(x), float(y)] for x, y in c]
                             for c in poly]})
            # grace pads: cover the sub-sample sliver at both ends
            new[0]["t_start"] = max(0.0, new[0]["t_start"] - 0.25)
            new[-1]["t_end"] += 0.25
            doc["detections"].extend(new)
            path = os.path.join(job["dir"], "report.json")
            with open(path, "w", encoding="utf-8") as f:
                json.dump(doc, f, indent=1)
            job["log"].append(
                "      tracked object: %d position(s), %.1f-%.1fs "
                "(review card added)" % (len(new),
                                         new[0]["t_start"], new[-1]["t_end"]))
            st.update(state="done", added=len(new))
        except Exception as e:
            st.update(state="done", added=0, error=str(e))

    threading.Thread(target=_run, daemon=True).start()
    return jsonify({"ok": True})


@app.route("/api/jobs/<jid>/track_status")
def job_track_status(jid):
    job = JOBS.get(jid) or abort(404)
    return jsonify(job.get("trackbg") or {"state": "idle"})


def _models_state(kind):
    """Registry entries + installed/selected/active state for one kind."""
    models = openscrub.load_model_registry(kind)
    sel = load_model_select().get(kind, "")
    out = []
    for m in models:
        out.append({
            "id": m.get("id"), "label": m.get("label"),
            "license": m.get("license"), "source_url": m.get("source_url"),
            "notes": m.get("notes"), "recommended": bool(m.get("recommended")),
            "verified": m.get("download_url") not in (None, "", "TODO_VERIFY"),
            "pinned": bool(m.get("sha256")) and m.get("sha256") != "TODO_VERIFY",
            "installed": bool(find_model_file("%s.onnx" % m.get("id"))),
            "attribution": m.get("attribution", ""),
        })
    if kind == "face":
        p = find_model_file("%s.onnx" % sel) if sel else None
        active = os.path.basename(p) if p else "built-in YuNet"
        status = ("Active: " + active) if p else \
            "Active: built-in YuNet (works out of the box — models below are optional upgrades)"
    else:
        # plate and person share the same model-required pattern: INERT
        # (loudly) until a model is installed or provided
        env = ("OPENSCRUB_PERSON_MODEL" if kind == "person"
               else "OPENSCRUB_PLATE_MODEL")
        base = ("person_yolov8.onnx" if kind == "person"
                else "plate_yolov8.onnx")
        what = ("person (full-body blur)" if kind == "person"
                else "plate")
        active = os.environ.get(env)
        if not (active and os.path.exists(active)):
            active = ((find_model_file("%s.onnx" % sel) if sel else None)
                      or find_model_file(base))
        if not active:
            for m in models:
                p = find_model_file("%s.onnx" % m.get("id"))
                if p:
                    active = p
                    break
        status = ("Active model: " + os.path.basename(active)) if active else \
            ("No model installed — %s detection is INACTIVE until you "
             "install or provide one." % what)
    return {"models": out, "selected": sel, "status": status,
            "active": bool(active) if kind != "face" else True}


@app.route("/api/models/<kind>")
def models_list(kind):
    if kind not in ("face", "plate", "person"):
        abort(404)
    return jsonify(_models_state(kind))


@app.route("/api/models/<kind>/select", methods=["POST"])
def models_select(kind):
    if kind not in ("face", "plate", "person"):
        abort(404)
    mid = (request.get_json(force=True) or {}).get("id", "")
    if mid and not any(m.get("id") == mid
                       for m in openscrub.load_model_registry(kind)):
        return jsonify({"error": "unknown model id"}), 404
    sel = load_model_select()
    sel[kind] = mid
    save_model_select(sel)
    return jsonify({"ok": True, "selected": mid})


@app.route("/api/model_status")
def model_status():
    """Whether the model-requiring detectors would find a model RIGHT NOW
    (the same resolution ladder the engine runs — selected file first,
    then conventional/registry/cache locations). Powers the editor's
    'this category will detect nothing' warnings (issue #18). screen
    rides the person model. plate_autofetch says whether a missing plate
    model would self-heal at scan start (recommended registry entry is
    permissively licensed and hash-pinned)."""
    sel = load_model_select()
    out = {}
    for kind, cls in (("plate", openscrub.PlateDetector),
                      ("person", openscrub.PersonDetector)):
        mp = None
        mid = sel.get(kind)
        if mid:
            mp = find_model_file("%s.onnx" % mid)
        try:
            out[kind] = bool(cls.resolve_model(mp)[0])
        except Exception:
            out[kind] = True        # can't tell -> don't cry wolf
    try:
        rec = next((m for m in openscrub.load_model_registry("plate")
                    if m.get("recommended")), None)
        out["plate_autofetch"] = bool(
            rec and (rec.get("sha256") or "").strip()
            and str(rec.get("license", "")).lower().startswith(
                ("mit", "apache", "bsd")))
    except Exception:
        out["plate_autofetch"] = False
    return jsonify(out)


_model_dl = {"state": "idle", "pct": 0, "error": "", "id": "", "kind": ""}


@app.route("/api/models/<kind>/<mid>/download", methods=["POST"])
def model_download(kind, mid):
    """Download+verify a registry model in a background thread."""
    if kind not in ("face", "plate", "person"):
        abort(404)
    entry = next((m for m in openscrub.load_model_registry(kind)
                  if m.get("id") == mid), None)
    if entry is None:
        return jsonify({"error": "unknown model id"}), 404
    if _model_dl["state"] == "downloading":
        return jsonify({"error": "a download is already in progress"}), 409
    _model_dl.update(state="downloading", pct=0, error="", id=mid, kind=kind)
    def work():
        try:
            openscrub.download_model(
                entry, kind,
                progress=lambda f: _model_dl.update(pct=int(f * 100)))
            _model_dl.update(state="done", pct=100)
        except Exception as e:
            _model_dl.update(state="error", error=str(e))
    threading.Thread(target=work, daemon=True).start()
    return jsonify({"ok": True})


@app.route("/api/models/download_status")
def model_download_status():
    return jsonify(_model_dl)


# Detection-quality tiers: one click maps to per-kind registry selections
# (the "" face id = built-in YuNet). Applying a tier downloads any missing
# model first and only then selects it — a selection must never point at a
# file that is not on disk (fail closed). Manual picks in the models panel
# still work; when they stop matching a tier the UI shows "Custom".
QUALITY_TIERS = {
    "fast": {"face": "", "plate": "oim-yolov9-t-640",
             "person": "yolo11n-seg-person"},
    "balanced": {"face": "centerface", "plate": "oim-yolov9-t-640",
                 "person": "yolo11s-seg-person"},
    "accurate": {"face": "centerface", "plate": "oim-yolov9-s-608",
                 "person": "yolo11m-seg-person"},
}

_tier_apply = {"state": "idle", "tier": "", "step": "", "error": ""}


@app.route("/api/quality_tier", methods=["GET", "POST"])
def quality_tier():
    if request.method == "GET":
        sel = load_model_select()
        cur = next((tid for tid, t in QUALITY_TIERS.items()
                    if all(sel.get(k, "") == v for k, v in t.items())), "")
        needs = {tid: [k for k, v in t.items()
                       if v and not find_model_file("%s.onnx" % v)]
                 for tid, t in QUALITY_TIERS.items()}
        return jsonify({"tier": cur, "applying": _tier_apply, "needs": needs})
    tier = (request.get_json(force=True) or {}).get("tier", "")
    t = QUALITY_TIERS.get(tier)
    if t is None:
        return jsonify({"error": "unknown tier"}), 404
    if _model_dl["state"] == "downloading" or _tier_apply["state"] == "applying":
        return jsonify({"error": "a download is already in progress"}), 409
    _tier_apply.update(state="applying", tier=tier, step="", error="")

    def work():
        try:
            for kind, mid in t.items():
                if mid:
                    entry = next((m for m in
                                  openscrub.load_model_registry(kind)
                                  if m.get("id") == mid), None)
                    if entry is None:
                        raise RuntimeError(
                            "model registry is missing %s/%s" % (kind, mid))
                    if not find_model_file("%s.onnx" % mid):
                        _tier_apply["step"] = ("downloading %s"
                                               % entry.get("label", mid))
                        _model_dl.update(state="downloading", pct=0,
                                         error="", id=mid, kind=kind)
                        try:
                            openscrub.download_model(
                                entry, kind,
                                progress=lambda f:
                                    _model_dl.update(pct=int(f * 100)))
                            _model_dl.update(state="done", pct=100)
                        except Exception:
                            _model_dl.update(state="error")
                            raise
                sel = load_model_select()
                sel[kind] = mid
                save_model_select(sel)
            _tier_apply.update(state="done", step="")
        except Exception as e:
            _tier_apply.update(state="error", error=str(e), step="")
    threading.Thread(target=work, daemon=True).start()
    return jsonify({"ok": True})


# legacy aliases (pre-1.0.30 clients)
@app.route("/api/plate_models")
def plate_models():
    return jsonify(_models_state("plate"))


@app.route("/api/plate_models/<mid>/download", methods=["POST"])
def plate_model_download(mid):
    return model_download("plate", mid)


@app.route("/api/plate_models/download_status")
def plate_model_download_status():
    return jsonify(_model_dl)


@app.route("/api/allowlist", methods=["GET", "POST"])
def allowlist():
    path = os.path.join(JOBS_DIR, "allowlist.txt")
    if request.method == "POST":
        body = request.get_json(force=True)
        existing = []
        if os.path.exists(path):
            existing = [l.strip() for l in open(path, encoding="utf-8")
                        if l.strip()]
        for wd in body.get("words", []):
            wd = wd.strip()
            if wd and wd not in existing:
                existing.append(wd)
        removes = {r.strip() for r in body.get("remove", [])}
        if removes:
            existing = [wd for wd in existing if wd not in removes]
        if body.get("clear"):
            existing = []
        with open(path, "w", encoding="utf-8") as f:
            f.write("".join(wd + chr(10) for wd in existing))
        return jsonify({"ok": True, "count": len(existing)})
    words = []
    if os.path.exists(path):
        words = [l.strip() for l in open(path, encoding="utf-8") if l.strip()]
    return jsonify({"words": words, "path": path})


@app.route("/api/jobs/<jid>/render", methods=["POST"])
def job_render(jid):
    job = JOBS.get(jid) or abort(404)
    if job["phase"] in ("rendering", "queued_render"):
        return jsonify({"ok": True, "note": "render already in progress"})
    if job["phase"] not in ("review", "done", "error", "cancelled"):
        return jsonify({"error": f"cannot render from phase {job['phase']}"}), 400
    job["phase"] = "queued_render"
    job["cancel"].clear()
    job["error"] = None
    enqueue(job, "render")
    return jsonify({"ok": True})


@app.route("/api/jobs/<jid>/download")
def job_download(jid):
    job = JOBS.get(jid) or abort(404)
    if not job["output"] or not os.path.exists(job["output"]):
        abort(404)
    # download name must carry the REAL container extension: a .mkv render
    # saved as "_redacted.mp4" looks like the format choice was ignored
    ext = os.path.splitext(job["output"])[1] or ".mp4"
    return send_file(job["output"], as_attachment=True,
                     download_name=os.path.splitext(job["name"])[0]
                     + "_redacted" + ext)


@app.route("/api/jobs/<jid>/report")
def job_report(jid):
    job = JOBS.get(jid) or abort(404)
    return send_file(os.path.join(job["dir"], "report.json"),
                     as_attachment=True,
                     download_name=os.path.splitext(job["name"])[0]
                     + "_audit.json")


# ----------------------------------------------------------------------------
# UI
# ----------------------------------------------------------------------------

# ----------------------------------------------------------------------------
# The app page. PAGE is COMPOSED at import time: zones_ui.ZONES_PAGE is the
# shell (dark Scan Setup editor at the top), and the pieces below fill its
# %%MARKER%% slots — jobs list + job detail/review under the editor, the
# settings view behind the header gear, the footer, and the app JS (jobs/
# review/settings) as a second <script>. All intake happens in the editor.
# ----------------------------------------------------------------------------

FAVICON_URI = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAJd0lEQVR4nK2Xa4xd1XXHf/u87rnn3rn3zoxnPB6P52EMfoWxEXZ52MQQhzYIkQaLBNJCXbVKUyQq5UPzUJtKSaRIqVpFSZvKQHCTQGlIDaShUBLSQIlpDPiFa8A2Y4/f8547d+4997z33vkwNWYYaJw269ORztZaP/3/+6x1luDXCCEEWmsA8nnPwPJWCCEsZHg0aPrq3WcuKeelH5tLapomjldZ29HZ/eCm69ZfbwjB7j0HD05NjH5Kxo39cRxfoIVfA+SSIl+sdFQ6Bx7++J2f1C8//y9ajv4ilaN70r0vPql/7+57dHv3ZU94xUrXb6jcRXFcr5jzWrs/s/nG39aPP7pDZ+P7YjW6RzZP7dbB6Ze0Gt0jk7G98b/+4CG9Zestutja/ZdesZS/mOr9hX6PNxfldt28UKZ3c1/fwKP3/uFti7Zv+2BWKXsY2rAyLfCbIVmWkbMt8q6DYRlZI8j4zq6fWQ9870f1M2dO36NT/+kwCNTbIO+y5X3Rcl7lilJb5867br9582f+6Fb6lnUkJsLxg5Shk6c5c3aU+uwsWksKxTJdXR1sWL8asgyr4CVnzk4539z5FI/98Cf7Z6uT29Nw9g0p5a9WwPVKZcNu+dpNH9z4p1+47xNcu3F1RBg4KZbxwu6XOfzaaxgq47bfvQ2hJVEUsHzlWvbtP0R1psZHfucmRCZxbBRuPnl57xH3b+9/kud//up3srD252Fztvq+AF5L+/r+5SsOfv6+O7nr1usTyxKG78dWsVLhxd2v8uW/+gqf+OhWBtdfieXkWHnlesqtbdSqVWrj53n2uecZvOpqbrhpM83ZBlqmFDxHZcrIdj292/natx7jxPGhjUFjet+FmtaFB9steN3L+vY/+eBfqBWXd2dxPXIy5WA7LoZl88y//wfloseSnqX0rFqDZeWYnp5hujpLkiS0FCv09PXyxrEhbvjwFizTxHAcoiQ1dBY6d267Idk4eLn10T/+0t7hobichH59HkCaicGbNl1trFi5LAmmZx23WEIgUAh0JpmanqZcLnL8zCj//cWvIostpIt7CY7to/e3NjF5boKZ/Xs5IWzu/v078fIuWioc10RJm+bMrDNweXe05dp1zrEjRwaBl+YBoLWZcxyFNrBzLoYwQAgMBEmaUq01GD95CqelwspKiXVbNrN4oJ/8HTdTbm3FcWxGhk7w9999nKd//AJ3bb8DVfMRaIQhsJ0cQmnDtk1Dv6NVXgQANMJAGP/DA1prTNskihOGTo2wZqCXq1YNkOZcfnrgCMM/fIHJaoMkjunv7eaWrddy7333cOz1Izz31LNs3boFoTQ6VQghwLDmrt07PsV5ABfFmOsEGhCWxdf/7gG6Sia3VycY//4TfK+eMVEPMFBoDYmGkwcOcNnzz3K+4PJYeRmea/GfLx3gi5+7l5xpzdXUekF3XgggBAiBVAq3XOL+b+3kGzseYXHO5ZwV8ZNShSUVk64Wi46WHFEimQoSmknGTxF8XCbUTw3zZpbjzbdOs+2WG9lw3UZU0AQtQat5ndGYX9sABEoqcm6e4aNDfOXrD2Eoh+vKgmewiJMExzRZWvHoby8xsKjMkhaXnkqBlqLHjxLNjZctwhSSviXtLF8xgIoTDONCqfkSvLcFgHBshk+eZnRsioHuHtrbcxwOJ/jwyl76l3SQhAFSazQCU0BLaztNqTmQJBRsi3Wretm5469p61hE4jffVhbE3MheqICeuyBSobUm8ZusWz/I9m0f4uzoOZTjcV1/F31d7SzvWUKh4NHW1krXonY6W8tcMbCM1f1LWbO4TP+6QX78b49w5bq1RLM+QgiUlCA17x7Q8yzIshQcC9txQAg6Otv59oPf4MVnv8tzY7McGpvh/ESViZlZzkzMsPfNYQ4ePYESBo4psGXCvpEZllx7A209S2lO13BbPIRhzOW0TbJMopV6DwukJO/aVKdqPLrz2zi5PLd8bBsDa1cxOlln6twIqxcXeOXUOH6q8CzBWLVGlGZYts3x0yMMjU3RphQP/cMOBq9cxeA1V3P89WM8teufsWyL7X/yafI5G9TFofT2dbSc4qZbP/Khl9YtVUkyOewsXlThVFCgb80GjrzyHO065orXTvL9VFBoLbG8axGeY3Ls/CR+nCIAs9HkNtdk72WdLOnto+sD1zMydIge1+f42Ulae9ck+0+EzlPP/Gxzlvj/Nc8CJ++x/9VfMHHiMNVGxmQ1QDTHefzhf6SvDMo2qXp5rhGCo2M13pic4Y1xn/ONhJrWnJ5scI0QjNoWnR0l+iqCp3/wT3jxBEEQkySK4Oxh9r+yB8d1F1qgtcYQBjU/BUMj0MQSSkWPRr1JrExGNyzn4PAsmyoOm9Z28fJQlY5lLWxe28Wu3cMcbc3Tv8gBP2J0YhqtNI1GSF1JwjAiaMi53x2lFrZiAYZUSkVpNtcFtSJRgijKmAg9ZBzRpiRlnVB2cpwfmWF1p4tWivGxKco5gRVGGM2MWgwTTU2j0aTu5wjCmFRqVJYgpcyEYVgLAJDJW5F0jZlGoCothWymIa0MaIaS2XpAztJMNyQjkz4lR6ClS80PMYSBlzOp+RFCKQqWjZ8KJuopSaYYqzbRSmEYOpttBCpUeUfI5rEFAFFQH7ed3L1vTuV2dAc+XWUnktJ0olQato5JEhM/k4SxZMxXSB1ScEw0BlLaSKXRUpNJCIOQ2G/SCDRhIVGoNDlbjd2RwLMymX06DBrjCwCU1tRrk/cXipU9w2nh4YkgGmzLxxiGlYSJcqJMkWaKNJOoNCbLHKRlUA9jNJo0kRgC0kwSxJJUGWidJqNV3xkPTLeRFl/XMr676dcOvXMgzR/HWuM3Zg45tn0VXvljgcw94orQK+WaWT6XQ2msVEGWZTRCkEpRCxWhUSSIaqSZoORopJRZFEdUQ8MJlReh5R/EQfWJJE0V74r/dTPKu3nPybd8Fi2/1FWIWVwyk3NVZXWUbMOxTAquhR+l5CyYCTRaadXu6ezUdOJMJ3mUEl+OI/9voihsvl+NS1rNCoWWbmF738yb8R2GSri804mEYTmOZRhBIsnbgik/S6bqiSONHM3MflKl4Z8FzcbIr8p9ibshWKaB65U3mFbukbwRrOopayqek6RKM12PnPHAJtL5t3QW3x0Fs3szuUDt/x/AhbBt23TypdtNw3igksvahNDMxLavlf5UHMzuStJ04fbxmwS4EK7rFZThfECAZejkcBgG9f9Lnl8C4BC+9whcW2oAAAAASUVORK5CYII="

LOGO_URI = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAABgLUlEQVR4nO29dbxtR3n//56ZZVuOXnfJjZGQBAuS4FKkRYv1S3GK09LypaFBSwqFIkVKoUihUEqRAqUESlokJFiAhBC363Jctiwb+f0xa+2z7yWFGwhFft95ve49+5yzz9przTzzPJ/n88gI/n80hBCD1865n/nz/zd+S8bwAg8PpdRtev9v4/gtf9L68fyuHh8fl+MTq0aSZnvj5Op157Tb7Tv10/6ezuL8Zd3O0jWLC7Ozc7NzdvDXQvzWa4TfWgEYXrxVq1erDZu2n500x/48Lc2Di7xsamMwWgMQRxFhGBQjreTbUL7/8IHd/7Zvz5701q712zZ+6wRgeLGazSY7TzzlTnFz4q2dXn7/LO3jsARBYJWUWkglcc5a57DWRc45lFI042i3ID/v8IE9/zYzPaWPve5v0/itEYBjF+jEk0/d1B5d86pMu+fmRYESQgdBQJ715fLSouz3exhjCIKAZrPNyOiYDePYFnlmi6KIpFSMtJpfU6I8b/dN113W7XbdrX3Ob/r4LREAQW3nt23fMTK5dtOz+5l9Q57niRDYKI5t1u8FB/fvJpCOnTu2cuIJ2xkbG6Wz3OWmW/Zw0817yArN+o1baY2MWa0L7RBREiU0G8H7097iBddd/eN9g0/8LRGE32gBGF6EtWvXhWs2bn2oE/E70izf4awhiiKtdRkc2HszoTA8/amP55lPeyKnn3wC0egoyACcoVzucNV1N/PPn/w8H/7IJ1jspGzbeTJxo6nzPMMYG8RRZOOAly3MHnrvgf370uoGvOj9BgvCb6QADC98kiRs2b7r9LAx/s5+mt9f64IoCgulgmD68EHZW5rlkb/7YF59/h9z5l1OhSxDpzlaa3AOKQVBECKjCJKE3Tce4K/f9l4+9rFPIqM2GzZvx2J1kWWBkIpWI7kuDnn5of23XDg9NWWOvZ/ftPEbJQDDE62UYscJJ20Mk9GXFoaX5XmGkqIIwzhYnJ+Vs1MHOPded+Y1r/q/POgh9wGdky/MUXam0L0FnHUgBAiBDALC9mqC5hqiZhsabb7/3St43evfxIX/+TXGV61nzboN1littbZREAQ04/BCU/b+Ys/NN/yo1+v9xP39pozfDAGoiZlqcrds3d5evX7zcwoj39br9gBrgzCy/V43OLTvFk7YvoHzz3sRz/jDx0EcY5a65J15yuVD/hpBAlKB88jBWYPVfYJAkYxvRjVWE7SbAHzmM1/kdRe8hauuuZmNW09gZHzCFnmqtTZRHMUkofzbtL/4Nzddf+2hldv9zRGEX3sBGJ7M1WvWBus3b384svEPnW53nXOGOE600WVwYO8ttBuK5z/3abzsJc9gfN0qzFKHot+hXJ7C6YKgMYqQAdZqnKv5Hq8FhAjQusRkC4RRRDy+GRWPE4w0yLop7/nAv/DWt72Hmfkum7fvIowineUpWIJms2ED5V40P33gHw8dOJDd2r3/uo5fWwEYnryR0VGxbsOWk+PWxDvTrHiwLgvCMNSAnDq8X2a9JZ74+Efy2le9jF0n74LeImlnEd2ZxuQ9wqSNiho4a3D1rq+3vwBRexFC4lDoIkWns0SNNvHEduLGGLTbHDkwxRv/5l184IMfRQRNNmzeBlLossgDKQKSKLjSmuyl87OHL56Z+s3gD37tBGB4wqSUbNm2Y3V7cv1r89y8MMtSgkDpMAjk/OyMnJs+yH3OPZvXvPJPecCD7wu6IF9axPRmMb15ZBCh4hYgqh0vcNViO/BrXpkXUcmAw4KQWCcp00XQyyRj6wnbmwgaLUia/OC7P+DVr3szX77oG0ys3sjqdRus1qU2xkSBDGg0wkvy/tJzpw7tv3ZpaenXmj/4tRGAYydo46Ytjck1m56tnXxLmmaREM6GYWS7naXgyIG9nHziVs5/xZ/wlCc9GgJJsbiA7s1hevOoIEIl7cpFs37RRb34x3wuolYE4Fz1fuuxggyx1lH255DkJONbUMlqglYDpOKzn/8vXvf6v+HKq65n07ZdtEfHbFFk1mgTRGFEu518qLM484pbbrx+2lp7q8/5qx6/FgJwLG+/ftP2hzrZeFev39/hnCGOYq3LIjiw92Ymxxr8yUuew4ue+xTak+PopQ5FfxG9dBicI2yOo8IIcB4zClFRREMh38F3ouKQqgWpBADnah3hhwwpi5yyN0MURyTjW1HxOGpsjLyb8e73fZi3vOWdzC+lbN5+AkEY6iLPpTVWJkmSNRrq1XNTB999YN/eQXwBIVY+91c4fqUCMLzwo6OjYtO2XXd3MrkgzfIHWqMJo0gLkEcO7ZNl2uEPn/L7vPov/pitOzdhFhfJeh1sdwZbpgSNUVTUBBxCSmpwB3D0NIuhz2fgCQA4a6sfuMHbnKMSCLBOUGZdXL5IMjJBNLqZMBmB1igH9uzl9W94O//0sU+i4jbrN24FgS6KPBBO0G63dludPmt26sDFszMzvzb8wa9EAI598K3bd61vja95fZbrZxd5RhAoHQShXJiblQuzh3jA/e7Ja1/1p5x733tA1iddWsJ0ZzD9BWTU9OpeCISQIKS364OYfmX/K9Zu+OeDTehqTFDtfLeiIwY/dxZnTXU9gS56YDPi9irC5hrCZgsaTb59yWX85V+9ja9c9A0mVm9g1dr1VhttjS4DpUJajfi/097CCw7t33NDv9+/1fn43xz/qwLgHxTqPbdpy9bWyMT65+SFe31Z5m0h0GEU0+ssBVMH93LaKTt59atexhMe93AQlnxxEd2dqwBeiEra1AssZOB3vpQVql/5nOFvvQcgwNkVT4AVr0AAQsqBsDjrsM7Dx5W/cQipsE6gsw7C5USt1YTNVQSjoyACPvWZL/G6v3wT11x3Exu3nODxQVlYa0wQhiHNOHrP8tLUq/fcfNPc0fPzvysI/2sCMPxwa9auC9Zu3PawUou39LPsJJwljCKtizI4tH83q8ab/PGLn80fv+DptCZGKBeXKLvzlMtHEEDYnkDIoFLVAhA4IQY7X9S2HaixgDUGqQRJHEEcQeCFxfuF1XWMhaLE5AVFaUAoRKVRnHM4ZyoLYYcmTmKMpuzNIRXE41uImpPI0VH6S33e8Xcf5G1v/zsWOxmbt+8iimNdFoV0DhlH4XIcqlfOTe9//8ED+7Ohyfpfwwe/dAE4yp8fGREbt55whlPJm7OseIguC8IoLIQjOHJon7Rln2c89Qmcf96L2bJzG3Z5mbQzj1k+DKYgaI0jg9hfT8hK5R+dzyelHHxvnUMIQdJqQCOGfsqePfv5/uVXc+U1N3Hw4DTL3T5hGLJuzSS7dm7jrDNO4czTTqK9YQ2UBeVSB2MtQkpPH7sVF3KAFwCEosx66GyJsDlKPL6ZKGlBc4S9N+/l9W94Gx/7+KcIkxE2bNkOQuiyKAIcxHF0TaT0yw/t3/uludkZe+y8/VLX55d24aEHEEKwY9cpG+PW+Hn9tHhxkeeEoSqCIArmZo7IpfkjPOgB5/LaV/4J59z3bOilpJ1l9PIUJl0kbI6h4hYOi3PVLpe1AKw8hnAO6xzGaJSUNMZHwRku/fYP+dd/u4ivXnwZR2YWaDYbbNqwjo0b17NqYhwpBMvdHgcOHWH//oMAnHH6yTzlCQ/jsQ+/NypUpMt9ZBBUZqRGiPXTrgBH5yRFfwlbdknG1hK21hE02xC3+Pall/Hq176R//7aN1m1dhOr1q63ZVlqrctIiYAkCb/gdPrKPTdff2WWZT8xj7+UdbrdL3jMDW/eur3Vnlj3jLJ07+j1ulIpqaMoptftBNOH9nLWGafwyvP/jMc9+sGAIV9cQndn0Z0ZhAr9rpfKI3RR+/MMVHPN4Fnr3bdGEiPaTYrFJf7l3y7knf/wrxycWuTsu57F7zzoPpxz9zPYvHacQDqMNjhjwBlUoIiSJoUT/PDyq/nif17Mf1x0CUoKPvye13H3e92J3vQ8QRz7aXNDYeDB19qFlFij0dkSUjqi0XWoZBXB2BhYyb9+8t/5ywvezDXX+fhCq+IPrLZBEIQ0YvXWIu+85abrrjnyP83r7bZet+vFhm5y3foNwaq1mx5sCD/Y6XQ3gCWKIl3keXB4/27Wrh7l5S97IS987tOJRxqYpUWK3iK6M4VwFtUY8wEbnN/pFWFTs7bOOaw1CCCOI0/OqJDdtxzgo//6RT7y8c9TlIbnPuP3efqTH8mmdatIu10OHzzA9PQRup0u2missVhrcNYghWPbjhM49Yw7EcQxxgW88oJ38aa3/j2XXfIZ7nKvO2GOHKLQFqXCFSuA1z4rCsG7kw6J0RpbLKMCSdheT5iMI0ZH6S92eOfff5i3vs3jg03bdqHCUBd5hrM2iOM4a8TqjzuLM/+8b8/uOtx4u2OD20UAjvXn12/adpqK2+9f7vTu4f35WEsh5NSh/dIUXZ76lMfz6r/4E7bs3IztdCh6y+ilQzidE7YmEEG8EqwRsmLyVj5Pa0MjiQlGWqALjhyc4r+++X0+8dmL+Oa3f8Cq8TZPfvSD+JMXPp01Gzew7/rrWJybJy8K+r0epS69TR/wwZ4RzPOUiVVruMOZd8UYSxgoRtav5eUvez1/+56P8eY3nsfz/vARJCMJxfyyTygRaiW0DEML5Cq3sdIIZYHJFwniJmF7A2FjBNoj7L1pN6/7q7fzsY9/hrAxxrqNW3DOev4ASbvd2q2Efs7s1IFvTB85crvHF34hATj2RnbuOnldo73qTUud3tOKIiMMQx2GsVxenJfzUwe4333vwRv+6nzuec7Z3p9fXsQsH8ami6i4RdAcHdzSyqKLwZxaa5BK0pgYZ/+eQ3zuSxfz7xd+lR//+FpM3ufUneu4793uwOknbaNM+wRRxDkPfTSjq9bSXZxncW6axYU5+r3eCn4QAqMLANZv3s7Ok07zDoHRCCDvd5kYa/D5L32D17/5AyylJX/+0mfyvGc/nrLTxTqBQFbaoKJ7Ed5dtBawR8UhdNbFll3ikVUEzbUEzRYkEd/46nd49Wv/hosv+R4TazcxsXqtNbrQujRR6Gnl/y7S5RftvfmG6/I8v9X5/7nW8Of+w6EP37h5SzI+ueFpaWnf2ev1IiWFjaLYpv1eMH1wL9u3reeVr3gJz3rq4yEMyJe6PlK3fAQZNwkaYwNKVsh6xw8TOQ6tS6JAUmjNq9/8AT7xmQtZM6I4YdMqTtu1hQ2rx1FS0en26acZKlAYXXL3c87l3g95GFobyjxnbvoIiwtzZFmKKQuss4xNrmb7rjswMbmaosgwRlfPZimzjJnDBzjlzDvSW+rxiU//B6+44D085CH342Mf+mvypV41F/YoAmmFYnTVazuIS1jjKLNFlDDEI2uR0bjnDwx8/NMX8ldvfDvXXL+bDVt20GyP2KLIrS7LIIlikiS4IOsvvWP3jdfPrizhzy8Ev5AGGBsfF+s373ygtvIfut3eDoA4jrW1Jjh8YA+tRPHiFz6DP3vxM5lYO0G51KHozGOWpxACwpHVCBVWqhKomLwVZO9vzzqLChSLi8s87AkvZm7mEM963P25y+k7GRkZY2RiNXGjjQojwigkCKPqDq1P8262EFKhwoggTLDGUpYFWdrHOceqNesQwlLkORUxiLUWKUGXJT+67LucdMqpTK7dQG9hjqt+fBmPefZf8oo/ez7/98+fS29mnjAIqhjDMP08JATOC4F1tiKUVvBBEAjC1gbC5iRidJz+4jLv/PsP87a3v4eFTsaGLdtRQaDLPJfOOtlqtftBYJ89dXD3J+dnZ80vsoY/twBs3XHCRNycfFOn23+O0QVhFGullJydPiLz3iK//7hH8LpX/RmnnH4S9JZJl5fQy4exRY+wvQoZNRgE52tkX0ftqjBtFUfFOUeQNLjfI57J9IGbefJDz2ZqagGLJIoC1q6Z5IQTtjM+PkaUJMRRTKPVRuBIGgmtVovVGzYRRjFal0gZgBBIqTyuMsar7OqznXOoMMRZx43XXMPUwX2MjI5y6h1PIwhjLv7PL/Ldyy/nA5/9Ptd869O0GzHGVUTUcNDpKC/B+e8HASdbORMKU+bYfIkwqfHBGLRG2HPjTbz+DX/LP3/iswRxmzUbNmGdLYosj4SQNJLwc/3l2WceOXRg4eddR/mz37Iy6tj5rlNO3xW1V1+7sLj0HLC60WzarN8N9t90tTzj1K186Qsf4V//5d2ccuIW8pkpuod3U8zeglAB8eTmlcVHeqRf7Xw3NIGeeXMUeU5ztMXfvvsjfPe73+fh55zGTbsPooE1q8dpt2KiOGRqeoZDh48wPzfL/PwcM1OHmZ6eZt++/Vx7zXVc8b3L6CwvkyQJzhmcs5RFitHFgB6u5VEqxcLMND/67reZOXyAIAxYWlxg3+7dBNKi4gZBkRNR8OWvfpdgfBw7BP6O3lW1OROD1x5/KEAisARRRNhehzaSdPYmsvlbKGcPsX3Lej74j3/LRRf+C3c54wT2XPdjOgvzUZwkVkiKflo8Omquvnbjlu27fukCUNv87btO2a5d+N2F2bl1YRgUSspg/+4bZaIK3v2uN3DpVz/NQx58Dvn8At1Du+kfvBqT94jG1xMkIyt2smbxqskRFbPnal+/3vlK0J1f4D0f+gRn7FrHkakFlnopSRJjrWHjxg2cespJTE5O0k8zer1+xecLVBAQhBFBFLHc7fDdi7/O/t03oZSq4gceb1g8a2id83yDg0N7dzM/O4WxmjztUZYFiwtLHDp4mPXr17K4nLJ+rMGX/vtbICXWmKPjCoPF55jnrQJWUiKkQgifmyicJoybqOZa8rRHOns92cweypkp7n2vs/j6hR/lg+/7a0Ybjr03XC2lEFEUB4Wxep2MRr67YfO2n0sIjksA6sVfvW5Dw7ros91OdzJKYm11GR3cfS1Pe8pj+MH3vsILX/R0KHP6Rw6ST9+I7kwTja4mHlvtn51q14uhCRkGfEIctXusczRHR7nksqvYu+8ga8ZHODy3jLYCiaTUls1btxI3m0xOTrDrxBO489lnc+oZZ7J563a/y/OMIs+RQiDDmOuuuopep+PJpYFp9trGcwKOsizZftJpbN62g5H2CJu37WDHrpNI+z0WFpYQQrB5xw7GWiHf+d4PyWfmCAMF2MqrHGQbIBiKUdQYR8qjBGJFIzikMISNMUQ0Qd6dI1u4if7UXnS/zzOf+US+/60v8YLnPpWDu6+jzPJIBYE21kwGych3123YvKZer+MdwXGsPs45Gq2WGJlc91fd5fSsKI4Ko3U0deBG3vSG1/DyV7wU0kWyI4coFvbjyj5Bc5yoPemv4ax/wCFkfzT8OPaG64ILEI0mn/vSNxlrBCglKIxl64RXuf20oNftkzQSHI7RsTF2nnQqeZ4ihWRyzTp6nWWElCTNNnHSIAhCglBhK9/dg74KqdeA2lmiOOTE084YhICpiKcizzkyPcv2bZvYvGEtX7vyci6/6gbucc87k3a7BIMtVXEDYuXSg0ISBIiaPnY4JxGu9hS8WVCBQKlJjCkp03lssYzWBavb4/zd37+Fs848jT96/kvZsO3kQIWRLotysj257gtFkd1nYW62OF4X8WdqgHppVq3bfHKW2peqQGkhVTS1/3pe8fKX8PJX/BlmaZrOkb30DlyJcIZodC0qTKoHlEP/KlXPyo73P+MnkjOsc4Shojszy0Vfu5Rt68cwxjA+0qTVjBECms2Ebrc3mOzlpUV6vS4gMNaStJqs27yFdZu2MDYxQdyICUIf4fNxHYF1lfq3DmMsxlosAuscRZlTak2pC4oyZ+OWbSRJA2sNiwuLnHLiVpzW/Md/XQLNRmXd5IBYGjxrxTeIo55XHKUBhPAmQaqgCm0rhHAEQUDYWI0TMenCHjrzB8lnDvGc5z2dv3nj6zi893oEIpCB0lla3H1kYvW9GQj1zx4/QwC8FLVGRkQQjb5a68KGYcjMob2cfbc78Ya/+gtMd47e3CGKmZtojK0laIxWV5agghWbN6zupUDKoQcfes9w+LXRavHNb/2A3bv3sW7VmN+9SiKloJEk7DphG2mWYozP9u33Uo7s30cYBoBfVK01RVGQ5TlFXmCNQQhHqASNOGSkmTA+0mRyfIRVkyOsmhhhcqLNxEiD0UZEM5Yo4ZG7BcZWrWXtho1EcUKr1WTrulE+/fmLsN0eoVIgfARSSFXZeYmUCjl4vipcPYR7BmZBKp/PIGUlBEGVm2BQQUTYmCRbPETemaKYn+Fl5/0xD7j//Tiy/xbCMMIYbZVqvHF0fCLw++tnm4KfagJq6rk9tmpVWZZPFAJpjKZIl3jt+X8KQUS2fIhyYS/NVVuqmxeeIpVq4NbVYGhFCGS1Q1jh0sHH9J0HUQ4DScx/fv17JAFIqSiNZ9qKvKC5epJ169Zw6NARSm2I4xghJfv27WN81SoarTbYgihOSJoJSRIjJBRpRlaU9FNNNzcsF5Z+t09vuUs/7RNgSNOUQMLYaJuRVsyWDZO026PE7RaMjxEpR5Gl7L7pBk45cTsXfvNKLrn0+9znvmeTdXoEQTgUpFx5fuecx0HDnP5QTsPwxgMLUgyin2CQEppja8mWDiPCJtH4JK971cu4zwN/j7LIAyGE1cbebXRscufy4sINP3P1f5YA1GokjJJdZZFLFSi9vLQY7Ny5kwfc71xsv0+xeJC4NeYXX3jJ9fa+Vi616mMQ1Bk8Y7XYQsijAyrCLzjWsu/gFO0kRFsfCo5CSVYUlKVGSEl7dIQsK4jiht911rAwdYjNZ5xBL9dMLyxz+LrdXHHVjVz2gys5cOgIs7OLHJmepaUck2VKtHac0fERlhYW+f6NM5xx2ils2bqFfpqS5QWzM7NsXr+KXSfv5E5nnsZZp+xg9erVNELBfQ9N883LruZtf/9x7vPgeyNcb7DLh2MYw7DQQwAPPL3Qr3gN/vkdWACLQK7IhsTjk+Y4ZecwurOae559OqeeejJ7Ds4zuWaN1roMWs32OcANx2MGfjYIBMIwuUtRZCglba/T4W4PPJt4bBX96YOgU1R7zAupCqoInjhK5Q8AUJ2949+BEzXcEyuxFBzCrbhPxliU9K+TKCCOAgKlWFhapp+mqDDAWkMjUoyMTtApHD+4aYoPf/nDXPmjq1nYv4+r9hxi08Z1PP8ZT+BRD78fO7du5LwL/o7Zb13Cg9ZInv7wtZx+3iug+2Pudr838aKXvoCnPesPKecPETYi3vH3/8Lf/tmriX9wGd/5KGTtJut2ncBd7nIaO1c1uO+dd3Hhf36d6350HSefegI6zVFSVNBkxcrWu98/u6twoMOJY7SBpQKo0guBFOAkWA9WVZigi5S8v0RrwxbuetZpXHP9l1izfr0sSy2FlGdIWYXIf1EBkFLihDzJL5qUTpds27oZUJgyQ0pv75CqAi5yEK+vV/XYJE1RUwGs/MwNEal+QlZYM6m82UjiCCn9/Cx1eszPznPCzs30CsPVu6e4+Iff5JYrr2Lx8EHuGhvu14I7jUjeEEjOfsxDOf+Cl6OnD/vWMM5yMHN8Ycpw4buu5Bk3v5xDNuCaQ4Y3vPldXP7DHxAqyY6t67nm+n20I3jIppAoAGFTfnzLj7nkRz/mE3HC5s3rELbkfR/+NG9/1+uwvRSlgno/15JdPenQ11oz1rkFQgzsoatIIj831Wsh/YWkQwqJLXMgYPu2LWDyav4ERVbon7nyxysAAKaswmXgky7ixN+ItSuLL9SKqh9oAED6aNlR87BiIIe+Do/KRari/QiJk4JAKYLAa4U1E6MYZ/jn/7iYq284yNU37uOcqOTuozC5TvHI9Q0C6+hnJbPa8OOrbuBFz3opew5MsdjN6KUl93nsI1kz1qLRajAvHeNxwtvuP0kYKHpZyWIn5YprbuGaa29EbN7Ax6YPM5nBmS3YMCq4/1gD40ree/0+tJN85nNf5oJX/wnNOBnEN7w7e7Qq9lgAT4lUVHg9t4DXjAOK3C++c1UW8xCb6NPYBUEQMCxh2rrjJgKOSwDADl1wKOJ1VGpWbd+HFl9QqfOVv6n94Po9K0kU9fsYuNC2tMzOL9JuxCgpETjGGjEuDLnu8AKfv+Qq7n2PO/GyZz2KC/7uE+wqZ7jrmKPf0fz79Sk3FnBLHNE8/SS2rV/L+k1beOD9782mNRNMtBvoIsU5Q6OR0Gi3ieIEFYQ0W23CVnvgpul+j4NHprn25n388Mrrufx7P+TgFT/k5r0L3HUEThlR7Akm2H/wCP/11W/xyMf/LmZhAaWGNODQAgsxZPIqQCjqKThqisXKNwPcWC/0CsayttaYRy/P8YzjEwA7iG0BVImXtVofAnb1qAmQIRA0/LthHsDvkOGr+++jKGRmdo4bb9rNxvEYXWqMDbji5sPsPjjLqO6xdcc2/vgZv8vszCJ3PnUzH/riIb4zD43N2zn53Ltw7j3P5uV3OoXTdmyi1YhAKXQ/JU0zjJBIFSJlHcpdWah+aTCz84MQr5KS1eOjPOgeZ/GQe96Z7FlP5OaD03ztksv4ty9cxPXfvIS+9tHZ//r6t3jUk34PU+YEqtKUR2k8KhXvH3Ql6FWZghokUmuKFfPod8VQfcOx3sOxzsRxjOMSAMvQc1BrLDlYLOccotq9K/ew4u8O7u6n3Vwt7NX1gjBm34FDLCwscsqmzZSl5qs/vIUiy3j06atZ6AUc1AEf+/RXuOzqPSSNFn/0zCdwlzufzpmn7OS0k0+k2UhI+ymd5WVmpnOKosBYi9GaMs/JsxSrC6IwIEoSGo0GjaRB3GwSxg3qXEPrHIU2aCuwtkQXGZsnmvzBQ8/msQ+8MzdPvYh//cyX+OCHP8GFX/kmb15YpjExgl7uEETJ4BFdDQCHBP7WkPrKvq8Xv77A0C+H319jrcF7jo8EguM2AUM7utbPiAFoFdRqTQzU5sodDY2BmycGN3uUbqkzawHihIOH55HOoLXhBzccoJnEPPLMDaxtSS6+eZHZ8jC7dm7hKY9/GKfu2EQrDkizjPkDe/jqnlsqhs9SFAV5llGWBWEQMDoywtjYGEmrQZI0UEGAtrDc7dPtZ4SdDiPtNiMjLZIkIggStLUUpfa3qEIKU2JFRJZ2WRum/OWfPY1nPPFhPP0F53PW3R/F5z/zXk6540709AwqTDxAHooRHbWIw0Iw+N2QSaznf/h3gzeLQSq8O+oixzeOUwCOHkcxTEJ4FqtWUceyTwOJPLo692ijMvzaDbj5fpqhpOS6fXNEcZNVo00WF5f46rUpG7Zv5RVPfDC7tm1iaanL3lt24yrPwxhDUeQ454ijkEbSYGSkSdJYTRAnCBmQo+ilknw5JSu0j+ZZByrwGb1lThIHTIw2Wbd2FasmJxgbaRFHIcZYMuPAGcZWraUsJ9m/Zy+xK/nXv/u/nPeGf+Csu/0uH/3QW3j8HzwGFmcwukQFPlFFOG/vVzKGOGY2BvaAWg/U8+tNxFAgbRhzUUcib3cBqC9aawCGvr8VfFipBle/1Xmf/9Yv7VYmo3pu4SxOF2BLUm2RRjAy0mR6fomlruSxj3wgv3PP0+j2Cm64+SBRHKGUqrJ7ve/bbjeJ44QgirEyJLOKhY5h+dACy92M5U6PpeUOi0vLLC4u0en2SPs98rwAAY0kZmJinFWrJtmwdg0bN6xm47pJNq4dZ9P6SSbHx5AqxBhNIwnZduIu5mfnObx3N6980ZO44ynf4f887Y/52sXf4x1vey1hItDzC6ggqmbNDYl8PcTgJz+h/iuU6DHDCjD0v6vWYQVRH9+y8vNqgKMW3R2lukW1oCtuzND7htHwcLTqVu5XCMGO7ZsBH6yZmZvnxC2TPOPR9+GE7Zs5fHgRoSTNZuJpdGnQAoQMUFJRWMFyt6CT5iwsZUzNzLN//0EOHp5iZmaOTreLHvJu/aiRdQ2n/VAqZGx0hM0b13HCji2cvGsrd73jidz5jF2MjbaYOzLDxOQEa1aNMNI6hanpWZ76+N/lAfc5hxf/xTs4+bT7848fehv3vf89YeEIxoAMwqHPOGYTwWDxa69pBXTXr1l5fdRf3LbxcwnAyhiyRQ6GkyK9EAwhx2PV0lHSOvBxMMagQoVxARe87R+RApR03O/O2zj3zF0cnO1w3YEraSQxDkdRlqRZijWWO+zcjJCKw3PL7J/qcODIHIePzDE3N0+py+rzJGEY+T5ASWOIlj96+uTAxfVeQlYUXHn19Vx59bUANEbGOPnEbZx+6jYiSk7dsYWHP/R+jLUTdm3fQBAlnHii5rKLPsCr3vQBHvSQJ/OSFz+Tv3nDS1G2QHczVBj/xLz8zGX8n+azeoTbmiR8XAJwDI1zFL35kw+w8tNh0HoUNKg1w0AHukGhh7Ga1ug4f/DMl3Phl/+bO5+4nm0bV7F942o+9bWrkHnKqjik1NpX9lhfJ0Cp+c73rme2V9Dt9ql8F0Aig5Aoblaf621raSyYo2drpV1MxeSLOs3bJ4luaDfY1I4xDsqyoHv99VxyzbW02g0+2814zVs/xs6tmzhx11budbc7csZpO9m+cYzXvOSx3P2Om3nx+X/Hl770VT776fdw8mk70dPzyDAazNKKINbqvM5XsEcrpcFmO/r+fx4dcHwaQA6jznoxa0JCDBb0aFEQDL3rqN8Owx5XPYw1Gm0N7bFRnv5H5/Mvn/wc9z5rG2PtBqvGR7hlqgOLi3z7rqtplA7hEnA+FavMCuKizwNv7jBbOjaNRLiKkq4TMX1gZUWtHuuV1nNqXd0MYgWjBQIWreW5Y01esyFgQYVEso2QoI0lkYavL0p+59oOV11/C1ddfxOf/eJXAcGmDeu446nb+N2H3J3/+o8P8673f5Iz7/IIPvZP7+D3n/AQ9NQcIgiHFvzYnMIVuOxqgDxILHUrczi8XD9tLY8ZxyUANa47ehzrjK78Ez/hDYifkNVhE+Cc84u/bh0vfvFr+cjH/4373XkbrSSmESdeHYeSCQdyzzQLRUlaKqyxg1B6KGF0pMk9JtvILKebl+hqFf1urirCh2LQfqEdxoFxrkoOqYSgzhEEIiGglARC0O3mLBcp0kJhfT+hVZS0jM9TCFSIUj7r2FrHoZklDh7+IV/+6uVs2PBZXvK8J/Oav3ghj3/i8/h4+jc8+cm/SzG3jApCVsznEMpyx8yZWxGEOoo4vPNdnWx7nOO4MYDnoYeXcYh8OOq7YzyD+vVRILC67WpzFmXByPr1vP4v38W73/dP3O+uO1kzErNmcpz2aIusFOy++WaCwhLHEQeRPG7WkEQBoZBEgc+mYbTBqiSka71JqDn3gessjxZMn/8P2kHpBsG2SgPXrpijRLA6EvxrXvLF3E+ys46pwvLwdsi7V8fQcShX+o+REguoQNEMw6plDcwtLPKK17yZpzzpkbzmFc/n/zzj5dzvnLuxfvUkutDV+4bm2B37eiABDOOmn1ir26ACblNa+E9+0q34/T91DEuq/77Ic0Y2rONDH/gkr77gbdzvzidw2tZJ1k2OMr2UcuGlN/DBz1zKj368j0gJlPS+cC9StFe3SVa3iFaP0FjTZrwRUhRmEFmTUqKUQClJICVSSJQUREoRB4okUCShIgkkkRJEShAHkkhJAiWqLJ667AuMgF4oKBNJHgt6EZSBQDQj4kgQSkGuLZmxSIHvQGoMutToUiOVYGR0go994t/RRcYpu7bw7vd9AjG+ymsrP6nH5cX7aa9Lz2rX4ZeFAVY+llvz2W519w+ex1u1QSn30CiKgpHVE3z9om/xrBe8gofcdQcbJiMuvXI/Nx7q0OuXIBytKPBhYGNAa4pSExBQ1/9I6zNtyqoOzxj/vRSghPD/JITSC4CSwi9Qpfa1sQR6xe4bC6UFjUNYBmnjEkjqPD8HTSkIhQCjKYzFOsMpIwEplr1LGUkSUncZqV046xxxY5R/+4+LOfPUzXznsh+B1kM07tDkDTy8nxQJ5wYQEY5LZG593CYBOBbkCRgEM4b78qzQGOKY+xODmzfGkLTb7NlzmEf8/vN5xF3XIwLBv3z9ForSVgyeQltHzziENQinPI+vDc4pSmsBiXQW6Zy375VdCYTA4lBSECpJHEjiQBFIgRIMBMBYMNXuM5Xm0MYiql1sBGjjzZWUEqTAVEKBEBjrKNKShUITKcFdxgPO3rGaby86PnHFQVqtRrV+osJHkjBSLC5nlP1lsrwBeVbhJsfR8ZP/aUfXpsCD22H3m0pQj3f8AiZgRf0PWq0O+fTDHstPjipxMgh51JNewl12NRGNUf7jO0eI4iYjIy2EFKRZQUs4zhiROBwBDiUMa6UlrCa/1Iai1ORFSV6UaK2RAgIlUYLBv0B6FZ8EklYU0I5DRpKIkSSkFQckgSQJFI3Am4dISUIpCKRASoGSkkD6YI4Zmn/lLJExtHAsl5YvHco47+v7uPPOFidtnCA3AlWVoAE4aykKTagsc3NzrFk9CaGs1Hg1p35nsaJR3bHTd/R8//wK4Bclgur7cQO1OBz7p/r5cOYPOMpS01q/mtee/1bmDl3LKXc9lU/+542MjDUx1iLxu+zeq0KeesfN3GVdg5d/9Sa+N1fwjKmA3Elk6CdTm6PvJAkVURgQSIGREEhv3xthQCNURKEkCQKkVwF+B2tLaSzaugE1YCvz4JwllN6+B8onYhhrKBG0pOPS1PLsFPYWgh1NwUPWNbjoYMpVUz3OPX0jN3x1DzIRGOMGfQiLXLNmdISb909z/tPOqRJoh9fxVlZUiBVTMNjsw6Dwp/ztTxm3QQDErXwVx3z4sft9SKKr31oLcaPBwZv28Xfv/ycecKcdfParN5M0Q3+IA4ISR1sJ1oWOL167n68dGuVBu1YzVU7zyRROnoxpI8lLN7Dbvg0DEPrdLoXAGL/7IyVpxQGtOPQ4QInKHfQiGiiDtpa8NBTG4pQHfkoISinQRhBHIVEY4BzM9zK0NUQOikByoQkoneFpGxMaUchYUjKzqLnDpvbQXqj8eyFIkghVdAjba3ni4x+KXe4MnWF4rE0/mkmpmYyV13bwN8dY2uMax8cEHnvBo3L9jr7RQaTrf7gXYw3JxCo+/I5/ZF3bsH+6pNSOMBZY64GNdRaBZefaCULpuHb/LNcULc5d32D5cMaaQLKsKx9fDESRKFS04pBWEiOc9QmlwhEpSRwExEEwsP9BpQXqBg9J6NOrlLSEytKo+IDSGEpjaTZbxGFIabyQgM8taAaCcSfpWktqYHOkOG00ZLd1KAHoEgj8PUpBtxDcbVvENTdN8+73ns/4hrXkR2ZQQVgpUFf73Cuavnq+QRLtrSWDDC/PbZCAXzgcXDN5NXlxtDOzcpM1vyUEUJZ8/Zvf5YTNq/j29R2iRFU0gRjslBLBvXZtYrQR8/1DHaI854cLDiUDnBREVa1AfU0lJUkY0E5i2knkVY1zBNIDwiQKUdKDU6UkYaB8BNF51B8q3yFcCFB2BV+HVlEaRyuOieOIUhtWWUeoJGmp/R/jOLyUc9lcHxmGnNSQNDevoV9YcCnWhCAEvVJw1uaEfXuP8PDHPIKnPfvJ6Ll5gjCqOJajkVOdJu+npZrLauF9ZvExWvh/lon/cfwC0cD6ZmoftL6BobtYAaYVNvSlTt3ZRQ4fOsBJaxSL3ZwoVAPVhhAo68iNoW8V4XLOo05Yx+d2T3Own7FuLAIhiMOA0UZEpBRhoEiikGYSE/pz/xDOVxbjDGVZeK/AWqy1KKkIgoAgCHBIjAWtVRV4MoO6QVmVrmsHUdIgiXxJWiP2wiR7GVprnLUYYCa3GKsxSvGgU7bx99+8BoCsKHEo7rghZnbqCHe457l85MNvx3Z6Q/mC/j9HlTX9U2H0UEiYuhX+UVN+3OMXA4EDiq3+dLHydaAlVgTEWksYhCx0upRZhhJNtINYDgMcQRhIlpYKFmTICeNNLtl7hItnMrY3JIUF4wShVLTjmFYSMZJEjLdbjLWb3s9XavC5WmuyLEXgKIoSbQxCSuI4RqkAV9UJlmXhi3aF8O4ggjAMCFRI4SCIY5pJAyklYRiS5gVpViCdwklHYRytULE2sISTa9nUEFy5ewpkxEgkGFU5e/Z1efgTHstHP/g3KGOwZQlCDhawdgKriaDeVc4dy8JCnSYCrkoKZYAxbss4/v4AQ4t59K0cQ1oc85v61uoghtElceDQTtBQPjQrlTrKrgmhIAi4fLrPmafuYF+3YG0IcehvNwqUZ+wCRagUYRgShoFX7aEiCiRJHBJHvpYwCgOUClCBIghDwjAkimIazRbNZpM4jqpYgTcjcaBIwoBGFJLEIY3I44pWo0ESezDoU9QljTigHUcEgeR+a2Ju7pSccOIWDncyFrop28YFMu2TBS0uePsF/MtH34LMepg8AyFuffEHi1ibour/IabvWHH4yVfHN44vKfRYLeSGBMGtYNBjcz7qOxokNwhBWWrWbFjD6vWb6HX2c+rGFlce6DPWkJTGC4mtmkLuXuhxzcF57r1rCzctdpnKShrtmHYS0oi9Dx+FAY04JI4CwsC7gFEYEAQeV0gBOEtRlAghkdIRRhHNVpMo9hXMzhi6gRpkYSnjm1VFUYxQikgqWiNt4iTBOQ/uklAR1GBYSlbFiv2zPXbc4QR+58ydnP/ly7HGsNCHRz3pcbzmFS/mhFN3oGfmB2V0zh6juo/KmK7mrd5FA7bXwaBzOVB3KDsGcx3vOG4NMOyMDMvDoMihFgrnjrrnlbC1T7CQKkQkTZ7+B4/mwh9O8XunNViVaBa7JbLqnaONJpSOHx+c5tBywfrxEV50j1MJwwghBKMNr/ZHmzEjzZjRZkIrib2rFgVEYUigAqSQVSMIUbF93jxEYUiSJMSR/9ps+L9P4pAwUJ4jqOIAgfL4ot2IGWkltJsxY+0mY82ERqiQ+LLyZrPB8x99b/7wHqeRK8k3rt7D3c8+i4u++ln+6cNv5YQt6yim5xCVtrPOc/jD/+owr29Nf+yOH3qvtYOikKpgsFqaWyGNbi8BOEYMGUZ4jpUQqhfQlQeqVYSoLiGlJJud5VlP+T3OvNudeO+Xb+DJZ8XcZV1Br9+nl5aeJlYwvbjEVTMdzjl1ByduWsdzz9qCkIIkUERKMZIktJOERhx5ex2oqgFEJQBVnaLFh3apvIUoioijmCT2QuCZQ0UUBIRKVVolIkkiGklMs5F4UxDHNJOEkXaTydEWk+0Gk62EKJCMYFiammcOyLtdrjk4z2v//Pmcfc+z6U/NUGbFwNXz8yGGKRI/lbZe3JWF9mnpK8LiF7rqqWQtYAba9uchBG8jFTyMBHy6lMWr7DqZos6jd9VX33LHVQ9hcVZjyhKrS7748bdyzgMfwN9/bZrJMOeJZwbcdZNPsOiXAoIG7/v+9RQyYM34BEdMVE0OVY+AyNcLCjkQPiUlgQoIo4AoCpFKUWpDVpSUpQEhaCQxSRITBAEC4esFjN9RUkrCIKTVTBipNEsShYRK+phCFHiN0GqyarTN6pEma9oJezo514cNHnXGZt596fW0Rkc55+w7Uk4fIgzDoXD6MEAe6nY+AP1VLwJr/LwO/lWbq1oGIeuOKzWNbIcucvyicPwCMNDnK8Nah6v66lCT4/VD1N8fpd78EygVYA2Mjq3ic598L//6ifcxNXoGn728R95Luc8Ww4O3w5lrQg7PzfMnX7iUdSMxD922GgvkpSHNSzppTmE8i1dq/xVAKlF12/AcvNaGvCgpjUGXhiIvydKULE1J075PKcN3C/ENnLwLGIUhcRyRJDFhEPh0AufQZUFZlhhrSYsSYx3b1ozxxt+5M5+5bpa3XPhDXvb8JzOycb3vOHoUcbMC8OoycinE0K/FYAkHDIqAupys1qQDFgw5PO231QIcvxu4cu0VTltgvT+t6s4WqkpqqAtDhjmBo9nDQPismTLNeezvP4zH/u79ufCib/LeD36Kiy/+FrazzOoQViv41PevZ2qxy6pIee7eGNK+5dD8MqNZSSPytrvdjJECojhCqgBtDdoYXxhSaqSRpLkmLR2zy32kVBijsbqgzAukwC+08oWusvIwoigkUApVF2A4R1FqemnOYi8lEJCWjid86nt86ptX8ID73pPzzn8pdrlPGMWeBKsK/1Z6CQ4hZkR1dkWNo+zQZqvPJ7A4Y7Bm5UAr/9dySIm4AVa4/QWgQp+DG6xUmVASoXxhSC2pCLGSOFpz7jWlVYtRldIkcOSzM0gpePjD7s3DH35vDt68l//65g/55mVXcf21NzBz2RVcfPNhcIaT14x484KgNJa8LPEpIgHWBFjjawOcM1ityfOMXpbRzwvfGFIGmDQnrSqoi7IAZxDOEkhJoDRJktAWvgq5ji4ODpQSAq11xc45eoUmkXDzXIdLd1/Ba85/KX/+588jdsazhHWn8+rRB+hpmDOpzJeoTjAZ9BUaIoacEzgpEU7gDAN84DHAsOZlMMe3nwBU3srR/qi35874qhop1YonYC3GGhy+6aKSdU2cHXIZa5qzLm1y5IvLOOfYtGEdT/vDR/K0P3oOL/ijP+GSS7/LupEGC/1sgDEQ0qt+Y5HSQmlw/QwnFSoICQJFluZMzy8zvdynn5feAwi8dxAGCmsteVkQSEEgfMjXt+rx5ExRFJRFSR4G1X16+jXPC8oqhUsKQVoaHz5WXkM1Rkaws0fwjTCDAeir3bpjEz8HTJ6t6R1/6EXtDivvyyKcHYBZ56oEGep096EE25/w239RAeDoA5asNYCumioOy5zAaEMYhUSTo6AkdHtkvT4qCBhuGjFEEFbbomqsBPT6Ka045mUveTl///5/YrIR0JIGE/gEUGstRgr6haY0DiUKhBQESjKel2gHSRTRTzMWOn3SwlBoiyk0jhyJQCnvcRtjCZQgDhTNKEBZqqZTrmoD778XQlCUfgGyvCDNMrSxRGFIRxti5Th9XZM3vPFv2bN3P//4vtejrMOWBlH1JKzncujxB9hIVHyFtRZjNPHYCDQSKEvK+XmsdYNYibMG62y1cYKhuVzZnMc7jgsEuvpGh266Rp0DrWANRZHSGG2SFiXvfNv7edlLXsuVP76OZM3k4OEGIGbgRdY1Af73ZVHQGm3zlS9fwlvf9QFWNQIfz48CGnFAU0kUDmMt2hi0sZRVi7dSG/q5ppPm9HONcd6mt5OIRuRlvdTGg8GqJZyrf6YrjSUl2ljSvEBb60XfrRBUeVHQTzMWeymLvZQ0z9HaN7IIleQxd9vCRZ//DPd9yNPILaAU1mpElZZ+FFVT42Rrq/nLcc4Qr17Ff190KU9/ysv4wPs+QdhsEichRmvfLgZw1lS1huFKmv5tsP23SQCG++B6VLqiwJyzaF1SFCkjk6N86ctf59S7P5o3v/uDXPSNb3DmvR/P6173TsKxcaJmgi6Lwc16rWIHoMcZg7OaIs14xevfQSThhLGQsTggVJJSKKY0TGv/rKU29IuCXpbTy0t6haafl/TTnH6akue+D3AjjmgnEc0oIFQCIbwAFdqQlZp+aejmml6uKR04odBmJV+wnxd0spylXp+FTo/5bsp8N2Wpn3GoV3B9t+Rw7rXFwekez3jo6ey79gc87skvRrUinC5x1rASY2Tl+fFKMc8zGs0ELUOe97xX8qBHP5vdN/2Q//uqv+au938Ke6fmaaweQ5clUoW+qkjUVcFHr8/tLgCDvLOa0as/zDkv/QLGVq/iL17zbh7+hJfwwHudxOf+9ul8//Ov4k3nP503vOUfOOcBT2bPoWmS1WOYoo+rgNfw/RZlSXt0hB9ecT2X/+gqNo9F9AxMNBQ945iwjpc1DHfpdjmwlJHlJcv9nOU0ZznLyYoSbbxm6GcZvTTDGJ9fONJMGG81aCexb+sqfA6gtg5dp4Zb0Nbv09JYsryklxZ0K7Q/1+kzu9xnvtun08+Y7ZcUyxl/EBl+v624eaEgkI5LfzTFs37nVP7ry1/lY//4KcLV4+R5WpnOeqG8EFhnKLWmvWYNP7jyJs6852P4xOe+wofe9mLOe9Jd+ML7XsSayYg73ev3+frF36e1ZZNfZqkq7GAG1625kNtfAGrWsdLdtdXPi5wkhCBOeMLT/4K3vucjvPNVj+UxZ43zo+9czlXfu4IdwSwXvveF6P48Z579KP7t0xeRrF+DcKU/86dqMmWMZWxsFC1CPvjxz+Os5UhHs3su5eYjXQ4t9dkVCl46YnhmbFjsFSynBWlekhYlWV6Sl4asLOlnBf28oDQGpQTNOKJV0b3tJKYRhoRVH8O6545xjkwb0tKynJVML3Y5OLfIgdlFDswucWh2icNzSxyZX2ZuuUcvLZjPS85MFC9fpXjBpGIxLbn60DI/2DPPpy7Zz0gDzrvgvcwdnqG5bh1BEmHKgrpdvC5znNU0V0/ygQ9+kns/7Kns2LGRiz/6p2xxh/nB5bs5eNUVvOqP7sfDHnx3HvJ7f8RH/vEzNDatx5YpedYHSn/w1c+xrHBbwsEDIshijMEWfSbH2uy7fonHPenVzM0e5hXPug+rzCK37O6iogazM4tcc+NBduUZn3v7H/CSN32Rx/3Bi3jZ957D31zwUlye0u/nICSt1ZN8+9IreO5LXs2Pr76Wu5+xlZa07Ni2hsXUcumVB8nSZUoZ0q2oZVMxkHWXrcB4sJdrf1aPDMUgkxfn/XqlJElUFWsIgdQGbR1SCqKqiCM3jkyXILyZMdbjhbwo6Gc5pbUI6+sLrVJoq5gvNAjYuWstu9Ym9Hqau5y+mZunetzxbo/mPufejTe89qXsPGUH+fQ0Wlua7QaFlTzr2efxoY9+igfd9078x989ja998SL2HVqg0WjgpOJTn76Ipz3sXA7u28fTn/3nfP/7V/LGP30SWgisXalwvi2ZQLdZADzC9IUIWdpDRhHf+N6PeNxT/pT1a0b4wCsewWe+9D3KhRbrxhtkecHCwhIj7QYHp7sc2neEB919B1ffcoS3vuP9XHHldXz8Q3/Nmsk2BBHve++/8Lw/eTWrJ0f4h9c/mbFijhv3zLFu3ThJI+Dce2zly++8iDAJSEqHsLqiTOskdAZAMjcG42y1sJ43V1IQhCFJbAeup61AoK2YQANkxuC0ptSeJ3DOoSu201pDoQ15aRDO0S8dWjiC0rLcK9i4doSXP+lO3LJ7jkOzfe5++lqcjHCttbzpny7lDnd5OP/wrtfx1Kc+itg59uw+zGOf9Mfs3r+P817wMA4cmKUzO82huRSplM92znJKI5k+eIh14xGv/5OH88Z/+Azf+tZlfO7j72ZcNtGm6gonbjsGuA0aYAXxr1k9wYWf/SyPeOwz+L0HnM4T772dm6+5gSMLOesn2qRZQaElvV7qJ9ZabtlzhEOHetzz5FW88SWP4Cmv+Dh3uudj+cj738QVP7qel53/Rh754NM5dcsqtrUyrt63QG4MB6eXiAPHkgq8YlOSMPAEknYOi28sGVQoPS1KikolRkFAaSzGQTMOSaKQJIl9mnepfSKocZRG+1y/yn+uvYsa61rrBucJlNp7Hc46Mm0pA29CpHBgLQcOLdDtl+As80sFM/NLnLgp4x0v+R3+5dL9PO2PzuO6627kQQ95AI970ovYsHaEL7/v+czsv5GP7bH0uilZmuEqervbK8jTAmsci0spd96o+NSbnsD/fedXOPvBT+eyb1/ExOSEv0/jK5Gc+SXVBlrjCKMmF37l67z6De/iGY86i4feaT3XXL+HIAhY6vobX+qWGKdY7uWkeUlZag4enqfbKZmZ6xF0p3nP+Y/lz//2Qh7ye8/GOsOD73EiL37kaXzmazdyw25/OHOgfBRsYrTJ4bnMB3NyTWEEhXP0clPl7ltyIyidYYSSKq6DkoVfTOswNsFYXy3kpCKIFJEFVXgQa60lzf17rXVDyNrnQxTW0S8tGI01jkgKlIV2IKERE4UFoRHEQQAuQwqfwCKkYLZTMv/D7/Oqpz6MTasj/vJtH+SNb/sg977HKbzxRQ9i/pbr2XNkmUAI5mfn6fV8p9HSGLJCY4yhLHPCQDI9n5J2Fnj9M8/hnZ/+Pvc693c4644no1TlJoqBc3D7CgB4dZg0Gnzt4m/z8HN2csf1AZdftZcgCCmzcqAuO/0cREg/9YcwSynIyxJdliglOTyzzMZNinPO2spnvnItmzZM8H8euIsjB+dJs4KlTorVGguU2tHPNMZ4YdDa0lQRn9g2SrN6WGccpF3+bD7jCA1awuGkoDTV+cFSIqXEIAiVIlDKB3yCoMoQKklLTVZor+69yA/YSoVgqrC8LDY8YixgGV9PKCQ0Q0legjOeSRQSsrzEGIc2vrmFlALjFHOLPR5x5wne2W6y1Lc87B7bmT+wj8PTPYqixOiC+fkltC4Roc9azosSY3wvBIGj2y9Z7pUcufIWXvyoO/KK91/CF7703zRbY7g6j/E2YIHj7xHkvP9vjWeg1iaWw0cWKQkIrB4cmaK1IS2099tLg7EG8K+FAKtLpBBkhaPX94i4LAqmZ5dpRYo8L+j2JRKHVIq81OS5Rluf+RIEih1KsKM+yMFY8rwkLC0tBIW1NITFOr8gpbHkeUFWAb8wdIQWv8O0q84G8GrfnxTmS8ecE95FrDqUawenCMuJpiBFEjgPInUOcSAoe5q0aQkCQRR6uicrSqIg8MfMa01WGOZnln0qGIKFuQ4zUcNrNmdROLqdftVzy5e19dKMItekaU5ZauYWeggH/cKwMLfEuXdYw00Hlz0KqsCwu/2p4EoMKirAWlhYzmlFktL6gx2ccQMaszSOQFmK0vPU1jpKa0mzEmctvbSgkenqRv2RrVEAWVagS3+gk1ArwM4Jyeqm4v19zeP3Zbhcew4+9UfCt+IA4+BKoZhMPNO+nJVMLZdk2tKMAtaN9Nm5doSxVjxIcatbv/XzgsJaFvoFi71iYCrGmpF/vzE0sZw3a3mvhMKWFIXFWFAKRiPF5alh7aZVtFsJURgQVj0f2u2YLDN0+jndTpcgCDwZZj1t3uvlCKkIlSBUUJaaMFSeqTSWXqaxztLvpxRFQbefMdKI0drQLywBfsFtnU1k3U+m8N0eAuCOSQUrtSEvDCUO4xzOVotVJS7YKmSqlA/0CGvppyW2smv9NEPrErDEgaAZBxxeztixNiEOq7MBrK369hpOP3GcB51zAl+5foq1m8eZWijYcuIkC4t9Du+dAQdhAAsWFnoZk+Mt7nm3jWzbvpq5xYzdB5f49t4F8u4ME2ONAQUshSTLcxbTgsnJUc66y05OPWkj84s9LvvRXn64+zBJIJFKsttIfmQdohFz0smTNJKAxaWUhW5O1Cp43jlbKXJfrxhHIUVpaMQR2hjK0jBzZJpIlYPS7iIvMEYOilojJcjzypSWK3S1quokxYB88x5Qlhl6qa+mqqlqR7VDb08BcG4428QPYx1OeJvsfXG/8EXp8+pLbelnJWGoEE5UIKtASej0cuIkqqJZXm1lufYawvjX1vnEjyQOKbRhfj7lHidMsn0y4VH32sqXL5/jDx5+OhbHc1//JW7ct0Ach8x3+zz2oXfiieduJV3q0mgl5Lmhec5O4okx/u3im/nwp79HIATNZsLSYpfRiTFe8gd345wTJxiNIIpD5pe6vOwp5/CFi6/jbz/yDdLM0IwCTt4ywmufeTfWr57g0OF5FuY7HOzmHNh9mA0jDaYXUkptCIOAflrSbsaAQwWKpcVlQpkTRQGkGqsNgRSkuTeFAsNyLyXLSkptB4kqzUT58xHwrminb8hLS6fbp9fPqg06tD7yl+AFeB5oBVxY67DGVcLmUPhs2UKbyhQI0tzhBCghSTNDKKDZCunnvpq3roiNA4kSgqLUPoxc+qyegf9tNN1+zsGpZXqF5saDHTq9jOuuP8DIeBsR+OKNvNfnKY85mxc+4kQuv2IvC92cRjf32mmux0nA+U+4I2ffYQMX/P3XmJ7rcO697sgrn3N/ssM3Mz87w7KDotTsP7JEFMbc/8yt7D5nK5+79CC9zDI+2iAOFbccWuLAwTkkkn6uSY0gzTX9LMd65UVWFJhayPGATlMgqxwBbTRhIOmkhc87sIblTkaaFd7zKA1laYkCn/9ntKWoIpvaQjctBhjlqP15GzTA8dcFDOK2fpgK8fuqV2+DpKw0Q8UZaGvR2odQtbVEgSAMFIV2HiBW/lqg5AC3Kumrb53zJgXnaMQKbQxh6JtBlqWmLI3vBlLxX0bnnHnKRn7vzmu4/vqDLPZK/NFBllaiaDdDupnluuunOGNNxO/fbwfnnrWFv3nBvVi86Rquvu4w/cJgqo4eSkmuvekgpdbsWqUYbwh0UZJlJZ1eSWe5j9a6yt3zWswYH1Wso3OlthSlIc9LrLGkWUGvnw9+b4yP92vjC1Odcz7LqJNRFH5+pPRzooQ/u8gaT0SV2mKcG/Q2qMPxv6S08PpUz1oavM3xNspTpVr7UGd99l6dFFxqi65cuDpJNC8MWe4PbfCLLnzbN+NRuKlIkFIbtLYoKf01be0K+kXqdFOytPAlYMDZJ02QdrpYoJ/m5IWhn2rywgdMej2fG7D34AIXf+cmzj5hhH033MzMUk5pHL1eRreX089LgkCwtLTM8nKHHVtW0YoFOL+je72cfppXi+iDWl7rmSq1wXsItgaZWV4Jgma5Vw5O8vDP52291l7Ye/2Sbt9XMFnno5bNKMQYU1Uugda2Cmkz0KKDzXkb2eDjJ4JgEG+u40KeYPG+bp0boq0PoQppCJyksJ6m9FG6CqSUhjQryXPvJRjryEsPbHx7F++D56UmDDRJqXHWt1fRVUMIY4yP1vX6g4waZzwmMcaR5iW4gNJocJDEAbmyJFHAkfkea8dD1k806fQ1YeCzdbyg+kyuoDpdtNtNMdqRFt6ddQ6M8bvXOzFe4xWF9tjFeKrZWoMxjqKw9PMSnKMsA9KspK6tLEpNP/UZyWVpMNqSUg6SXp2DLDfYxNIvCkrtd7ypciDKCgyuMD9HF5fdbgJg7crKDxd+1ALgZcMN9d2pXEIcCDnQArW6NNVC2qrFyyDTBXDOsLAwRxw3MNbzAKU25Lk3F2VlB63xuyfrpwMwiXPML6W0GtFA62hj6OcFUeiPie1nOcZa7nTiJDhvboLqaLea75fKHxwtHGRpAdpQaEedgu2zjDX9fo7A9wzKCkM/K7BWYq0mLwTCaZaWFoCArDRIURAMJUVZ69vQ16xfPy9pJQlCCNLCIAWUlcr3CN9VbWzcQGCHN2WtB25LNOC4TICURLWiqVOXHN62m7qcy3n/21V2yWuD2hwIAmHpZDlhKL2dr+wlMhxyyRzTCx2inQ+g3z6RtN+nqKTem4Qqi8f5zKJSG7TRA+LDWUsvs2SlV8V16Xde+IydstR0ehnW1sfeQJZp9MDcmEorVTvcOvK8oJdpSrMyAdpoyrL0BJX2mT6uOhpeSCq3uGB6OWNPOs6e2T7CWbpZQZbXF/ICkBdmkC1VaEMUVo0inKjOPXReAJwH4b5wuYpZ2LpDmGPAAQuBFMeP7X7mGz2zpPdUWUC2rsk31lWpWa4Kl7qB+vQ0qBeOvHS0IsfuqUWmlo1nCI0HR3UmUKQ8g5hlBXuXm4xuPIG8sY4DS3ogUNa5aod5TSOF/5wsKyt3CTrdjH5W0ul7MkcpiRB+l5WlJs18RW9RlJ5erkipolK/WeGFbFihGuOp6MK46sDLWr17QSu0QeKqWoLKnw8k0wvLrL/bY3jWeW9iRqxhvtNlpBmh69y+KgehX5mNrDD00xU6XRtDVhiy0lKUFmPqebWD3S6oQt/OEgTRIOVcwvLxpob/TBPgnMOU2WUqGPEfFPrmbAu9gg0TMcZWaN968kcbrxny0hAo34mjn/a4ZR62rArppCVOQFrx+jhLVmgWuwVpCUr3+ffPfY4QwxlrRilNnTPoqu5g1XGv1puVTrckLzwZsricsXa0gZRusBtrYXV4TKGtQAo1IE6yXNMI/cHPWeHvuVakznmtkZdlpWn9ztWlpiw13X7JSEMQBD5mUZbWawpnMC7g+z/8MQfn5pienmPT2sALo6l3qxjwJYEQpJmhN8AQPtcgK8zgtJJI1GnwGt8ySxJIy2zXa6zqZBIrhcLq9Lu3y9Gxg9w/W9wUKIl1RCoIrQpi9szk2CGAZ6x3WVw1cd6eQigdy5kkbIySl7ZKAxuyVMI3hNLGUhjL5lWKJD3EWesKVo9ElXbz+MAvJKSZHsTl+7mu3EnPQZRakxcaY/xp4N5iuQHtmxfeftcC1UuLCok7skJ7bVDVFljnyLKcolw5hc1W2iuvtIgnvnwUsdTeFJTaMNoMyA9ewSVf+U9GXYdGI2J6oe8JnVoAjCMrDL1Mk5WGfl55VLV77Xz+VV13CVCWhlI7pLDkRckt0wVBGBFGCdbZIFACq/Nrj1q/n1cA6kXq93vTAeaL+FMMbas9QjezXL2/y2QLcuOrb1XVnMmDuQoda0MkBdtGIdMWJXwmz0ruukBS1xQKsgJO2jjKqnbAzHLOWEsRSjHQLAJBNy0oSx++zfK6MKI+hsYOsnjK0ufWl9qQZaUXmsLvaPCBrTTXvjlU6QUnK6rFp84Q9qCvlldtHUXh3VOt/Y7EVS1nfSKST/LUjq2rE85cr9iyKiLN/ecb4wYFU9pU91OZnn6uB2aoxjoe8HkBDxS+o5k2jMbwnZu6ZKVlZHQCIYS2ThC48sJOr7PPL9/P1gI/VQDqv+/2M6vz5VdLXzFBECU0miNce6jg5kPLrG4alKzr1CtQCBV4s/RLy2ioiYUlLXyQwz+0qybC4whZvW7Gkry0ZKUlrur889LHGZSAtNr1/czQ6Zdo44O2UgofgxdeqPJSU5Q+oNLPV3as1sYfQi0862erlC/vrXjPZlhAi9LWh3n6aqG6QFWt9AwEKMqV5+plljS3NGI5AHM1KVY7VbZKPOkVukL8Pn6SV/dojMVZ/5lF6buJxgGsaksuu6XLLVN9Wu0xwrjpiTghpcs7r+qkhV3Zvj99HDcP0FleuHx0ovHRDPmHShjdaI0GAscP9naZ62ruuKVJ0ogRUqCt9W3aHDgsqgp/jiTSq0lZS/bKLTq3orJkZR+zwpMdCM+UedbQ4wspIdO+0NMYrwGkgEgJijJHOocxEuOgl2v6maKfGyLlbeyaiab/HFeXtnvSKlCimnAIQoFTNak11Hja6+ZBraC1EAce3FrnT1CzDnJtkapqQVsRZXU/AZyrvBiP8AMlCQMBeGEEz3tY4+imljAQjESQ5gXfvSlj/1xOszVCa2QCcIVBRi1RfHSxs3i5F9vbWQB6WeGS/tyLg2TVuQa1Q0pTNNpjURBG7Jlb4sB8hztszDhj6wiNUNLJQQpHIFbazPnEEEsQKqzwpEvNW5TaIBBV+pUnlMqKIfOIu6aY/e4MAzHYSXU1TF4ahC3Y241wWrN93GsNnK06hTgK7ZtH5YUhkKYKuvh7yUpDEnlfPy8MKqy6hkkx0IZSiCHNKsgLv2DNJBg0l6yJskI7otBrNeEsAkEoVzRrWVoPYL3rxlhzqFtahaUybWmFUBYlN02l3Dxd4pCMjE6QNEcBV2grolDYq7Le/Iu6WemOd/FvkwAIYG6ps7QlaTxKh6NX5FpESpgiSprRZBjR73W48mCPPbPznLoxYc1oQmoCCuNtF8LfVGkcKOuB3QBZe1PhnC/IMNqCtzZVbp7wHgO+e5g2vvevtY64ii+Ad8f2L1mummsQKEPAAhsmIuJQ0ogVnVRWncOglxYI/OKkuSGvuHUHAwAmq+bSHtNQLZSoTI4A4dW+Nu6oo9tqvsSzopW3g8BZaFQChvCasmZHk6pLeT8z4BwGr81CV3JkIePaw95LShpNGs0RVBADriitiJJA9EW++OhDS93lilM77nGbW8Tsn5r+scoXTgoRV2qCyIGWUulme4zR8VX0TMx3d2d8/5ZlpOkzkdjBuXzGeibLWldV3lS2sAKLtWunh9qjaLPyHm19EkZaVKnaxmGN99dBEAYhyz3fMziK2yz0iirrh8E1mpFCSL9wNXeRFd6rqJtC+2IRhy7tgPqtRbW+J6U83hgux/a23npsA9iK2q5NTO3FCLwm6WamQvmeW1ACeoUGHE2l6fY6fO+WZX64r6AkYmx8Fa2RCVQQaYez2skoEuIKm86feGh2/ma4bYt/mwRgeByYmbvZ9Kbu2aR4AyIKNCoQQugwSuzo+CTtkXGOdCX/fW2fa/cvEdk+sbL0Sx/jN3VDCQAhfdOFaqfX3oOp3MiiStVS1enpdYt3U9GoaWEqN81iMZy4LmLUzmBmb2Dn6jbdzJDmhn5uKU0tgFWuoPBZOIihmnrnUX5Z2sot9C6lVwDecyiqRJJG5IHn8H37RM5ykBijB9S5tw1yqHxeWztgHNPCUlpoBIaQlCv2LPKNG1Lm0oCR0XFGx1YRxg0rhNTGiQCUbMji9WVv5pyp+cVDP886wi/QJ3C20+83svz81ePjnzThyOszG/weziCV0VGjJcejWOZpjxtmeuyZW+KkdQHtZoiQEQ6PB6QUBKECUZ3uIYQnlKzDSrcyQUHVjsauYIBSW7TzrWd9TLwqWHGOO64LkEKR6ZqqFQNVW1VcD/L9PA1dxyocpXGkpa4YzcBTvHa4hM0vZ1lHOO1K3UAtQHlpUBWgNcZWB18fM4QYUMhp6WiGllZUcv2hjGsPaUorabXbxEkLqQILaIuInJMylvaLlMsvnV1eurEoj60Kum3jF2oUmZaG/TNzPxpNlh89Mjp5bxO235uV4hThSqRUOmmOBFGUkPZ7XHU4pR1p7rDRMjnuF6iulq2LMFXVtXul741fsLzi2+v3eaAlKl6gLlb1buhSaigrnS+sxjpJFPgOHHHokba10C/sQIsI4Zm8rDBVXMDX8mqjwYWDpAtRhaWtcbhKIL1LqwemawUkuqEey67O2qoQvhv8XEnHZMsxvZhy1YGM5QyiOGGi5e283xMisMgolO4GWfb+qLu8/M1uVhx/1sdPGbdLu/jlrLTL2dQ3JtvLZzVbE3+QE76zdLYdCGODKLIjYRToskm31+V7ewo2LS1x9s4GSno3rObVpTJVxy4PDEW108oqT2BACRsQkav8/aozqKBSpRqL7zNgjKMwlkYkMda7f3WTB20shdaDRIxC+xM/lCgrJCdxSLT2waIKA1IaSy8rkEoNCM2al6gjkHVSqagLRvCvhaS6D/8sEosUBd+/JePAvEGpkNGxNkGUIIXUCKR2MgiE6DZV+epeZ/G9851+enusWT1uFwGox3w3zemm/7h+fPQLzcbYBX2XPNc5I6UwOoobciyMZJ72OLjQ4wuXd2g1EkKpqhTolVZuNZJ1zqt66yCJquRSPIPm8AdCOFs1spQenWvrO4nmha7ApccPeeE1Q16YAe1caDvw2aQAawoOdSSNTLN+VCGisKK1GTB8ae7JJydK4jDwCZ9GDXAJzpsRKY/uAqKEqMgkjZKCOFTsXSy59kgPYxWt9ihR3EAqZYUQ1jgRSCQt5d5XZIuv3L+wPHt7rlU9frFDo44Z9QMfWVyenZ879LyoXDwhUfybk1FgEFIKWcSNlp2YXEUQt+lmJabM6OUWiaEZWYpKFZfVAQvGrdCiyrfpGmQb1QJSu2XeK/BaoMbbuopMphWwSwtbpVT5rCRtak2i2bug+J1nvoHTf+c5XLt/wTOQVRja1b36KlyS66r1HbU34wY8fmlWvJz6XrWFUDms1hQGBIa0sETJCBOrVpE0WlYppS1SGqeChuRroe6cOj9/+HnT1eLfxmSf4xq3qwYY9kB6haE3N3/LWKP7+FZr7J5atd5dCnWWoEQF6PbIaGB0kzTtsdBN+erVJXfcomknCoGkMHYQanbOq8xI+ViBEFQTv5Jc4YNKXoBKa4iCKnJXAbug8sWLKutHCjHI2YsCSZYXEDb47//+MunyLJmL6Bd60BqGwcdUNIvztt4O7LqPh/j8SC+oUvqCklhBKDTz3YybpnJ6hSKOY9ojYwRhDALtvJ2XoRB7lek/q7u8/PXlfn7MeSi3/7hdBeDWxlJa2KV05tLJVveeSWvs90vReIfBTkqntQpDWsF4EEUJvV6H792SsqotOWWjZbIdEYcMwKD3HIYyXoYYl7qBk19sS2k8vFRS+NI0IaqYgtcY9VFytSeQFxqpQsZY4MYrv0PoCnZO+oWPlalOMvHEkGOFz/BxBYuWskpXq0Ct9TggCiSNQJNnJVcdypjuOqQKaLXbRHGClEpbwDoZhFIUyuYvzHudf57u3r52/qeNX7oA1LTkfC/N6KUfWzs28qW4Mf6KXEZ/ZoxGonUYRXI0mJRF1meu2+XSG/psmSzZsSZkNAnoFD55IqqSPz0a8MUoVS7lAH07fNUwxvvaPjfB0oo8aVNoUE7gnKSsNIYSvsJotB3TMou0Y0Ujjn1OgfAtsuo4Rb3ryyrU7JM3/EOW2puEtMhpK4iFZs+RjJtnDFYEtEerhRfKIoQ1lkBKSWyLt+h+980zy92ZX/Z6HDt+6QJQq61aEKaXOnOttP+ysZHRD5mg9cqC6Mk4jVS2iJvtIIxjmfV77J9PmVrSnLRes3kyRqnY71zJwCMwlpXQKXWPvdruiorOFYMOotRsnAPnLFKstJwzlXfRCCOSUJIXllZcHSU7VGtVJ71o44FdjUV8txtHElqULbhxqmTfvCbXgkazTaPZRqrQeu9RBAgpY6W/IMrOeUudzjX9qm/hbeHxb49xu4LAnzaOxQeH5hau6S0e+T9N079fFITXWBFHQkoZhJFujowzOr4Kp2KuOlhw6Q1dljp9xiJDK5GDTB9PD6908TLWEYd16xdP2frIon+/EPUZgPW5RAKcqMrDK1xg/clhWvtEkrzwIeU6967OH6wFoQZ/gbKMRAUzC11+fCDlxmmNUw3GJ1bRbI+hVFAA0jgZCGcvS2z/IenyzGMOzy0MFv/YefrfGL90DfDTRjfXrpvPfGPNSO+uzcb40zIZv846t1ZKTRTHOgyjQBcZ3V6XS25M2TtbcsrGiNE4qIialQOea4o4UJ70EbgqqOMX21hHoHwipZQSCQjp08Hr5FoffmVQeVPnM5hBpU3V7NJZhPA5C9o62srSTXMu350z3XGoIGJsvPLnpdJA4ISKBGIxNv0/7XWXPjbbz8r/eWb+98avVADqMdPpp3T671010vp40pz4i0JGf26dCZQyOkoajEdxkGd99i90ObTYY/OE4oT1DRqhIvfJPX5RhT86LqgIpno/1UxuDdDqpot1dlqt4uvwdO2+1bkCVBhAKUmgambf0Ywsuiy49kDO3nkNQtFut4iSRkXfVv68kMTotxfZ8hsPLywP7Pz/trq/tfFrIQD1RMx1estxlp433hp5T9Qcf0fuokeDRkh03GjJIIxk2u+xdz5larnLietCVrcjbhESpSRS2kH+nBSCWrGuhJ4B5101oVay6G31fv/eOue2FgQxlA/vfx4pg7OGA7M51x/JKY2g2WoRJ02UiqyQwlonA4eQkbCf09nCH8/2uvvyY3j7X/Xiw6+JAAxPRF5aphaX9o1m/cclzZEzXdh6uxHhfXEaFYS61R4N4jghTfv8+GDBRDMnCBq+zFp69ayNRam6nMwN8gpiNfxp1eIyvPNBOXxPT+coSn+KaVk1Z3bWoq1htmf48f6MtHBEcYPxsRYqiJBSaocMLEpG0l1li86zu73ly7pZebvw9r+M8WshALc2fHxh/vLRRvfBjdbYY4xqv89gx6XUNoobNoziQJcFnV6P0JYgBWlpUcL3DXIIlFqpXKqPjPF2vELu1BjBIT2QqBI8/c/SwlA3gBICwkDRyUu+d0tBEMaMjbcIwhghpUYIaVGBgOXAdJ+T9jufX+xl+a9wCo9r/DLYxV/KWD3SnlCN0RcYlVxgnUWhq8NKTJD2e5R5ijaGtaOKUzY2GG9FdHPo5Za8tLQbAaOxYCn1OYpRIBBSsNgvCZQglJKlviZU/ozg0jjaDcVkE2460ueaw95tdA6SRtvbeSm1L8+QgRQSqbO/KLKl9y50egu/6vk63vEbIwAAYSCZHBndSTR6nlHRc3AaYbV2zkmtS5mnPdI0RQnLCetiTliXoF3AQgojiaQdCRZ6vvN3M/JMYC/zNfqRkiz1S98jSEGiHALNTUdy9s2XKKkI44Q4aRGE3s47VCCERLrioy7vvHax07ml1HWLqV8PG/+zxm+UANSjESpGRifuQjjyViPEfbElwlltrZVaFzJLexR5RiuCO2xKWD3aQIYxOMHccoaSkmbs8w+zUhMpf6D0fE8zmgC25PBCzi0zGuMESZIQJS2CMLZSCu2QkUOiMN+Qund+p7v8rX6ufxPW+yfGb6QA1GMkiVSzPfEooxpvM7htwmrAamddYHRBr9fD6Jy1bckZW1usHkvYO28wFtpxULF/BqUkzRjyLGexU3LDVEa/9IkZSaNFEEQopbQTIrBOorCHpcle2Osu/ns3+wVTcn7F4zdaAOox1mo0k8b4i7WK/9I4GymMrlRwUOYZy51lsCU7Vik2jEc0GnHF9YN1hkha+mnOVQdSjixbVBDSbLYIogaqis9bJwNAR7b4qzxbevt8p7/0q37u22P8VggAgFKC8VZ7Xdgce0NJ9EznDAKjAWmNkVm/R9rvITBsGFVsmIhoxYpebji0UHB42QCKZjMhSpqoILRCyErdCyJh/tVknT+fW+7stfbX1qu7zeO3RgDq0YoD0WqOnOrC0TcYqR6FLRHYwjkCo0tZFjlZUWCNqQpHLUJJGklEFCWoIETKFXUf4C4Xpvf8bmf5e728/I208z9t/NYJQD08Phh/gA5ab7OI06XTCFzhHNIfeOUziamykZEKKaVFyMg6iXBuNhL5+f3u0ocXu2nxMz/wN3T81gpAPSZajUbSmnyaDpLXWSfWCnxPguGDlWr61yEROEJXvDXvL10wt9xd/FXd9//W+K0XgHpMjrRGGs2xJ3ZyXVjEBinkJidcAUJK4awUMowlM7rofqTT6+7Pf33Z2/83bp8hBv+EqM/m+3/jt3b8v+W99fH/AbdaIL4CZkuFAAAAAElFTkSuQmCC"

WORDMARK_URI = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPIAAAAwCAYAAAArSCcbAABpt0lEQVR42qW9eZxcZ3Um/Jz3vfuturX0pm6tlm3ZbhkDFmAgEERiEiBmnZFJQhIgi5kskIUhC/Pla/VkksxkkhAgZGIzEwJhmXHnSzLAJGaXAQMGBMFYbSTLsqylW73Vcqvq7u97vj9uVXdLSGTmN/X7lapV2711733ec85znnMOveoN76zXARTBuM7SiLw0oiIQOksdAoDVNKI66gA6qBRCZ75DWRpRB3XU0YG1w+PofEsY5g4GOuigjnr5dhReTABQA7CexVRDgC5ClLcANYRAECDPEsK2mxlpEZsOG3HGppUxAMSSRflqFQ0z4x4A03IYIeA4W58v8pR6qALowTBtLj8BtHNr8z3VCoA+0Bu+BpR/G6bDGO5flDjsOQklkSccL9Kb+5ZkjCAAECIesHBzk8rPAYWdkGE63OuX73WV0LmzRlEyweVxCNEFYMYue65JkZVzbfi9eRaTabnc7QK5a1INIXLHovI3hhi95rkxbT4PwNOGzrOYzCjlDgAMz5VlewwAUV+JOlXVhz/0U4Nth5hx+Y1e/9YP+dmliNKq1LaTcCeMGQDqgUvAJCy5LPphIDoAJu2Mq4XU6/je2ziAnpNwmjiUpQOyegljHLAdv9zmGpBWBxQ0pvUKVlCPXcIagAnADmPueMHWvi0BmBkeS7/Pq60muyshn6tO857eMgFAtdriRmOG2+0lml2F/sRNM3T8vn+Tf+9P3H5jMTdX/rW4uECrqyfo8GFoAJifv/K9m0/QFY9XO5YEQAyfE8P79vdd+VnxfV678vvoKu/d/DwduefeWpZGZNkeZ6lFU3bGA9tjtFrIalJbUonskkNolJ/I0ogGtsd+ahHQAep11DslgIHO8Hvrl+1NkcfkuTF1h6BGEMBMcgaA9cykcSvnPCsv0E2wIUAPYQkcALljUZGnVEUVsZmxmWQcBAGigRaXQ7KEZWzabFoOx4OuaJg2F7lFsZlxkVtU2Ak1UocLO6EegGrkKSBEnllkjjucZwmZiTNcQLrCMG02k4xH+zdmOZxlCVmWwysDLdwhgIs8oTh1uDpaGOKMC7f8jBFnHFkZm5bLGB4II3K58GLa/n8AiI2WqKFcLIAACEKYSfna6DgVuUVTvtBxkvMgcrk89vXyWFekBgDPjahtVVVj9bx8wRNfPigpYQWzYGEJhmHYOssKkeosUfzYDc98/FLtJt3rKlGtSZ0mAwqyaZ0GIQHACJgAUGQOGVbCAGDZCY9A2gljnpqaArACYArpuXDzfNp2wMAK0tSlatWhnpPwCNRxNq23zt0KAOA6L+AnI5dsL2bXb/B5APY3T7B72x2Mxx8HbgT2pI6enj7AOHYMyzctU3t6ms4vBvL1ZxZusLLcVEXEkpmEaZJNlgGLJJjVp5q3PJrWX5kAwAKAIwBmZ09wCeKDBJzgbSCmK4B1zcXwKo/b73zF89j2/NVeuxLsuMb3l/85cs+9NctOeGSBy5Pj8UarhfKEOoSxcqVNkwGN3pcNgVwuAFF5soNxbYeFsOxs80e2AfiuRcVaTIbpsu/FlGcmmXHOg4mU0amj8GKqAYhERyCsYvs1bCYOIyj/k2cJublFhS82T7wztObFNosLALG5tQ9XWuTtgAeAhmmz0lJvX1RMy+XRwuM6JgEhNrItCznyJIrcoip6QKWKop2Q4wld5Cn1KlUYaek5AEA1BEwr4y4CAMB0xdDrazGVAE4ZdaDIbDIsl/3h83lWejSR5fLIswEAKdTmyRVGRUVxxqPFeHRuLDtjs98S//yO3x689i0/dN3re73FSbCQkgBTQhgSTIBQBVayAn8fFfvf/p3vPHnkX7+nYu8JOGxnIkttsuyUAcB2hsDtKtGz/c1jGzQsncYhrQKwhla8hPIUehOOHh+0CQDqUUiYAtLYJTsMOE1DwkRpoW075pUrzoztBTwyyb3U0tgH4CwwGfm611umanWaUQJQHzsGTE5CzN5/tPjHO1/T+EB4/sxeUwah1gARiBmWECikQEezPp3IAy8//uUn5l40ZyxOHmQAWFgAMHeCS+zO4xrgvfL/+gqgjh7lVcDG/wIw+SoLAK747u3gFtsXEwMA0AKqM1KnSwOybZ/XixTVmuSq71DVB7ABrI9t2bwsjQh1C+jUAWQYk1XVM5SoAMjsjEerdJoMaApAFgOYSIFOCtOqMxCjGwNGBwA6MCJwblQEnCoK1yIDpSVzLaGRbIF4BFATWWk9k4yTABwPKgLooYoqinxkHS0y4owRbIG8YWZc5CmV1jrjPLOpyC3qIYOZmVQLACRbR6sGIM9MyrMQAQKYAMd5V0BWkQHayi2qVoBevwr0garpMJChhyrQ78H0a1zNSquPIECOkJCEQ8vqUm2IzNzQIspKsBZZTN3h87VtAB5ELsO7RHlmESxXbz+jmWuRBbBlJ5sntmd7PJVGPPj6WaHsqvT7bVWwzi7AOC5BWiitBDNLItFhUVxy9uLQX37bjI/fp+NejHrD1Wnc3bTGqe+QPUiYdjSUHZeWtuPGrHsBA3u4imXAM5FGIXW8gG3EwNqKSDdBWRrb1RSYnCg/v7oGXF91qNcDYJfvsb14m6WbwXq7z/UdBuNhoFqd5kZjP3+rt0wWgIMAjgE4DGC5McM4CnjL7bRbUQ9cUMVUbNhEgiQXSnMa5QHkM32IShQWDADL/WWaPXxUzy8u0NzcyCIDc5gbQnn+am4xXwEovgKQ4hrWlb7PosBXccH5KtZ/9Jq+0iQZ1iBhNLeeWB/GOUgcciYC7raWRW8sYWAMaAFWM2HAQ4bO0DKDjB2eQLsEuDXwOAMIsGE74KWlAVV9YMrxOK1HlGcxDSyXjQkAnRRFbhNqgJVtWc8YgGFmnGcgz3J1DtCWxe0BsGFaDucAISvfW+RV6gEwPKHjvFe64EMQF3ZCDS10D0ABoJqn1Murpcs7dNMBByNXv4Z4+AiYVs65AwqHrrcBm4EMRgaCCS7YYcO0CAiBPKUkMgVMDMFaLj7lAhgiShw2Lcnl4gAauR1dxEBm0sgT8ZyEPC234nIrZUQuuqjBQ7zFJVgu51lM9cjlyC4XZACA30Y1LS+Sp964ryg+mCohhNk3jKWnu7/5Y/j0kT4ADSEYJABVyKe/8a+r04++202rmarrvTrV5zkuKlSvulT1MwKA9WRAthtwxw24Hm+5za7/OMeDCqVRSLYX8LrfZ1zYjfHGErA0A3hDp3kKqPZMbbsupfETtHtPhbOVgDu2tQlg128wLpyH5zX5ZLNFu/3dWG0NyL1xinGpj+MAams/oO+Ke/yJm05R5dhhHDsMTC6u6ZMnj4rJg78cP2/h7tddjp3Se/3q7c986HpDPD8d7vehYRg+N3uE5+dPADgK4CjmSwBfDVC4ikvM1wDmlRb1at9B3yc+vtpnr3TtR58lo3SbfMYGgCZQhU1wSneq20qF7fiMBNRzNtieGeM0KeOkOoDcswkAVi5ZqNeBKM7YnkkZSQI0E6Qt0FiziSyNsHIpIqAOy850RYfcD7UoXcEIsIAsSrnQNpmqT6Zfup8IQ+QICBngQmjHSaidlz9mBJIxy+GNLCFjaG0BuyS5hu8zzIxzLThHAIQh3PGajrOEiigRjif0KAYHQnRDYNzawUCO2ibQ3CHeSnM9IplGnwGcoRcANswJ7mENhim4yEHl/lRhmFvbqMFFvumXBsjXE0pdJluFejxxeR0mmYnDkZOI0bby0KTCi7kGYFBpag9ApwMUiMmIXLbsjNFuI2s0KC2ktjEMk+oAHoc0yJYkBCQzns3fNP7o6Anzm2FI+LVfK/fq6FFa3jeTGZCiWA6M1L1I9bpAPbCQpn1K09LFV1VLB1mbAiX1GoApTMGbjtEOd8P1wa7f5/Poww6aPInzdL4dsD1m8WS7RemuvVzXQIw2rawAU6gw3CmsYGWT/BzdzgPY3fTJDsC9VoWxb0BoAZgFDi0D03f1+NixY6icROl+HwMweRAAsLp6gu49dI95z/62XsACJlaZDt90iHDfcXVcGiYk4AlPA8DS8ZM8f7wE79zcUWAeWDxykGYXwPMAAXNXs8r/ErCvJLGuRlTR93HdeWhxr2btr7TOm9sx0Cxd5zQdUGY4BESwHcnrAKpoYWJsWjj2GDm2Sd1OJoAmsjSmarWCzDQJQ4aWg4ZGrwfbLjhNmxQACKeBLI0ptxpkZhXuhpFOCq+wB5IRDHSWgiqB0NBAH1oYVspZJNhfyalbA7zRDwhKELQHTFvsscO5k1C2jfE2TJvd3KLeyAUfgS4EciekEcttwmF4iTYth5Fkw5i8NIdddGFEKdfrLueZS5uWLwzJDALOL4vJGYaZMGDBtBxOkMG1alec6Awjoq3qWJQn5uUvB8CkVdNRkpcxeRACIVCFBQvY5PgBoAsAWUw5gDpcXgeGCyiARgNAG1Xfpb7QBABeB7gBgBIFD2NFdapiq49iRiCYQYol3QwDEhVNWIchhbLqe6SVsrRMSaYqOtLwLBieg0JptcvgPIrzzNciqbJVrK0t66VeXbn+eXhBk4Em7LPAvtZZrPSaug4g9rYuwl0AHh+6zx0EmOnFmAIonRAaaCAetAk4D9sLebU1wCRa5IXA2RCoRv2h53gcx7CEfn+Z7qpMM3AYxwDMzoJmZw8DOIbPLN6plxZO8PyQyDo8uZ8Jx/U3mLVixkD0GQAOvwiYfxDA3BCuc8AW0QUAR7m00nQ1sH2/2Pmy16anp8XMzAxM0+QoigQAmGsmH18+fq3FQVxje3yNGB2G7fictgZkz/icCUVWlHCagJ5/6zRJ1yre/jN3R1esNFdj4PgKv52vvoq8wZmbO+ykMy6dXxooy064N/C56ttk2RFniAj1OrAWb3MdQ+qGQUk6oabzUaopKAHZyxIq8pRGqaZeGaGisIgRZmUKJ3C4PUip4WwtAmaSDUFcWurIyhkZKM9i6kNwsRZvxbCZSYAJIIQZGaJMVYGL3CTAGlpcB3mWUJQ4PG7ljCzbZMGBZJNf6A5TbrWwBGyEgMd1yeB7WUxDDx/WkBlHMmS6t90GQ1fbiFKO1iVnXkk2WnaD+2EkOgDMHR7XEdHpG6GKJFQ6L5gNQ3XZU37Q4LWlp0RQmTB0kBtFyzCnndhVUlclD2qSZFUU8FkrG0gFCVZSikQT0opv9guoNouoPyWcgW95aQoUS8jIDfvsBoZ+6PEmnnnHNJ9YBA5G4FXvrEBrAA+A22xgtTXgNGpRz2vy5MRe8oIBnz07wG3Bbv148TjcoIlq0+deK6ReEMIFgOjsEBSH+SQOAIdO4RPHQfv3r+nDqxN07NgxAMDkkLyaHxrTBQDHFhYIAHRRaC0EKypJwbUHJ3luWwoKAB58EHqIaABHae5K6uv7AxhXAaBYXl6OlpeXr/a6dw2LfiXJdS1PYBPMRprYhOYAva4SaACGCIR/o1/89pvv7gOzlYWPf/wFu3fseropzFvqY/W669oGFJgBCILQYCGINABoZiGImACltSYiQXGWZt1OuJGmxYlTp899+2d+cu67wPH+r8/dHySr6wx/oGwHjFaCzAWh08HArLOXtUR+mQtbWkwzCRjBlmttWiWxBWTDeK2mi+H7R6DPs4Qapr3JIMsAqCFAlOTshSF1AbhRygYEF7lNJkAjinjdiamWmeV3ZRYK02IDPQA5HM/WQAZPS40kB5wMppY8iFKu15u8nsWUJznMPqgXlLFyDQG6YYjIctnsKwELZeoNAQATCMPNXwzLYVPLTfY8z2KKLJet2GPYGbIUZO3wuH1paJABDGyPJ9uAFSVs2ylmT0BIU5MVF5RlLGuVqqHPDaSEAUpZSml59UpRhc4nhaJpFrxDaDWlocaZqQJWBpgyIj1gjVCgWLUllljzMirWpSr320YexXtgZ+cGFR2nS4QbmwwAB2eB3sPLNDl7UPceXqYVAAhCnoymedWDuLgS8lrk6z07QnID4JHwLAH7hmdpGdXmNDeW2/yl6Qa9IHW4vdigTzROUWX6AFdOLvHhCnBsdYmOTC4yVmfp2NC1npw8yJgH5ubmMD8/z4ePDPNMAtIWIHe4hYkXrdLi5BGUID6MBx9cY8yduAy581e3jPQvWObL3vdHf/Rnt/m+a2st2fIrGnmOpbUlvP++9z557ty57CqWWF8jnr5mDG0ALaDZRK/V4utoXEb1LP6LX/lV8a1HTv7Kzh0Tb65U/Ftd18L/1W3PTgDALTddp5cvffKfnzq/dt9zn/2vPnzPPb+qm5NV49Jal+E7oqITjaCJLI1oNRW6PsyLmgDMWg7ARRc58tAkzxlZyzI+LUGd8QjQTpaQs5lgwuZC0LQc7m66qSZFMdisAUUMMsyUDXPIHndjWndjQgZEVs6GUdFxvyVqgcN5Zm8uImUcDzItl0e5XqAMYmueDdNyObJa3EyGTFbgoBYC3Sym3AIDGUzLZRM5IgBehjLfHpZEW5lDNwlJzpHl8riVchR7w9SgoI1WC76nKUvLtGEDQDZjUZQpkamCcOyElVduMNZ7J3p5lrW7lX9O6/XbRLFu2LYvvCqlE7oodhPRDQy+WRfqJhJityFlXUjhCkGkmbVWOlNad7XWK1rhCSFxgorkpBT5UxYqKwij8KZqnD7kB7QzCNBrLePcpWk+WJ1mLJaM85kzbcYe4I7ZE4zFg1ir+jgIoPf4kDS7sclxCJqMfI19/uahnMCEnj55AtNY4tlV4NjJA6WYY/IgTwJD/vrEpkVeWDjCc3NHhrHvHLC4CGABfcXdtUz1+2l/0yLjyAImJ4/wwuwxPvLgQZq9DLxH+Spu9fdzga8EvAJg/8RP3P33jUZ9fxTFAAimaSIMu1ERZ7f+/u//7oWJiQl7bW1NXyEC+Zcs82Wu9jD91MJ1vikjO4tvnTCnzl341l/v3jl1GACUAheFVjz8SZd/kwCzJhLlU8xM5VdLBjSYmYSQzKyhNZPn+jIIKrfvmBr7y7NPffZV7//ox+85+9jp9R2332A99e0lbdkOZelFAhrYFQjdDzvCMMHFkFTrDk3TuJVzbjmblrobhqUBtQAzcTl3TOohwZiVsRmWJEruhFQF0A1HpNMwP2uN4muXixwExDDMlPsmuF4RXKzZBKvUupi5y12EZMaurtWAPAw3Y+hNZZPlcidykQ9VbaNcMFBaYazkQM2FuS3FhS4wPuHyelaKZsYtl9czEIZ57fGheGbccrmDFBU7YcBHb5DwWHOG+mGB7bn7ijZ0piRllSbd+PjXjZXp21b+NDRvJ/9i8paDB1V0YSC9cc+2OR4HixuI8XStiudJKW/zK36zWq2QY1swTRNCEJgZShVOmhXBYBDt7vf7B7Msv4Wk+Aqx+LolYgOBh0udpDMee5kLH14IxN6AvH2AvZyp6ekD3GiUOeVjOIx+4xQfbDeo0WhzbwcoDgPaFwIrwRRjXx9YPIFGY4anpw8wlk/R4uRBfWT4+xaxhtVZEBYXMDt7Py8sLtDsg9CTRxYJWMTc3InLzOlRzDLmID68kP+4N5DeJfv2VeA0nZg7ygvzwNzciZLWmjvBc8NYeW5+HvM4CmB05W862fy/4fput9jC9yva910QQTODLMsiKUlXKj4B0EKIq6WarmX1r0acsdz/vNe5gZSyNrGjGHS+G/zqm37ik7t2Tj6nKHReuscQVEJVMCBAELTtDiIBkGCGIJAgQYLAAqDyPWABQAgiAQForbUQoqjXKjfduH/Xj37i09/4B5FNF74jZORIRuLCshPuh1qMmFetBlS1iLO8iqpZUBeAaZTseaZ97TsmmSxYFiU82tGAvEIhtQPABswgZyBFQypYLNhUBUWWyzXU4CCFAyDPTQhpQoyZgJNg3BIaiQtmB8IfAIkDIU3UHSB1gOoQvH1pQjoxSd8EUkBKE4kDxKogZ+Qn+QVF7HINgApc1qoo1Vwp4DhANwUis6AagJobsFYF5VJDSj0KmcuQQA7gAEhcFzYL7nSYDMEkDbUp5JFGD5nKdLVqwZPMzSTWVK2o7Jmv6RUHnpaMrfQt7UrPRzFFEDcx9HPA6qWu4zx7ZucOf+fMDhofa3AQVOD7HlU8DxXf40q1gqBaQVD14XqeyYypJMlmAK1YUN8yaGBZMhbSyru9iGNDUb0WoDXYYL2+iqLI0J5ukNtP8N3zWkRrE2La/haSZA9llT6Z51IMZlKcu2Tz5BrQaJjl8e1vEACc238GT609CCwc5YkjC4gWD2J2FjyPYzgysYbFyUUqBSKzvDi/SBMPTmDxyEFaOzhJE0fWcBiH8c6//dvoa63V8MgvHeHJyTWx9hcP0pG5iZKtnjxIixNrOIyjODx/DPM4xpg7SnjwGJWZagB48FppI/o+Ci/x9t/8rTc7tj2WZTkDICKiJE3zzz/01fd96cHPtoMgkP1+//vFwdcSimw+CqADZ2KM/vNvvTp625t+8j07ZyYOFoXKicgkEoJLWwsGayIUREKBoZmhGayxeYdmggagQdBUvl8xUBCxhqByL0gIVWgzz3W2c2bq4G+/7XV/8N/eeXd3/OZ9KtVSV2tS247PlUDoy6UZpYZ7sM36mbbLhRtTFyEGlrtJCo0P/46SnM0k5zw1aXt6owQxsJ5FNHKzizwuJaed0vpmqUPtkdIt9rhex6YE1XNMGlna2iig7W5Z5vpwH0ZMs6ebuhR1pBz3WyLPSuXWpnqrNiS6cPkvHt/2my6TvraBdGlAaALVmtSWnbBle2w7KdsDn1PfGQo5BtSVSqTJgOSFz5vywqLZzmH6thVoU+wG1K1aFT/ouu7T9uzZKXfvnObJiTHUahVyHIcMKQECCyHIMk3yfY+azTpNT43zzpkpDoLKDAO3C43rBFRDQjrVrCdnpst8sBcM+Mah6zs9fYAby20+Zydiz45luuFGwJvdJzxvIOIwoKk7AgKAPTuWCTiB9vQSleTWEt95Z0PjGDA7ez8vHrmbFhcPUqmTPkhHhn/Pzs4yACzOL9IsFnjxyCLNrp6g2dUTdOxY6aoeOQJ5BEfk4vwiYWEBs3P3lyKQuaG0a74kvjAHzA2JrtK9xlAiMoerkFJXpoT0FXcFZtrEHWFoBQV831fb4mF1DREIXSP9tJ14ZmOX25Sf/MJ9/Q//94//6E03XPevldIKIJP11ndqhjZNuU0ELv6Pw+Q8V5qIxLZ9NZXS6ob9u3/ivfd+9C+Ofea+h285dGflwsWEm2iilyqybHCGiAyr1BLnmU1WFpNvuZwDyFOTPIx0yDFFWUxZITTqgJ/ZNG65vO7GVEPpmoYpqOvEBARYBwAnhKGbXGQxjU+URQdFFpOnPG3ZCU8B6KcWRVKJDGDfs8l1YooyRbkoD66ZZJwVQmNccgUZ0AZWXIvq2wAZ9VsCAArPRS0rGfloW0pp2nI5ykrpqusUFDlxmTIbSkW34m4gGklifQ/VFIADzlKHqrVUp8mA4AN216EeAMsG95yEbc/nDFJXI4cCL3F0njdI8B4N/UzHsZ++e9e0mJme5Irvk9YacZKi1x8gSVIUSpGUErZlsutYsCyLTMOkSsXneq3K/d5gp1Z6JteiZluFBdcmEfR5Gg21iLOILgGNOx0+u3TC8KcnjKe7jqTOhmHbi5RZJuFABeNZi8zUUTt2OkWxFhbrs/vUPpzVx04u8fRJYOHgAg4fnkWr9W5zdvblFIbnaRCE5IcBt4KQFxcP6tnZExoAzx6BDHf9upwNAsLshOhXYj7c7ysAxezsnMY2zdbc/FHMDRcEYBFzOAoslMDd8qSJMDc3zFHNXysdxFeQVJcVQzDzZc44E7D5HMCWZekr8sJX02rjKq786FEY140bdPqBB4pb//jPftqyTM4yxUQAEY3uWgiI5Uur39rohB8Lu4MnXNcJsyw1R5JSIVgLIVkTiJllnmthmkLnSVyfHGvs8fzqa3bOTBxUSmsiCIBARMQEDqoV+dw7nvHGX37zT3x97o5Xm1wodclZJUQBIitnz/E0kCEPbdGo+cIer1EVVWRmQugDWWYTZnxYmWIODB2gKsNeb5jrrmIMPfSX+ojTjHMrYC9LyLU1xWnGpgU2h3FpB4DllAKVDHUad5WoBb7Img1CtQdiJYApWFlKdpaSWwk0+gNYlsNValBqtxkAUopJpRkXuq9Nq85RvyVKzbjLhpWyZ5Vsdm1T2O6yLoTcMVkXlUoVlpVQlu1mjAOW7XCWJmTZDgM92JnLYRXI1mNK04I1DL3e6sOyPe51LwqggZFMc/RoD3zGALDdmMeEQ5YBG4Q6K72XgFsnxprW1NQ4Nxp1IiL0wj7WN9pYWV1DGA4KzZwLQYbj2Ga14qNa8eHYNiutOMuVYGZFAgVDbVEuYZMvANjRapLx3EJYZ2CpsQkXaeSbmXakLV2ttW1lmalFhwyhATdOOMv6Rt0N9xVnB/1KJb7ttnPFcppqnDgi+pWnzCZytzA2XK9pWnZhSztIdQCnwOyJYjBA8YxnPENlmWF6RWYDrgk7QaVfFGZuxrmZ95aXl9PpuTk1Pz+PYSwslpdnqIE2pueO0Mzyfbx0EowHoefnh/Z3bm6I6fnt8hDCMEfduOcewvFSJnby5LS46aZlOn78OI4fP74FXdril4CRZ0oki4KYmY6++c0i9H0CgAu4gNVvrspaLaeR1DILAlpbK6jdPoMzZ85czVqz0TMb2YFDdzUatdrzSnKKBA2JOiLWQpB49Lun3/m0W278zaHCcYsk+/7VIGLoLiig8cePLH793qfdcv3rAK01Q2jNYGZBktBsVH+g2XyOmxRmnmexNOGyWTG44WhOk4imp/bKJ9prxXv/4/8bA08V24Tp28Xp292U7e4KAJi/+IcfrlhhZF0sPG3mQJEDAyWlL5XaWbGKQSQYToLr65Oix65477s+m2DlQ8XwO8TwN9MVbhRvc6dG+2Xe8Po592WzB+3OUqy9SlNBA3ktJr9rU44YtRowiFOuo47pHRP06Ye+Hh//xHw2/LyxTRRPw+9VV1n95St/9r9aO3ZX7P5qV0X9AMaExYgxLGFM0CurkggbgH1dwN31WExLtlnJuka+yzKNqWpQge/5ME0TRV4gzVLudLq0trbR1lp/g1ksE8iOomRvGPZv8lyn4XouqUJRGPYHmvFtEuJJYqNdaKSxnfIGpAAyMdiVyKn1wrMcbiBFUxM1SGEcghpEuqaVcJkKEqCEGD1ArUMOVnN4q06CNXN6uq/SIN0XheTBd2ENxkWhpyBFIMnyIDQxI2c4ie1jUBQiB8g2DKsCsMOZZoIYRCatu4a9XK3euL6Ifn7kyP0Ks0d4fp6K7xuPzs1hbmiFr8gnMwBaABTuu6+8xo4Po+gHy8cXAcbkkfvxpTMfFIIkmAE99HKH9Jncu3evQUS8zUH7l240NjZWqVR2yaee+vZlKSrjw//0ePr6171sn++5O0tmiwUIYNZaCCmefPL8N592y42/8eijj1qf/MqF5vqZizIdc9jKik3gZmlC1rjD2bpBll0wqgCFhRhAC0NLa6Oo5K9703/+3c/9w+/9wI4dE7vyTGshILTWJIUBz3H2ve5nX7Xv+Jn2UxO1inCkTNMkpJxMWdsxif/4O6/t3Xnkt3Ys/M+/umPvzh1Pq/j2TBTFNQCsmAUAEiWatMpzgEgZQqh6s77canVXzl7ceOSX//2HvrPxraX+z7zjx6vtfqdwbdIwc11TY8p2Qi60zwdmAvHbb767C9zkv+/+d73wlr1vPzTRrM30+4PJQilBTMTELADWzACzBpEGs7BdO6341fPnLmxc+PyXHvv6773jHSd/+Jd/1bw+tgw0kMuGpbLc0pyRzNZWjeldE+by2Y3sA+96U+/fv/N9N/7er335+Xt37rheqWJnkiQeQCVdqAGGZq21JgHyPb8HiKUnzi6d/cfPH//CvfM///jPvv2/Vmu1zFha7gC2h56TcjUBZUsDmpnxueckHPQTYhJCFWRKFD5rPek4juN7LmzbJCEIeZ6jG/ZovdXKtdbfEIZ8EFpfICZiKca04ut7vfj63iDaBc02CTpPQjzCROekMtaUzBIn8XnGARpJ22SgalnGJCR2sVLXs9Y3MHAdoHaSoIAkmwCx1jpizW2QXiEWFwwhTmvWjxuF/dQEsAavrVOIwCz0NDHdzHl2i9LqOmjhAxgI4mXJWNbQKRO5zDyhWdUIIheSzgvFJ4siLcxxGe5YahaXsIDWw39lvuMdcwe1FrZpmvB9n4RlkUrR/9u/FYt3HX+zWpyfp4USxFwy2SPWHLQA8M/93M9N7dq178YkKWBZggFT+74lY+1cWkwnz3kYiGLVFTSyyFRmAIpCocgVfeELn+79m5962+Trfu6Vr63X6rPdsD8jBJFpmiWPLIg1WNT86rml1dWLjz7ynW/92q/94jc2NjbaN9xwQ3D69OlNgBunH7iXr/+ZP5yqVHxDA6wZBGYwQ0sJsbre/f+Ymd79T//kfKtzIm1YlgzPhyJ3bXJTk+IkZ9QALA5KcT/qyM/HNGGlqltuJD1wW8X8wMP3nnnq/C/+044dE7/ADF3G/ERKa/i+583e9oypT9/3z8t7XzgpsjC2MgHRYJn99/e9H9/458Xf2rdr5ucbjdoe8X8anl8P3P7MAoeff9uj33zkib94+Ut+6SNz7/wVanVCnSZV6sexiELPqDie+dtvvntl4e//6YXPPvTM32826i+sVuz/Yy7g+ut24tDT9w9e96o7/r//9K6//t3p6cNLkfc1dxD5DAGRFJn0Gk3rc8efKF522859T5y58PaxZu2VQVCpfN+M5RW3m2/aj+c/52nrv/jTL3//r/zOO/+wVnsaGtO2pSOVZ5lFG4C2bJ/XsYHAneawv4Kq6UPJQgqtbIAc0zTh2DYbhkFEBK01p2lGWZoPiMQFaLpELJ+CaSWscp8YSyRwkhgTLNhkEhvE4qIW8mzfQNvsp0lRqKLmaekgrgLuLgV9s9B4pmJ9hyHlAce2a57nCtM0IKQEGFBaIUszJGmq0jTrF0VxQpLxWVBhKJkJGfHAtmWdFe9joheSoBfXg/qkZVtIkgRRP24XrFZJUU6ALw2jbkvh50rlWvN3QFRooqcoXDKaYUjvWVjgl7zkJTN//sY3fmp8bKyZFxmkEGTbFi4uXVr+yEfeeHAeaB85ckRiYYGvbDhw7733ioU3vzl/7Wt/4hXPf/7z3jeI4kIQG1KKolr1jEdPnPrE/LOf/spvfONe4wPzC0ah7gVv81eFENBaR69+9ete/+xnP+PXxsYa0//S+b7plhtx+zNuw6te9YpvPvrYd//wFS+/828PHTrkHT9+3BgWTSwqx7WblmVA66H7xltu8xNnn9p47nOehrl3/Q2mMIVeElOeKUIGhE4pXER3k4tBvVMKz9b1uPa9iGwnYbGaF0SkojT7dik/BJgJBgHMYMd1aLruO6e/9M/dH33BXdW4mutdE1P81Qc+Z3/1n973oQMH9r2kzGlrXSjo4UJDXD6OKIVhOHAZO8goGUI5NTl268vuHPuLB7907/UvesGz/u2f3H+/++DXnzRsx5BV13M/8OFPDj75+a/+6+ceuvXDQdW34rjgJMm1lGJIT5RebWmIefMQEXhrm2U8RJ7n+wdnKz8z/45feM4H3v+hH335b96xdP/vPFbtFV2yGhX77ONr/LMvufnAz7/+ZR8dG6vtYQbyvFBaa9aay6/jMldQ8gnbgiKi4caZ6rXq+PhY7e0fuffoD7597v1vavdrYaPCsDqtwpIVTsfA2ABSJ6SJCRc2YrIgweUiajJrpFmGPMshhQSIyLEdOI5T6fX7MwaopgVVoVQOiISIljUVHc3Gk1KKjLXuaoFOVohugTyK7aSQNmQ1N6s5zF0m6BlEeCFr/YNBxd/VbDZQ8T3YtsVSyk0rBZRgTtNMhr1+7dLK+rPTJGUBYmmQ0KbegKY6SdwA1rc36o3JmekJdl0HeV5Qrxc14jhuFEpDSgnLKiO/Xm9gtVqdnQSMQYlAiEmnf6sVAdCOU0e14huNZpWSOGXNml3bJc9zhVItulqPkKF7TY2lklG3bVvW6x4cxwARoJnJdWy4riUA8CEcwvT0tNaKSSsNrTWIBDFrOK5VOfyi5/8nx7URRUmhtSLmMh2EUaaIhyAkYhAgJcl9+3bevmfPzMKxL3z1Pxz+wef+7v79+2tnzpwRxjCSlNt8d4AA1hBKaRB4YwTqS+dIcqHK9EkARAm4hu3sah2RnXHPyPUeL6I2AK+jRbPel8xshP2B2hSObG2PmYkGad8EFjKNV+un7anhd37p7u4ji4+/58CBfS/RWmd5rk0hhBiRZTz8wURU+tUosUbbaAACgTVDMZBnhYIgfv5zn/m2+//+ga/f/ZqX/o+5P7+/cupMWzxxpsdveONz9jzrtpvfF1R9K82KQkoYAMlhXKOJmEvyD1vA4iHIthY+qRVDcc5Zhvy6vTtv/lf/+tXvuY1e/zNv/g+/5QVpN7aqXvLkdz+GH//j+947NlbbE0VpLgQZQpAUQgxPYFkQLzYXpZIgGUXJ5dOEoiiYWeS7d07e8Y5fe+0fPP1pP/uzr3/Hmx1ImaJRxhpV36EsNcWgE1HsGTKwGFCUgdGN41QPolgkSQLTMmEaBvyKx81mw0iS5I6iUCZBfIdIPwmNdS04FBkG2kJLsezHQvY7RdqTsBI/yDjUFTHV9x1HRpNFwbdo0s9lxYebzcbM1OQ412tVmKZJQhANRUJc/jxBJAiu48G2HQaEubx86TlZlkuhySKSpyBgMWGMQHXPdbhaqaJerxJAaDQSTpMURVGU54IIaZpxkmRDjkFnw0o/o3KuIgFCrTYFpRRnac5FUTBrJm1qSCn4uuuewYuLi2XnkG1gHgH6xOgSkzxkm5mLQnN5aTNoKFkujZalhbiMPAYzwzQtQ7Pmfn/APOScqHSoh+leKvFL4jJtWb/XV5Zl4Qee96z/5/3v//Ajb3rT6z9+ww03VAUACDkkhViX1kaPzAvDsZ0cACVxRKNOIKblMsKt3KdpuTyIUrbiUl1kh1qkSUSj3GcPFQCgeBAZI5SVwX9JADAYWkECs5YttPM/Pr9u/NFf3v+c/XtmfgGA0hqmYUgiKt+vlFaCwKZpwDAkpCzvhpQwzPJORFpprfTQagtJkrUmQwp+1jMPzj37h395bHktd6aanvmZ//6W1Te86ofe1GzW6kWhCkMKQwixeeBt2xCWZUjTlMO7IS3TkJY1/NsypGUZQqkS9UIIMgxhAVD79+95xR/8ydue9+DnTye33jau/8vvvL79l3/8m6/cvWvmGYNBUggic7g8gJm1EKRM04Rpbv0uKQQMKSGlAJiVLg8aCCCt2cpzpa7bN/Pqd733F2678NCuNc+1yIo8toUSfRGIsptLKSlVykpJiA1BOJkk6aUwHCDsR5ylGYQQqAVVmpmewN69u+pBUPkhAn5cF8VrGPqHiOhZbPKNAI9rkblGIWkiddlALoTWYue6Mhwjr6pcTUPrm1nx88aajZldO6d4crJJFd8jQwpkWc69foROt0etTpc6nRCDfsxaK3Zsi8aadT0+3jSFELcw814ijBFpH4qlICFtyyHXdVHxPQTVCmpBQEG1ShXfJ9uxSQiCUoqKIidmPYDmEMhCT0cRmssFwEiRQAiCEGIobygNATMoz0vGeGGbVZ7bRnQdHDGpJU6oxC6NyGgYhsFDl4DVU0/RpmERhHJzpQeilAJALIWAHF5vQghIQ8I0DZimOTR0rIio5LtJyDhJAICf9azb5wA4SZIoAwC0UpcTdjQ0l7xtKWg0YE0vc7bs6KGoQtSGXvV45DLqKbJO2W7Gsj2OYsCDRR10EGQBAWBBYou22yZMKQ8omcCEZQWe/OeF/9L/i7f/5Ut83zOyTBXlQdqywJYlZZ4rdHth6ZoxgbeT5szw/YqwLANJUjAJJmZASiHzvOCZ6clbfuYnfuSH5v7msa+89gX7zampl9jj47UXAeCi0GRIgdKVEcjyAmfPrn1jEEcXGWrosgsJJoMBFgK5KQ3h2NbNU1OTNyilIEQJTaU0+55Lz3vOgWe/420/+dnmL386AEC7d+14rRAoLbwoIxmtFBzHFkRAGPbLlRuA1qVLBi5jq3q9KvNcI89zCFGu34VSXK34OHTo1lf86i8fevC2H/lv5sn1RCHrw8xcNpByoYW2E+TSUT0t8mUS4jQrfWJtbX3ctkzLMCQ36jWyLBONeg2GlOy5NrU7valOJ5xI0uw2VahVBp+Gzk+YJE+aRnwWll6qodbmDZEVjrYtHTeZea+CPlT1/Rumpyd5fKxJtmUhzXJ0wj42NtrU7vSQ5VnCmtkwpO37ngiCClzbQqG0UEoD4BhAwsQMFiazdkFkCClgGBKGUcbZmhl5lqNQCv1en8Nen7rdHjrdsEfAGYAvCaXbPe5k9uKXCgAQeVEQEY8W7HJhLD0f0yxVZUcA3H0FmLcXURh0OasxugZVocrnq6dITQ9jI5QElBYaYiinME2LbMeS7U6INM3AWgMEmIYBIQVYa1i2Tb5fkf1ej6mkzUAkZBTFvGfProN/+J/fedvvvP3Xv2gMgzDayhjpbUEnkVKFBIAkGlC2XAoGI1n2jCpBnDLq6bBrpk2WI0SmDQ104MGCn9k0LNbSW42miKGBLTYPECwYOFtMBMiAL/fqQeXWraQ5Q+vSbxEC9O3FMx959OTZj26sh+ulTJMtTZC2IXIuktyD0jt27hrbv3/nv7n5hutflReKpRSj46Bs05LX7518RuvBD33RfMFeOvzq2ycMKfYpBWLNggUgBGmA6aGvnvjdOw+/4X3AWh9YToYpLwt4gQVcUsDpYcOJA9XHTn3yr2++cd+PFYVSzJBFUZAQJixTHASQnzmdmnteeM+OIAhmR+L44W/Utm2JlbWNM99+5MT/u7bRPZUU0upFha2FJodkKlRU1HxLz+yaec6ts7f8XqXi1rTWEIIIw1Blojl2O3BDYNoTbCYXGChLHVlWFe2xdHQJAKyISa1D8CnJNJZkWXNlbf2QbRskBLHnumAGeZ5LhiHhex6PNWuiHyWNfm/Q6PX6+7MsO1QU6hRJPCyYv2mY0eORTy2XY0soOa0F3SKlcdv4eFPUa1W2LRuFKtBud3H+4iW0Wu01rflk2RWAC0p5oj9I9rTa3XFDGh5DI8/zkEGLQsilglUooT0SyIQgSEMMLVsJQK0UoiRBu9vD2uo6rW+0oizPTxLRI0T0CNh4ItV5J8+9zJ6d0KX0c6C3BWLbpBcCnpfTleC9SjkjICVtGaZRhhjQuqwHx6EDvLwMTQBvXusoSUXLMhAnafTVh7/+h6dOPfnZM2dOUVEUolqtZjt271aOlCKOI0xNTdZ27dx1z+zBW+4uipyFFCRKMCvPc4xnHTp0K4AvGCVq5Qgul2WEiQiqjJ/ZSX2u1pROE5uQRrrs2wUgqmM9i2kcLq8jhpnkbCInwAYsDCWGGgA2AwfiK7RoDCiVAXgqdxQpALJWrU4OY1ISgqA1K8sy5BNnLnzqGQdv/Gk8Z64yZni8kT6hsJ5qTDdLSV8ekD8B4/QDfxYDx7/4+Omnjl+/f89NWmsNQOihOzQzVfeAL4WovNp+TnP3mGGYDgBIQwDELKUUKytr3Tt/9t+/b/qu/9A/fGDZK/LER6UCM0iLvCPLOtAc1WrV8e6b/0T/a99Y/MRNN+z7Ma3LH6h1SYQ1m3ULgAkzT1707H2TvueOlSFN6WcJIsRJwv/wwLG3/OIb/vU/7n3DnPPUB1qMvSFh3BZTzSqtrACvfNak+NhfvfZrn/78V3fcefiOfzcYJIqZ5IhzkELsRGWHvdFTuRG5qASGzvZpbfctxqWyE0cUNZRhIJSuXmLmxyTJ2qAfGWeePH9zrxfZzbE6fNeBaZlsSEme55HjuKhWC84bNSRpavb78Y619daObi+cJqIqpZlfkXi8UFow0ZRWfF3Fd5u1WgDXdQlgRIOY19ZbtLHRusgCnxKG+A40rQqoQkMEgNih8nxPnufjBGISvEZCnmUWpw3WAyZMlVk/pk1Ss0yTIklSdDohX7i4Qu1W+0kwHjak/A6zeoKVvqAtfQm50zpwYDn7yEe2KoFLp4evokJ0Nl3rWYwEmlsw3v+KV3BJY6srign5cnXFsdHlzdti5BLrhmHJLzz0hf/wype/5D8OtQN8FYXY6Pa5k6ee2H/jDdc9q9cbaCFIKFWUXVuK7CCAIdk1NAub+7PJ4DB0+Ro7bsqZtrTtpMJ2JKfJOGVxRLkXC8NyuRN1MG7VecRe+1m8qUc267VSDyqYr1btRQTIcjERUloagCtEKY7WalOnygDQDqMv8P3307t7FfuRcxeVle4yUCvLopwkIoRAxxHylXf+29rH/vJ3V/tx8hARbirLpSF4GC+kaTYOLCeTySnd3PM0wzQNEgJgCGitwQwkaYp/99O3z+7dGXb6yvcNnhQsC0U6K3SgWQhBrD2DTOH83h+/Nql6cmZ45i5zuaQwCTjkrXS01XQML8uyypazwWzZpuj1+6sPfeXJb8zN3V8J0bXCX9+FSmBox804icsY17O0eek5b6H1du/rWaYgy6B5U9lnO6axa89NKoCt5aTi9Q2F2IrZrphcfwLkXR/wxvkNUM3IxyxjwzDV40ahQSTCJEnPXbi4PLu23pqpVDy3Uq1QxXPh+x57jkOeYxN5LrRWCKoZu56NCxfoxk4nJCE4Y6VBkDmAfSC+vlr1pes6bBgGaa3QjyLaaLVyZv6GYPEwF3JRFHotF5QbBrlaqDGSYtIgbigFLVi2ClWsG5a3LmO2lSw8ZlbbcaK1hioUeoMBr2+0qd3uLAH4R0H0VWh9Ns+s9cJSISz0uuefSOz/eJ/Ci14kRhX9zJsZmm1GRcGMtpoYzl/eFvfyd6vt4ShfZgABAIcPD6k3UJntKKEmpZTtdlt//tjnP/eWt7zFfvjhh+2nnkqU2GWyznOqp6kAgMFgUPz2b/+2fOtb39pfW1390oEb9z+LmbXWEJsSao0dALRxGfpHaY9teBMls8hRUuW0coHSNXDqD6gKB5bd5CyNNDqdYRP7rc7Wm90sInfUHkfq4S9k8Igb2NYyvNxOXhUKQKH1cOUV2OauSGgyQ7r7bvnbf/AB7SEqWoMI3DVlJFqiCkBpqSsDmdkVidOnT3OaJlmZuuJyfRqpa8pV0FxcnrF33igdKWnriGtQlhWYGJ+ove1X3/qZ0Vq3VW7GxMOYB0QshiutlEIqpUECYhTPD2MjAiasdpJ5TbLMMhbnMmm/lS0r1nqpTMUqdkyoIgmAoqOFEWoJBCi0oQvX0F/rX9Km6SVlKoMuO1cEMEIgTcpKGttJ2I5dsuECT3cRXQLhFldzv10MUhHXDWNFiyQnITqi0BcAfDuOk/1xnN6w0erscxx7YnysSfVaFUHVR6Xiw7Zt2LZNtm2Bmbgo1P7eYPBsSVQIQsLg/aaUU67jwLJMCCGQpil3wz4lSbYkgG8zyVNaq3PCMrpZpJRhmFLofB1Q5wHDgxIkLZmYIo3yLMuVpDpQqrCIiBkMrTWKvECSpuj1+rSx0Sq0yr8pSX4LlD86GOSXiKKBZ3n58hPLanp6WpX1ypNlJ5nCou/tY1kalu4on3qtRvTHRyv0tpd4qMXc8rSxzQHdNLg8vPgJSMdrfvjv/ugP8omJCXNtbU2P2petlEsEAZALCwuG1ppUXoSlNy9K93z4rYZlFtullps7wHz1SqqBn3EjMnXkulSFQykGyNKIMjciCx7DBXU6w1kHdaBj1dnPYvK9uHSzAVEUejPtxNgyW1oBJDaliMP1Q8mRcyDE1hGnolCj97UAZJ5DZqhQMyoqd8tm7ytpRBW7wgCyJC6ZcjFMGW3+PMUCqLnwG75WZIAZSjOU4s38rSEl7KAqt6WYyteG/svoNxDKFBgzo1B66MwwSJTxkDRIAo/2n3NI9s9/I/TBTFISlNpa5AvNFEURgtoBhBgIo1MWieQ1cJ6GBAEhqC6wBkipimGagy6PhUBqSgoAyvdsWt/s653R+mNlD2pgBTW42rBzFUYiCTynJanIC2n1BOklEvmTArQIxr44Tm+6uHTp+o1Wa3Ks2TB2TI6jXq/BcWy4rovxZp2yNKPs3IXbszwvpBBLzDxFQtqGYUAKOQzPNLIsh2ZuGYZxMVd6TVdVJzJF1kLEQdPJmq1BAiCMPE9mkSGdQcI9J1cSVdFEoVmQCU0mayatAaU08kIhTspFIo6TdSLxXSL5JBBf8n10AK9YXFzkUWXUqIcXABh5JraY3ZERIxAJ8ryp7yvNOdM4Q1fiZvsfI7d3cwrEZjpqK30JQcjKHhi0rR75eyqdhsQby814vDQjzJuU+bbGAqTV5a7+0NIIQpxlmyMclgC4cUiW76DsggkG6kAjQ+dSOT7GijyO4oimGhlSpMgzm3TV0ABUs17nrQUD0GAQE4QBEIQEZs1BJzGB/SM6fzNNdWWfItt2OesmlF2yyPTKiqJB7PKUyrhie6iSOWw/pL+XKB+miIAaQQ4UCUdvRTObtg0MRlEUhRDEzEzbF7rNrxvmeFkNAU3lGswMsIYSQthhLxoAF+LfOHKE3vbVd6gy3bGV9C9pRkLDNilNQhpPM8pEhSInhLcsdG5XtOdG5LFBWDuvTNvONy/BbcQpkaAp16Y0GVA/jEXVyFXP8Xl9s8F8G7gEyMqakKgawteWzsmHKRyDdKEVOgQjJK2WIOlxKfBtDd4TDeKnp0l+hyp0jQGMNxtwPQfVagXNNOVON7TX1zYOMGsBRp0I1mjdLcUzelS8brHWpqtMpWJXOY99nYsg4Cb2EWYcgaVceJEikcQcOWV73CaAwlAsy2JZg0zavKK1LheIKE6glV6Xgi4qVbS7EtELDx7MT5w4wbMLs0PneB7Y7BYCWJZJl6dlNhOjl/WVudrtxNXMNeurIPsYYTP1v6U5GKaSOFYxbQMyXa3nneeVHT/10HG+UnBvGOao1Q9EobibJAXKRP2mC8pEhD27Z6rMTEf/7B8MrOXFBd+hdAMYn6yq1LMp6xSENjC1Yyej3cbAbgENB4MoYUDw2GQVTXuCiKgIqu7e0eVLWyshaVWg6vstIJAkLQ2cKUYeyXBN2Tw2RCQBUF2YGk6uxiYlGUKKfhgLRCkXk1UNAI7rieF6KEaAFhCbRKOQBOCcNg0rtUjoLfKeN4UxZRqAjP+LJkfG8qW1i5/9/Nf+5Ed+7k+adx9dwG5vh0tErBVfLtuTguF5iAwl0AVi5GzCBeDCc0GANewCYrNQioYGhFljJPUCMwvbKn+vablc6BzVZEC243MPQFpxqZGYspJZlhWoqs7EGHQ6CS0aRJogRV+wbkMaq0rzRYJ+Ugh5moQ4X+SFbnU6d9ZqVaMWVOERwTQNOLZNruuADFFlrRsAuyM2fus+WnC0By0qysncMNfWYN8+jWWg0zlr1eF5Utq+UrntBA7MmHIpnQEgC5tNQ1GhmEgBw5TRUDyjtUaRFdCglmC0LYjICIP8xN0neAhfnsNc2URvu0keqeSucILL56rXPKFzc8Ar9u/n+e35ps0lQF9RS3SYDx06JJhZYlvp4ui4jMoXN1nurZTRFrDXSwJEXEZn0SZDzsNY0cChe8T5Cxc2+v2BrtcDoVQOZoIqNME2MDMz8TIi+qu3/6dPeRw04uvijDvVDgzhseoU5GcxQYL64TogAdfwKAhzVoGj7chjgUKMj0ti5srYWOOHS6ZNCyllWSpkCGq1O/o7J0+3Z2d/VCVpXqZVtdo0OJuaRQAkiV70ohdZ5zuRgeU+o+boQktNRsKVQEBlPdkBsDsOiJnFVx7+ZjKKLYa11duW0JsNTWQozYVmZqU0tGYIQTBMiW43zJ44e+HvPd/psWJiDdJcCsYImnlbwTiBhC4ZaEWsNBOJtY3upQ9+7Bt//83vnjvz4udfb519Iox4otCjKpgrs5C2Il1NE84cj3KUg9s6w2YH9Xodtl02E9RSMvPIrdqe7yeOpcl5ZhHQhVMpp30sJQPaPyG521LC9NmwLLOKQu9i4hvIoAOa1Q5oZjAuKvBpCXVWWVhHRj1Lk2KpPQg6lWf5obwoJgBmIcpOEaZpwDQMDL29hITIVaGSLMv9UmnFMKQBx7ZAQlSZaYIVTQXgfgA/xDQAFBUhxFjO2QwRxinLTSmpr0W+AsrXNbNBrN1hCfhWexohwMxUqBwCKoIwsizu6aB1noEPjHJGNI/5snfXFUjeZMAxOoQEzXrItINmV1dpDnO8eGSRFhYWMIc5nl9cpJlXHMfc3JzQxeW+4ghc0pCbAL9w4QIREbMuxVaEMpuhtZaWZQlm1jMzM9u70F5WZ5wFGTGzeOihr1wWj6uhGkWpMqtr3HPPXeZH/+Yvzv/4kVcujxu1nXkOLSUJaUiplNZ7d0//6Ef+7guv+cnX/uCHnvvcX3dv+9EX076ZMSwvAeNFh2BU0G5nIvVtAloIg3FdNUJKI5tWRCG+++lVdfLLb+r8z3/87Fv27dl1u1JKSyk286dCkMiyfOXTn/r2pef+2NNHVQqSrmB+R5GpIL7lwQcfzF/+079u7QyeoYWISYz3NTCDVuGKdLktxyyD7viBmzMi0t/5zmMzo5NGRJtkl2E7ITBFZC0pzRNZoRRG3ggRWApBvd6g9+zb73grMFgdlUN+nz7Eo7LDfHgHAOc1b/tgcMON1znL62Fq93ZHenw9G6XUtiUMyji5MAiZQ872/j71cuplnsXUCwMAKW1+ji//jhLVg81+ZL1uJgAHsBPutpQYF4Gw7L6dm/mk0LgBOj+kme+QJPZBELHSy0T4jib+jqXEaa3VRiEyKclsgFGDgDHa1ohzKEUVRMM4sANQrJR2w7B/YBDF8DwPpmVSNfDhV/xmtxveYQrZ0oI8A7yuhSawrCvNO8H6ema+TgNVEqJNjO+C+bRmNSDmcYaukjDl6Mooe4lpFIViZkolUUFSqtZKwM3LFFlb/y6OUkyWTqQ00u0aKK0UbNsOgslGhQjrr3/fb8kbb3wZjt93H9155504cOAAHz18tGwg+yzKH/ziS3dvenvbBPFZngsAOPrGN5orKytiMEhUrVYbpaBIa6U937N3Tu+eJKLHnvz85/Wf/t3f8ZNPPil7vZ7I85xM02TLsviOO+7QRKS/8pWv3YyRdGxLYwKldAwAxi2Wsu770gMb/f7gWwBmpBR62KcLWmmyLYt+7M7b7/3aNx69+dFHTv7Pz375Y8vHvr5UOHaDPM+VlhmQViapQUGAA0edQ5IAQjhipll1XnHPrTuede93X3fD/j0/P1JOlWqaoTAV4E7Yf+TBB97TOnznhz0IOwPGSIzKnIYuiVYscyjet3fqde//m0984k0/fdensMXu2UDDLAHWjgCoPwX4Hz7+mR/fvXvXy9K0YK1ZCDkspADQ7Q1CoJ8fPlTNV7696mdZDtM0kOdFWdysNDfH6v4fvvu/TP/OW39m9ciRucrXVs8W05NNshHIPlwpexfZsBzudD0O0lDl4wNU3GnbsitWq9Pn7ncfVt/8xmfDw8847HiOS4sTq+4OMpyRVnzT7SzVsTBqBfe6HptWjwMnoDAMyQeQw96a4IZx0koRo0yk8eX8AbmORZGVsZfFZDckD6KEZ4bTEl0ZkzS0K1TWIOa9mvmQ69hPH2s2DMcyEcVxc6PVuSHPipsU8SNkiAsGhNYFdrDmZ1cCr+G5DqRhUJn7V0iSFHGaQWnVI+ASM3dJgPv9/ky326v4vsee61LF9zA9NS6KPH9OHCcOCN9SRMtaSYOYd2pWNxtS7jEMsy4IZpbnA8VqWoACQXwBxBVo8giQw/Bnk7NQSmsIUQBAIQ1uVpt8ubByfkvVsQgwzwmi+Xb2n9/ZF4KmmMFCkMjzXI816+7Pvf7Hf+Ped/2n3zxw4OXJNTxs9Ttzv3/rDddf96aiUAxmybSVIs3zYgUADt52G5UDU3rprl3T0JphSAEmsOc6+OHDP/jbr3jFz333uhe/eGV4HW+veVcA9Kc//Wl88CP3v/TAgRteniYpgyFIEIzS6rMQtAgAhgj7GgCfPXvpf83efP1dUhJtFkEzKMsLOI7rPfvQwX+3b+/Of/eSl7xwXUpKy2LZkknfLnApyVQmIQSKIndsyw3qjQryXEGpMmVSajPKR6WZHj978X8AyFd6StRmTAI21CjDN9KYSimoKDTXqtXGK3/sBz928tST3yKIS0QSTJCCWEghGaSHPJWemZ6eus2xLSRJzkKAtOay97bSuLS6vggcH3T0lPvg10/nP/8L1CaCS6X7TXlaaNdxnR9/1Uv+6mk3fuHP+kmyejfuKISWnGkYkFJKeQcLzax1pgGlsjxnwEDOWthSsun8AHVa/d7CF5883bRqThZmJgWGoVlDqWGpGW1LUgxKLr4GE+uXzZgYWhE7IWCdi60V7kq/gERisu34bNRDnUY9th2g50muRg71oERQZDYBVRB2CEHXNxt1Y3KiqR3bpjRNYTu2vb7ReWaSJNcppTsMZhKiWvH95vhYE0FQgWkYKJRGHCfohn1qtTqaNR4lgUXBPAChXxTFno1W57ZKxYNtmnBtGxPjTQBkraxuPGswiK7XWnUIICnkWFCpVscaNbieA601Nlrd2vr6xgFmXBAQPYAdQDsASOnSj2ddHkfQUIU4SnrMLpbB7Giy4tywY/38/NCzPiyA+SJO0iUi7BeCeJiFEINBzLfeOvuWU4+ffakq1KlRgo9IgCShTE6w7zjOs8fHxqpxnAwZ5eHCCqDb7X8HAGq33ioA9CzH+rYQOCik0AwWBJKDQYzdu3a+9N3vnnvkD/7gNx8l0rHWShBJlpJgmhaEAPJcjzcatUOe58k0y7n00xmstUiSnE6devIpAIZxutXCz/36+xpH3/ORfzh48Lpf2bt75mCS5EoIIRkl8FRRcFRAB0FFWmPG+Perm9XD0qsRQ5fnBeI4U2V1z+ZhQVEo5fu2PP3kuUfe8Obf/ftf/MMPV7rdbi43egawf2Sty1yrGC5XhqAsy7jiu6LZ2HfoX2KaikIjzQoYUhCDoXLN0hC0fGm198kvHvvsW971Lvn4t3q1z3zsm3HynmIRwLQubZwUgkSaZti3Z8ft+/bs+GCS5lt62ZE8bNtxKAtA9LAMrWRBgqqPJ86c+84vzH3ylT//Uz9MOypJAbQ1gTTz1rEYuR6FbdBYAETCZU+nnFv25hby1CTYGpiqlrTHSMJDeisGYeIsY13ToUbkoz3Z0MAK0Af5yYBSMyfpuQQUBlRBGjrJshxFocjwJVlmBYZpwvc9DAZxPcuyOkCwLAO+66IaVOE4NpTWGAwitNodvrSyRlEcnxGCHtHMJyVEX2l0hEAtDHtja2utnY5tcRBUyHEcTIw34Zale428KBoAYJkmXNdlz3NgGAayNOUoSggkLECzZp0No5e+1lxopQ2lNdRQhz4kfDQXZZzZau2g5ns2uWqamy8bA2AemF1Y4BMn5iSAYhDFDwF44ShIGXpJlOcZ79+/90YpcOO1rq0kzRDHMQspSQ/jXymF6LTD4pF/fuyLYKaz932cAWBpZeMzB27Y93pZpj+GhUmMMOzpHTumJi3L+qFthW64MrXV6/URJwnLkqGF0oot06RLqyvtj370ow9NTMAxWi1gsgm8/Nl/sfqVh1/2i/Va8PmK74k0KwohyCjF+kRgSNYaaZpxOXFWXyZw48tS5jwKoCCEICmF3K4vZ+bC920jDPvZxz99/O37nnEYhk4MM3bz3I4J8Ech2BA0ApcRX8ycJBkP6wowKuHky0kkIhJCDIsSCAQhUNiWYZ6/sPy3f/Unv//Un3/+85XFY2eLWm2XWjx59n/s2zN9Z0mEshxVosRxpqUglqJcTphKMow1b20cgJSAYZjbUkqspSThurayrUzAkFkwpUKK1vqlZnxbmeIQyB582E6Hk75JA6vOPuLNvtiOUGRnXinpZN468rwtx60Zwkg58WxyopSDfkhJpMmCgxYGmOSaZoojA3oVAmc041S3G05almURgSu+R7ZlwjSqqHgeK602izVM0yTDkFCFQpbmGEQxL6+s0dpaa42YvwSBRRLOU5nOB4aQA8VFVRDGV9fWX0yExmQ+xr7nkWEYqNcCVKtV5qGoRUoBMbxI0yzjTtin9Y02tFJPSSkuajJWibXLGq1CqShJMztJMjBrKoqcWWsmrRVIFg4KHZYQ3iSNykZ7m0248NC7381zc3Pi2ydOfXTPrum3O45DWZ5pKYQYyYKjfl/zkM4Uw4tqdM6Hsa4wDINK9SNQFCqvVn3ziSfPffrtb3/zN//x4G7r4aXj2Rvm3u/c98Fjn7j5+j1nduyY2N/phIWU0iivGSnSNOE0SfRl3tm20GsYD4thldbIiOSe51oryyt/88Uvfur8c5/73KYgq6Ee7XfSfuWD7k8cecUXv/XNR9/YHwyU51rGkE8vwKxAm9Q4mPX3qFSJL2fvRrpSLjVlWpW3gpm1bZtGp9sbfOYL33jDb7z597/0vGdcb51bDfMOgAhKACFvUgdM2JK3AbZtEhHpoYchRncwl323h/8nGjohw80zuHAcy1y+tH7+PX/1T3/0S3P3VxaPncDa2qD/xl97NX7sR37+g6cef+pjtm2amrnQWitm1gCT0loUhUJRFFCqDBFK91ih0BpKK5SF46osyxy6zkMhhE7XH9y48Zmyexb7Cmm4VOr8lR5+vy5JP+iMtEgThypBOVJ1EKVsDlviJlbGaVowVnqaQEqPbsy6/InQDLA2alaRCpkkNiWRQ8BYOaC+KXW3S7lR2D2V0kUNPkEQX85z9bWV1bV4ZXWDNlod9PoDzvOciVCWhUoJECHLc+73B9xqd3l5ZQ1nz12klUtra2D9EAjfIjYeFxavwapvaFEsGUwnBPMXWenPLF9aXz53foXWN9oYDAZcFAULKnP5RIK0ZmRZxr1+n9fWW7S0tEL9weCUEPQ5Zv6WEHxGs1gWRCusdLvf71PY7SLs9nTY61Oe5z0IrAE6KrIib166xHNDV2czSp4DFheP0OLiIjXabd1sNs03/uSrHnnk0cfmPc+WlmmCgAJgpTUzCMTYur60ZoGyXFgAEEN1mdYaShDljUZgrq23Nj75mc/92/uPHMG73/pWzM/Pc9AK+aP3/dv1T33qc7+0srKhK9WKoVkXzFqVQBLDguzh9zIEMwsuW1gJIhbM5baUKhQzF/VaYD1x5uyJ9/7N+//9oUOHvMcee4yNFaxgClM42Y957t6PeS9+8fM+9JGP/M+lF/zgs/9gx9TkHaYhxTXn0PHVu+7R94622vzfYJBgZXX9c//4uS/9zi++8e6vzd3/+cryiVN9q24KqxWKsfqeDOgr3h47brJ0jFar028265XtLu32noJCbIF+yJdtbvvC0uq3/vyDn/qNh7+TtQ4ZqxWzI1JrrKqWcLG49xsf5D9751++8Tfe9ksfvH7/7ruuFT5c0dn0ewR8I/JSFUpKKUBEAu0zaV0IgbUTTt6suI5lurZtXCasKxS7ncGl3N5xqODVC3bdAndQh2l1ynE4WrDpOgSsazZYVqve5nlRCkIIwDCF55jKXB8kRWBoUqt9LSeraoeVqevW+gQH/GS/EltNa13GCiyJSQqllB6srreeFobhhO95pus5MA0TYijl1kN2OM9yxGmCaBBnWZ4+CdDDgvB1LczvFJmxHCVFKPqd1DQrmbI7ZMPUEJwSeNBqtV6YJPHeoFoxfN8d1trSiHmlNE3RH0QIe704z4rHBdFDxHRcazqlCxWx5AQCY9B4rNMJx5VSNcOQFHb7A6X0NyTx43lBXeEhw+ysXgRobm6OgXkcWTxCWATun12lhYU1cWJxsZhfWCje8paX2i9+0fN+7ysPf8c4eMu+d1SrFQMAilxBleV2uNzF217mW8Zf0hAAIJcvrZ78wpePv/Htv/ZLj87NzRkPLCwoAPI97/lVvu222/w3vOHHP/mhDy286kd+5MXvnpgYuw7DNFRRFFsdQYZeFQ+FDCU/xCAhYBomkQCyrMDjp5/83Dvf++5f+Jv3vjes1Wp+t9tlw21rkTohuzHoy/2T/Fv/8f7aT/7k330ZlT+96yMfeMcLZw/s+aGg4j/dMM09BNRNwxg6dmXcvf2CLzvcjqSQmgBCmmaQ0liOk2S50+098uh3n/jkm37yVZ8FkP/sf/qH6vHPnFKukYueVKKaOlQXtgY2CtbYlFBJg0CClCCSX3l48fdrDTffu3vHEa1wvWlKKYggDclCCAgS0KxRFIqiKFGWZT4Z9ntPLq+2/9cPv/59n565cV/2Qz9yvWyv9lPUgDpamIDEox94zF0PrtM3Pv1Xf+6/f/jXf+y2W3b/aKMR3FTk+R4CpC4HIJWCmTKRPGq4zyPBymY6RGlirXWl4oqNdqfl7X1D/ctfSDA5sdYiYGNlfeNErlQ1zxUXSmnbtNDphivjXlXLfod6lstWnHG9blGnU0e9Xkpfw16Im57/Gmt5ua/OX1x53JCS8zznolDsOpZYXd841+59tXWwuV/bLc9IbU0FgPVbx9Wf/NxvJgDhrt/9L97BEBmE11JWKmyOlQStas2PRlF6UxRn18k2NYUULiDNcsqIhmZdaKUiZl4G0RMEcUpIuahZPK6FeUkpEaJZJOsYZ9Vfz3YBbeVpIgaT4owIG1E0uDmKkr3CkJOGkFUpyQRASqm8KFRXa32egFMk6THWfEoLelIb3iWOE21KTVoVF0jS17TSnU4nnNEMQwIXhaQTYH3OEdQdJG7ebjdoFnN6cXGRFmbL6+hFCwtEoy6wcxBH5o/g0iUU73rXP9rPu+Npc3/5Xz/y8efcfvBnqkH12QDttS3LK73ZkRD38qKIoiRuV+M4O7l0aemB1/zML324+9S3O3NH5qz5+fliu7l75JFHknvvucf8qZ868okf+ZEjX56b+42f2rlz153SMg/oIt8hiEpymYaSP+ZNKTARkBdKGYbxZLvdeez8xYt/94qX/+gnANAQxAqAoJe+/l3B/hum9draKqq+Q4ZQQlJFWLbH75p/TW9IgxuVG17QeO4zZ93JiSqZyiA4gMgckUuDtSrIMAyS0mBTFVRy9uW/Fy+2+LOf/VIb3e/0hq1d5Vvm/tFPk/PU7uUqTRyyDSWytGxKMHvbATX/Ky9W584tfWX37umnp0mmhZSCiJVhGPILXznxb170/FvvBeC86KWvGb/xthuRqAnTKgwrhyWEVJwB0HFET104l3/1439xYbQzP/WfP+jLC8qMljLGcHqhZXuceRFFoRKBK6VnV+V/+8M/6QHHCTOvdl7yA7uCemBKpQzKi4Lz/qAc8iZIsDbIMA2CBYhCcoYUeb/gJBsUQBeGbAg4k3CCWxOYeTG2Kx14WCs++eGHq/bYlG+Znoi6l7JOfymfqs7woWe/oIissv+1FZejPzPXIivOOHMtKrKYPMekXmdVHn/4nyWJhKOkrTGQ3O/1ARP53FvvSpeXZ0RR60g/cejxl70s3XX0Fyb+jer/oTKM7tsar5zfd3B31Ki0JTLYkx5VCirGtFJTxGKGSU8z0xgRB6zhAtqgsml1REJ0AFwiIS5qlstsG5d0ITu634ladjO1W4kCgLTpSAO5CGy2pUoCkVETKCaJsIOIprXADig9waAqAyRAfRBWiMR5aH2BSFwEaLVrim7U8yPXiciGqLhIxwHsUEBTSuGxJklCxSrjjmXJi0mSLK2beffkMWQPPjg/mh1M9wB0H4CPP+1p/88e173pH/XEO37n65948v677xYLWMBv3XmveNab37w5/HPHDc+Y+OE7nmPA95ClGXsAiqKgCAMgApTqUTfLxIMPPNDdruc8cuSItbCwMNrupsxrDtDzAL30pS81HnjggXzba7XnPe/Fdd+XnArBQgiuyCrL6lBQEgFKKfru2SfFEye+sQ4gBoDbbpvyL1zIZavVGg1DZ3rp698VoAnsV1Inw1Ej2ACMCSVcx6LpGZ/jxoRqVuL879yXqcljC2I0AM87MRBR2KLVoMmjYZhR2CJgN4BysDV27cLMRE+sL3WNRqOBM2fOICrcIhSZyJIBWYOEbaMuLDthNIEbDt6m5+9+sX7qqaWv7tkz/bQkybQQJAAUlmUaX3zokXte+AO3/dVf/8OxamjvjL/58EMEAEt9KeWl9mY9SlyT+qaJ52obq0bzBqDV2sCTraio90NKY5d6XSVsQwugjsIrARIlOaML7LyxJqerAHpe0e97+QpWEMQOYQII+zWemKnqQbhOUb9kldNKlybWgNCt8dQOYOUS8Owfvq7A48DXz33VaC/3rXzKHE6myHn/5D4FAM2Jvl4D4MY1jvsWrS2fkkADWXqRLNvbXGy8xKLIKdsoZUkJ7H3XT2k97eodK0C/b1HkdSmJLEqXz9PATpgLU7pZTA/+1m8MfvT1z9n7DtDJLrj7UvvG6/74ix8OTxw9KsMwkDoQtm96rplnVS3TKljVASMgJk8LbQotmIRIhdBxliM2oPtKUo/JDrVwo37WT42wyB8rDA0AdzSn+ezZEwLYh2azRUVgmBULNmeqaoMCFEUTBgVMygWEVUZPKlWgPgl0OTc6Uhrt1DEHrWQlbQPFjlaTVFOaNavryljVpZQ2YFgwIZQ2cqkw6CMMYyCawLFkfv7BEUPKRwDcec8h8eb7vpl/6Zm3P3Jj1XvaAx2+6Q2PfOnUEcBaGMoi5+bm6BWveAUdOnNG0913q/9NCa54y1veYoZhSA899BCfPn1aX9Hz/MqZULRr1y65Z88eAwDOnftyceHCZqHQqB71anOSMTs7a01MTBhnz3bw1FPfVtuESFx20Ww2MYYWzkglxpIB7EHCGBtDoaXe6K/rjVMSQXyCFidgTq6918TEsKLm6wPCOFCNxjCBAa8BqEYOVY0CjrfK3ZYSq2gCZ5/A6tkWMiUVzo0EUjnZANuQnGKMqgW0My15bdmUaMZDbekVcelQTpcWBRGR/vU/uV8MVk85gVPWjkrhc3rDUFmTODTmeGLQekgUjs+PPzCgOJO6Vh3IEGPl/vuKsjQC0EENNkxt6Ag51WrASicrVjqdsjCzDtNLPC6qMdJORDpbp5XTpZZZAoicjL1ORBfNOiyjzb11IDXa+NKDZw0vichzPE4rUmetfjnE3TKwsXpW5krqVisRaAJry22KpBKQgBENGPU6sk6HkJRzpzppB9aOss2K5WRsaY/PtlaEdSGhtuNz6g0IF8p5VQAwoaZ16CVKqtA4fSP0S2y7aPX6BbFeP2f2i8/cd5+wW00Kmy1W/UpuTUoV51kqHSe0U6wbBduwtAFlEbFilWkF6eQwtMrJzJIcuZm082I8KC6tF9prNTneB3JbIT/cWiYETa42fQ5aIYUIsnZrXe00giwTSU8I2lAg27Y8AS7rbqUiVaSi0K5MdGxmaRplSQvZ9CNQd04uMnAEn0nb2prOipZE6qfj0rZjSqXLbIS6FcdqAsjuOLio7r77wW3F+XPAkYP0qP1FAXwTzNxu9XrFuc5yDoCGxQ88B/D8/Lyen58fAu+IPHTojACAOI6vmWxdXFzk97znPeqKUS98jXnKBIAuXLhAFy5cGAmZxNTUlBhprUePo2oorTWNZKSLi4s89GivOhTCsAYp98Z8IBlQlsYE34W9AQY2EGJM2E7IoRsw1soRotVoQMAY1uFgV5TwhY0Nsgc+7OsC7q2FsF3BWSUAWm1soAXLSRgbY8jSgbDsUmFU9Ush//oGkPkDSgGkLRAaJtJIS2CvGAnaedgTdKRPL1gLAMJ2c+5qqQ1IvhA5hA0A8Nn2Ek7XJKVIkfkgawMot2uLrsqFaSv204iyah2dNEK9XscAHUbHhYGUB6ijbgEd1IcgtWil06HCswk1GwZcro/qrjuAZQPtWlXZ3Uz01hPuNZuopiDLTjhKPUQxADRKP2lY5jmogwexhzwMxGRaWlojcrnwYrKMlogyl406hq51REjLwW1lE70OrCDhqvY1HB9pMqBhFAPLTth2fIa3ig5MDiqxAqAdKYU0yGAS5i59vZkuHcjT8BhWbmjyFAJ19pKvG4FSxZrMfW8QeYlDlCrR3TbGSOVS17SlB17CxbKp2zftZ1w4D2A3VoJl3nc2IOwL6OzZclT5Ciqlz9kKOQ7HVRq1dNwI85uq10dCZAIYUJIU5Dg7eQ2AEyyxXoVerzRUhCk9603oxck1xiroGE7g8Cx4eXlGAYgvTTeo1/oi7UlTfXJ6mnEMmJxcZGD2sgTo3UcWxeos6JeONdV7wEgKDabCqKSl1ZsYWuN5zGEO87TVA2QBx49vqgZxrcqkbUBSVwD2atVM4orvYwBYWVkZFUtcOWlRX2PCI22bbjLyQLWR+QOyNny24HM65nMvGdDMGICNMexyEl4DkMYh2W7AVntZwC/TGbuaUq+tAbbjs+0GDKzAdqe4nHq4gp7TYCQDsgc+rzoJJh3JmEiQRg5tJMBYMiDbcMhOHawML3Wko4GDkvWwLkxrLpsvjPTEmgiAtGOT0mSdHE9y1FUCBuBtSJ3CIXt3wun5AVWVr1OAsnRAoQ0O0nFtoxCABXQA29CiDujOlqy5HMbY6QB1IEvqlKHsRVYDkK/FZFrA+hB4QAdZCrK7JYNsG1ogXIe1bZJkllqE+gBIt5ou1DuAD4sGUcbY1gPfsFKO4MKwXPazLpnRDu7Uy/JQALDaGVt2uVr3ukqM5juV23HIshNOkwH1BpJTN6REeASADLNCUvagifhWoyNnz3/N9KM1Dr7e5zCNaVDdS08EddUrguIJSJ7Myr7OcVDZvBjdsM9tAB6aHBycYpx9TGDXbsQn22TAkRt2Bjfs8z40+ew+wG0BcVhOWJyMfH0CPvbYy3Qia+OO5jQ/3BpQ3Jyi21otDpsBPX7B4eqlFjcaAe87eZaPATgMEA4fxk3Lp+gYlvjw9AFeXFxjtIEqXog2gMn2AmYPzzLmZzF/ZJGOHLkfR04syAUAL+j16AeWl/Uh93OCX/QifK7VsaVlYaI5w1hZuaxz9fy1pytea4g5X2FxR4AUVwH6tSz2lYDlK7ahrzKwja9oa1AagqqSGk6Cqj+gnufz+IaPFDbZYymXkkGgmgzK6X5jZfzcg889B4RkA0FjutyRS0Or0M4ERAO7vISTchg3drsBh+1MjEclVseGFx4apaXZ38Cw7BFoTBQFcEYNTbAu8+2MMucKskyTgL0iTWOyHZ+TCDRlD3g456i8DReYNHEI2EBc83UgB2IG4J6hOHMjsvoVYQ1HrdYBdOqdIdA6lw0xXR8KMrrDgWvYPhoR9fJNcYZRq+DtwMrScipjpwMUuU11c/T5DgovpoYteWRlfU+RiTpHKtMeQB3LYSvI2A9tMehEWzsUe7hyO9uHtm3ue+xSKtcIgM47K4pVAS2peODh96898CV8j4zopX/2v+wprJDbCtlrNnEybNHusMHxoBxODr/kPaLgPG2cyITr7+Y4bFO96lKnEjOWhxxJs0X70OSz4QoBgBuEjH0+9jy8TNgBVC+1eDl1eA8cxnKGS+0W9YaxNZrTWFw8QScBxuGy59Xy8ik6DuAuHAaOAbM4QcdwGJOTa5u/9+jRo3wUR2kOswzcjbsXkI1mu2zdTuOLh54JwzDQ02XhSf/qQ8qvdeNRg/qrxMD8fcafXqvbiLhKM4GrFeNcmcblq3kJRscNeApAbwBU4VDqD8h2yjd3pRJVx2f4DlKAqnCwWaQ+AOD45WVZibneBwEryBpTOvBCSs471HMSxgQQns+EvTvh9cih8aHhteyEs3ZpRQYR0HMS3uX53FKZBA4JwzAsAML1bMEayIuyokQXsQKeSmJXO06acCl6AKrDecEAkEFy6jtkI+DUB9U2ygPQcxJGYQ4RUZTg7LdEdziLeDAceVNipoNOp4Pxep3Xt80urmE4ozlKgXoHVlyOObVG407rdfTREXAjII1KMw/A6KQ8cjk6AEwldT+NCPUI9Q7Q7QK1WkyRBHkoGzZkSYe8aNi8YbhwZC5KFjuNKHPrhLRTMu+pQ9VaR69jDNVkIHoDn63y9Ai2xkxKVzMHaDz0jNv+yMtVwqSIbNuQtmXkueaPfejP//TYH/2v9cmP/akZhT52w8cIxDMAlkaAPlmB6zfKOdD9kLwK2FsG2n6D4wHI9RschSBgwO7tU4zTQ834ptjxIL7ULi/CFzTaDBxEtQl+uLVM1UvTPAsAkwdFY7nNy/3yE3dNH+Dl5VM0ffgAHzv2vag4evQoYf4ojjL48OG/tj/7zPovjgP1WGsSRQEoEtKW2jSNaS0oG7NLkvIugI9fnZi66gC1+VE8fTmo6Bpzhuka/+erLB58FYDyVUasXs1rKL0ut50JNCw9ASDZ2IA9NrblrjWltqMNWt9AaXnFsrCHli9NBhQ3hAZi4AkQpqaQVkLCSOw/Vi4MDhJOAKSnlUhnwGX3ikBY9jAFNDQ24xtjCHWb/U6of/jV/8r62okLv7a3PahwodICQJJkUto2vnvmwneOzN1vPbkUqmqiRFlp0MRGszWkscrpClYyoJ4PYGNjy+30x4hWe4Q0QuTZXHNM6oZbhUX1Th3rXkzwgE4HZX9uJwMyUA3AuhPTOgAzAeDZGIfLhW1cDmQARWbTuJVypw500EG9U0enXhJXQIZJeBgNUZ+MvXIGtJlyF6UL39mcvbM5dx2TtsdZp0Md1DFpA5VA6CzOyAoE98NIWLbH6xtjwBiQKaltJ0GWugL/BOkFFVu021YTujlFxttZDnOWUsKRBtpaoZoXf/XgYaz+1H/TonN9e9PC1qshLfWCsnrKLy20LZ4SXi/gKCqTL0tA2QJhCPDVYMApWoQW4ALsnR2IXlBeeL0dy7QHQLU5zVguu20cXATWGo5Gb1ksVg8yZgG7lYj0HkfjOPCJT5yiu+5a4mM4gH5/hiqVYzw7C1pcPMgLJRNER44sgOh1+rnPvcOrG9mf3mya6OVc8uJDXXquNfq6gBFr50qQzV3RKfP7gfkaoKJrkFyXsctXuOF0DZf9agDW2xaN7X+XrLW9O2H02wjdKU4nyvyv1VIia5YywUwLHTTKOBmu0LYbY2UFsK+vaxsAlgF3os8AhN2PGZhC0s6Es7t09bqnlbBnwEgAu6uEkWqydmRsOQn7iUPtoSXpKck2pvBYFKvpH9iVvPoltx/D5WNcJQCevmvOeM2hCWvNA9vwh7EiuJo6tGEnPIYmgCX0HPA4fKxjDDMz4DQBIRkgs8t4s4AiM8l53HKx2aO7DiADyq6gLlw75LEIQODobqiEq4Wud4Dcw9ZM5aEVNrAuyiC7A6NeZyBFvQN06kBkZ2zFJXj9IdgbtscY7ssoQDcAHqADRO7IcYdle1x3O5QBZMHjetqhLK1vXgD9UIt6vY5Ch1wtShO8njhkOwnDqKgjjy2IpFq/8PVLF99oSDaTVCiQZghA5iAr06QLqU41962/9K3/ZKYTQrthA/CBeNCmTi9g1+8zsBvxoE2u3+BOD0A1JEQARuPHgvPAhd2bP8duNXlfAKwAWAmmeCoEncWQCAtCXj07EL0g4YOzJ7ixPMM4Duw55Oj29AkCDl7W5O7QIWB5eZluwingEDA9DRw7BkxOAliY5SNHDhKwAGZNBw/e3f+ueeo15wpRTYf6QFaaC9JsEAypFH1zUKxuAyWXf185xPyyTtbXstbf73nG1UWAfA0LS9dgunEVout7QgI68kt/XgHKQdheJeA2clEduqvOIOHQLcG52d9vFCFWylX6xqDBg7BNUb9ktaeG740rIY3c3pEFH8XFlpMw0Cy757VaqN0wJM7cmNPYJdsNuFEhKVAIAMgcqxwM3gVWVVysb2xgfKy0vxurUqLeQUULDTRRWsche4sN9Dyf7UrA4WomqsN9yNyIiszeHDY+ml01crE7wzQP2sMQYBiHtgH4bkQlQOub7xnF+gDguREBdXQ6GLbm+d7vaGyPcd2IrNjjzI2oooUuY+tycbDijHu2x1UvoiyxCJspsTpGjQ4rQ2LNHvic+gPqDRIGxtB1Et7tln2v1vccLB749bvSyx25y0nRl77lf9nxMK6t2plY9/u8+7LrbDeA8+XQkaBCS6NFfGilXb/BuHAevR1lPhmPA/FUQPv2ASutkKeaJaM9ips7RiHqhaGrzWluLLd5+uQSf+KmGTo0xO/3lrZtPTs9vcQHh9Z4dvYIA0fF4uIizy7M8lHMM/3vxbziCiv4vwNWukqe+Gps89U+I74P+OkaSme6xj7jym3//3IyYEXBRr1AAAAAAElFTkSuQmCC"

APP_CSS = r"""
/* ---- app sections (jobs / review / settings) on the dark shell ---- */
#appzone,#settingsview{max-width:1560px;margin:0 auto;padding:0 16px 8px}
#appzone .card,#settingsview .card{padding:14px 16px}
#appzone .card h2,#settingsview .card h2{font-size:15px;text-transform:none;
 letter-spacing:0;color:#e2e8f0;font-weight:700;margin:0 0 10px}
#appzone h3,#settingsview h3{color:#e2e8f0}
#appzone label,#settingsview label{display:block;margin:6px 0 2px;
 font-size:13px;color:#94a3b8}
#appzone input[type=text],#appzone input[type=number],
#appzone input[type=password],#appzone select,#appzone textarea,
#settingsview input[type=text],#settingsview input[type=number],
#settingsview input[type=password],#settingsview select,
#settingsview textarea{width:100%;padding:7px}
input[type=password]{background:var(--panel);border:1px solid #334155;
 color:var(--txt);border-radius:6px;padding:5px 8px;font-size:12.5px;
 font-family:inherit}
textarea{height:64px}
.grid2{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:8px}
.grid3{display:grid;grid-template-columns:repeat(auto-fill,minmax(175px,1fr));gap:9px}
.row{display:flex;gap:8px;flex-wrap:wrap;align-items:center}
#appzone button,#settingsview button{background:var(--acc);color:#fff;
 padding:8px 14px;font-size:13px}
#appzone button.sec,#settingsview button.sec{background:#475569}
#appzone button.danger,#settingsview button.danger{background:#dc2626}
button:disabled{opacity:.5}
progress{width:100%;height:12px;accent-color:var(--acc)}
.det{background:var(--panel);border:1px solid #334155;border-radius:8px;
 padding:6px;text-align:center;font-size:12px;color:#cbd5e1}
.det img{max-width:100%;border-radius:5px}
.det.off{opacity:.4}
.det.selected{outline:2px dashed #60a5fa;outline-offset:2px}
#appzone .blurbtn{width:100%;padding:8px 0;margin-top:4px;font-weight:700;
 font-size:13px;border-radius:8px;letter-spacing:.3px;
 transition:background .15s,transform .05s}
.blurbtn:active{transform:scale(.97)}
#appzone .blurbtn.blur{background:#dc2626}
#appzone .blurbtn.keep{background:#16a34a}
.marq{position:absolute;border:1.5px dashed #60a5fa;
 background:rgba(96,165,250,.12);z-index:50;pointer-events:none}
.selmenu{position:absolute;z-index:60;background:#0f172a;border-radius:10px;
 border:1px solid #334155;box-shadow:0 8px 28px rgba(0,0,0,.5);
 padding:7px 10px;display:flex;gap:8px;align-items:center;font-size:12.5px;
 color:#cbd5e1}
#appzone .selmenu button{padding:7px 16px;font-weight:700}
#appzone .selmenu .mkeep{background:#16a34a}
#appzone .selmenu .mblur{background:#dc2626}
.badge{display:inline-block;background:#334155;color:#cbd5e1;border-radius:5px;
 padding:1px 6px;font-size:11px;margin-left:4px}
#log{background:#020617;color:#cbd5e1;font:12px/1.4 ui-monospace,Consolas,monospace;
 padding:10px;border-radius:8px;height:180px;overflow:auto;white-space:pre-wrap}
#preview img,#framewrap{max-width:100%;border-radius:8px}
#framewrap{position:relative;display:inline-block}
#framewrap canvas{position:absolute;left:0;top:0;cursor:crosshair}
#appzone a,#settingsview a{color:#93c5fd}
.joblist a{color:#93c5fd;text-decoration:none}
.warn{background:#3b2905;border:1px solid #b45309;color:#fcd34d;
 border-radius:8px;padding:8px 12px;font-size:13px}
.chk{display:flex;gap:12px;flex-wrap:wrap}
.chk label{display:flex;gap:4px;align-items:center;margin:0}
.plist{display:flex;flex-wrap:wrap;gap:4px;margin-top:5px}
.pw{background:#052e16;color:#4ade80;border:1px solid #14532d;border-radius:7px;
 padding:2px 7px;font-size:12px;font-weight:600;display:flex;gap:6px;
 align-items:center}
.pw span{cursor:pointer;color:#4ade80;font-weight:700}
.pw span:hover{color:#86efac}
.pnote{font-size:11.5px;color:#4ade80;margin-top:4px}
.qm{display:inline-flex;align-items:center;justify-content:center;
 width:15px;height:15px;border-radius:50%;background:#475569;color:#cbd5e1;
 font-size:10.5px;font-weight:700;cursor:help;margin-left:5px;
 position:relative;vertical-align:middle;user-select:none}
.qm:hover::after,.qm.open::after{content:attr(data-tip);position:absolute;
 left:calc(50% + var(--qx,0px));transform:translateX(-50%);bottom:135%;
 background:#0f172a;
 border:1px solid #334155;color:#e5e7eb;padding:9px 11px;border-radius:9px;
 width:var(--qw,250px);box-sizing:border-box;font-size:12px;font-weight:400;line-height:1.4;z-index:90;
 box-shadow:0 8px 24px rgba(0,0,0,.6);white-space:normal;text-align:left}
.qm.below::after{bottom:auto;top:135%}
footer{text-align:center;color:#64748b;font-size:12px;padding:18px 12px 26px}
.hdrtag{display:none}
@media(min-width:900px){.hdrtag{display:inline}}
@media(max-width:640px){.grid2{grid-template-columns:minmax(0,1fr)}}
"""

JOBS_HTML = """<div class="card"><h2>Jobs</h2><div class="joblist" id="jobs">loading…</div></div>
<div id="detail"></div>"""

SETTINGS_HTML = """<div id="settingsview" style="display:none">
<div class="card"><h2>App settings <a href="#" style="float:right;font-size:14px;font-weight:400" onclick="location.hash=&quot;&quot;;return false">&#8592; back to jobs</a></h2>
<div style="font-size:12px;color:#94a3b8">Server-level configuration — these apply to every job.</div>
</div>
<div class="card"><h2>Learned safe words</h2>
<div style="font-size:12px;color:#94a3b8;margin-bottom:6px">Words marked safe
during reviews load automatically and are applied to every scan, in addition
to any per-job allow names set in the Scan Setup editor.</div>
<div id="persistlist" class="plist"></div>
<div id="persistnote" class="pnote" style="display:none"></div>
<button type="button" class="sec" id="clearpersist" style="display:none;margin-top:5px;padding:4px 10px;font-size:12px" onclick="clearPersist()">Clear all learned words</button>
</div>
<div class="card" id="qualitypanel">
<h2>Detection quality <span class="qm" data-tip="One switch for the face / plate / person model set. Higher tiers use larger models: they catch small, distant and partly hidden subjects the fast models can miss, at the cost of longer scans. Applying a tier downloads any missing model (SHA-256 verified) and selects it; picking individual models below still works and shows as Custom. Scan-time multiples are approximate - GPU builds feel the increase far less than CPU.">?</span></h2>
<div id="qtiers" style="font-size:13px">loading&#8230;</div>
</div>
<div class="card" id="modelpanel">
<h2>Detection models <span class="qm" data-tip="Face detection works out of the box (built-in YuNet); optional higher-accuracy models can be downloaded and selected here. Plate detection needs a model file (not bundled). Every download is SHA-256 verified against a pinned hash before use, and each entry shows its license — some are non-commercial.">?</span></h2>
 <div id="msec_face"></div>
 <div id="msec_plate"></div>
 <div id="msec_person"></div>
</div>
<div class="card"><h2>Optional detection engines</h2>
<div id="extras" style="font-size:13px">loading…</div>
</div>
<div class="card"><h2>Encryption at rest</h2>
<div id="vstat" style="font-size:13px;color:#94a3b8;margin-bottom:8px">loading…</div>
<div id="vsetup" style="display:none">
 <div style="background:#3b2905;border:1px solid #b45309;border-radius:8px;padding:10px 12px;font-size:13px;margin-bottom:8px">
  <b>&#9888; No password reset exists.</b> If you lose this password, every
  encrypted job — uploads, audit reports, rendered output — is
  <b>permanently unrecoverable</b>. Write it down and store it safely.
 </div>
 <div class="row" style="gap:8px;flex-wrap:wrap;font-size:13px">
  <input type="password" id="vpw1" placeholder="password (8+ chars)">
  <input type="password" id="vpw2" placeholder="repeat password">
  <button onclick="vaultSetup()">Enable encryption</button>
 </div>
 <div style="font-size:12px;color:#9ca3af;margin-top:6px">Job files are
 encrypted (AES-256) whenever you lock or shut the server down, and
 decrypted while unlocked so scanning and review work normally. Pair with
 OS disk encryption (e.g. BitLocker) for full coverage.</div>
</div>
<div id="vunlock" style="display:none" class="row">
 <input type="password" id="vpw" placeholder="vault password">
 <button onclick="vaultUnlock()">Unlock</button>
</div>
<div id="vlock" style="display:none">
 <div class="row"><button onclick="vaultDoLock()">Lock now (encrypt all job files)</button></div>
 <div class="row" style="font-size:13px;margin-top:8px;gap:8px">
  <label style="margin:0"><input type="checkbox" id="valk" onchange="vaultAutolockSave()"> auto-lock after</label>
  <input type="number" id="valkmin" min="1" max="1440" value="30" style="width:70px" onchange="vaultAutolockSave()"> idle minutes (no activity, no jobs)
 </div>
</div>
</div>
<div class="card"><h2>HTTPS certificate</h2>
<div id="certinfo" style="font-size:13px;color:#94a3b8;margin-bottom:8px">loading…</div>
<div class="row" style="gap:8px;flex-wrap:wrap;font-size:13px">
 <label>Certificate (PEM): <input type="file" id="certfile" accept=".pem,.crt,.cer"></label>
 <label>Private key (PEM): <input type="file" id="keyfile" accept=".pem,.key"></label>
 <button onclick="uploadCerts()">Install</button>
 <button onclick="removeCerts()">Remove custom cert</button>
</div>
<div style="font-size:12px;color:#9ca3af;margin-top:6px">Installing or removing a
certificate takes effect after a server restart.</div>
</div>
</div>"""

FOOT_HTML = """<footer style="text-align:center;color:#9ca3af;font-size:12px;padding:18px 12px 26px">
OpenScrub v%%VERSION%% <span id="upd"></span>· <a href="license" style="color:#94a3b8">Apache-2.0 license</a>
· best-effort redaction — always review output before sharing PII</footer>"""

APP_JS = """function renderAudioSugg(){
 const el=document.getElementById("beASugg");
 if(!el)return;
 const sg=BE.audioSugg||[];
 if(!sg.length){el.style.display="none";el.innerHTML="";return;}
 el.style.display="block";
 let h='<div style="font-size:12px;color:#f59e0b;margin-bottom:3px">'
  +'&#127908; Spoken PII heard in the audio (local transcription) — '
  +'review each, then Add to mute it:</div>';
 sg.forEach((s,i)=>{
  const used=(BE.audio||[]).some(a=>Math.abs(a.t0-s.t0)<0.05&&Math.abs(a.t1-s.t1)<0.05);
  h+='<div style="font-size:12px;padding:2px 0">'
   +(used?'<span style="color:#4ade80">&#10003; added</span> '
     :'<button class="tog" style="font-size:11px;padding:1px 7px" '
      +'onclick="applyAudioSugg('+i+')">Add</button> ')
   +s.t0.toFixed(1)+'&ndash;'+s.t1.toFixed(1)+'s '
   +'<b>'+(CATDN[s.category]||s.category)+'</b> '
   +'<span style="color:#94a3b8">&ldquo;'
   +String(s.text||"").replace(/[<>&]/g,"")+'&rdquo;</span></div>';
 });
 h+='<div style="margin-top:3px"><button class="tog" style="font-size:11px" '
  +'onclick="applyAudioSugg(-1)">Add all</button></div>';
 el.innerHTML=h;
}
function applyAudioSugg(i){
 const sg=BE.audioSugg||[];
 const list=(i<0)?sg:[sg[i]].filter(Boolean);
 for(const s of list){
  if(!(BE.audio||[]).some(a=>Math.abs(a.t0-s.t0)<0.05&&Math.abs(a.t1-s.t1)<0.05))
   BE.audio.push({t0:s.t0,t1:s.t1,mode:"mute"});
 }
 renderAudioSugg();renderTranscript();beTLDraw();
}
// Full transcript with matched spans highlighted — the fail-closed check
// for spoken PII: ASR patterns can miss (a real half-muted address shipped
// once), but a human reading the transcript catches it in seconds. Click a
// start word then an end word to mute that range directly.
function renderTranscript(){
 const el=document.getElementById("beATx");
 if(!el)return;
 const tx=BE.audioTx||[];
 if(!tx.length){el.style.display="none";el.innerHTML="";return;}
 el.style.display="block";
 const wasOpen=el.querySelector("details")?el.querySelector("details").open:true;
 const esc=s=>String(s).replace(/[<>&]/g,"");
 const muted=w=>(BE.audio||[]).some(a=>w[0]<a.t1&&w[1]>a.t0);
 const sugg=w=>(BE.audioSugg||[]).some(a=>w[0]<a.t1&&w[1]>a.t0);
 let h='<details'+(wasOpen?' open':'')+'><summary style="font-size:12px;color:#94a3b8;cursor:pointer">&#128221; Transcript ('+tx.length+' words) — verify nothing sensitive slipped through</summary>'
  +'<div style="max-height:150px;overflow-y:auto;line-height:2.1;padding:6px 2px;font-size:12.5px;color:#cbd5e1">';
 tx.forEach((wd,i)=>{
  const m=muted(wd),g=sugg(wd),a=i===BE.txAnchor;
  let st='cursor:pointer;border-radius:4px;padding:1px 3px;';
  if(a)st+='outline:2px solid #f59e0b;';
  if(m)st+='background:#7f1d1d;color:#fecaca;text-decoration:line-through;';
  else if(g)st+='background:#78350f;color:#fde68a;';
  h+='<span style="'+st+'" title="'+wd[0].toFixed(2)+'&ndash;'+wd[1].toFixed(2)+'s'+(m?' (will be muted)':'')+'" onclick="txWordClick('+i+')">'+esc(wd[2])+'</span>';
 });
 h+='</div><div style="font-size:11px;color:#64748b">'
  +(BE.txAnchor>=0?'<b style="color:#f59e0b">now click the last word of the range to mute it</b>'
    :'<span style="background:#7f1d1d;border-radius:3px;padding:0 4px">red</span> will be muted &nbsp;'
     +'<span style="background:#78350f;border-radius:3px;padding:0 4px">amber</span> detected PII (not yet added) &nbsp;'
     +'— click a start word, then an end word, to mute a missed range (&plusmn;0.5s pad)')
  +'</div></details>';
 el.innerHTML=h;
}
function txWordClick(i){
 const tx=BE.audioTx||[];if(!tx[i])return;
 if(BE.txAnchor<0){BE.txAnchor=i;renderTranscript();return;}
 const a=Math.min(BE.txAnchor,i),b=Math.max(BE.txAnchor,i);
 BE.txAnchor=-1;
 BE.audio.push({t0:Math.max(0,+(tx[a][0]-0.5).toFixed(2)),
                t1:+(tx[b][1]+0.5).toFixed(2),
                mode:(document.getElementById("beAMode")||{}).value||"mute"});
 renderTranscript();renderAudioSugg();beTLDraw();
}
const CATDN={mrn:"regex",person:"person (full body)",manual:"tracked object",qrcode:"QR / barcode",screen:"screen (tv/laptop/phone)",anytext:"all text",bank:"bank number",crypto:"crypto address",passport:"passport / MRZ",phrase:"specific text"};   // display names — ids are a compat surface
async function refreshModelPanel(){
 // always visible: model choice lives on the settings page now, so users
 // can set up face/plate models before ticking the categories on a job
 document.getElementById("modelpanel").style.display="block";
 for(const kind of ["face","plate","person"]){
  const sec=document.getElementById("msec_"+kind);
  sec.style.display="block";
  try{
   const d=await(await fetch("/api/models/"+kind)).json();
   const dflt=kind==="face"?"Built-in YuNet (no download needed)"
                           :"Automatic — first installed model";
   const row=(val,checked,disabled,inner,right)=>`
    <div style="display:flex;align-items:center;gap:8px;padding:6px 0;border-top:1px solid #334155">
     <input type="radio" name="msel_${kind}" ${checked?"checked":""} ${disabled?"disabled":""}
      onchange="selModel('${kind}','${val}')" style="margin:0" title="${disabled?'download the model first':'use this model'}">
     <div style="flex:1;min-width:0">${inner}</div>${right||""}
    </div>`;
   let h=`<div style="font-weight:600;font-size:13.5px;margin:8px 0 2px">${kind==="face"?"Face":kind==="person"?"Person (full-body blur)":"License-plate"} model</div>
    <div style="font-size:12px;margin-bottom:4px;color:${d.active?'#4ade80':'#fbbf24'}">${d.status}</div>`;
   h+=row("",!d.selected,false,
     `<div style="font-size:12.5px;font-weight:600">${dflt}</div>`);
   for(const m of d.models){
    h+=row(m.id,d.selected===m.id,!m.installed,
     `<div style="font-size:12.5px;font-weight:600">${m.label} ${m.recommended?'<span style="color:#4ade80;font-size:11px">★ recommended</span>':''}</div>
      <div style="font-size:11px;color:#94a3b8">${m.notes||""}</div>`,
     `<a href="${m.source_url}" target="_blank" style="font-size:11px;background:#1e3a8a;color:#bfdbfe;border-radius:5px;padding:2px 7px;text-decoration:none" title="${m.attribution||''}">${m.license}</a>
      ${m.installed?'<span style="font-size:11px;color:#4ade80;font-weight:700">installed</span>'
       :(m.verified?`<button onclick="dlModel('${kind}','${m.id}',this)" title="${m.pinned?'SHA-256 verified against pinned hash':'first download: hash will be computed and pinned'}" style="font-size:11.5px;padding:3px 10px">Download</button>`
       :'<span style="font-size:11px;color:#9ca3af" title="registry entry has no download URL">manual install</span>')}`);
   }
   sec.innerHTML=h;
  }catch(e){sec.textContent="model registry unavailable";}
 }
}
async function selModel(kind,id){
 await fetch(`/api/models/${kind}/select`,{method:"POST",
  headers:{"Content-Type":"application/json"},body:JSON.stringify({id})});
 refreshModelPanel();renderTiers();
}
async function dlModel(kind,id,btn){
 btn.disabled=true;btn.textContent="0%";
 const r=await fetch(`/api/models/${kind}/${id}/download`,{method:"POST"});
 if(!r.ok){const d=await r.json();btn.textContent="error";btn.title=d.error||"";return;}
 const t=setInterval(async()=>{
  const s=await(await fetch("/api/models/download_status")).json();
  if(s.state==="downloading"){btn.textContent=(s.pct||0)+"%";}
  else{clearInterval(t);
   if(s.state==="done"){refreshModelPanel();}
   else{btn.disabled=false;btn.textContent="retry";btn.title=s.error||"download failed";}}
 },500);
}

// Detection-quality tiers: one click per tier; scan-time multiples and
// accuracy staging shown beside each. Multiples are honest approximations
// (measured on the person model, the dominant per-frame cost).
const QTIERS=[
 {id:"fast",name:"Fast",mult:"~1× scan time (baseline)",stage:"Good",
  desc:"Built-in YuNet face + nano person model. Lightest and quickest; can miss small, distant or partly hidden subjects."},
 {id:"balanced",name:"Balanced",mult:"~1.5–2× scan time",stage:"Better",
  desc:"CenterFace face + small person model — catches most small or partly hidden subjects the Fast tier misses."},
 {id:"accurate",name:"Accurate",mult:"~2.5–4× scan time",stage:"Best",
  desc:"CenterFace face + medium person model + the most-accurate plate model. Highest recall on crowds, occlusion and distant subjects; best experienced on a GPU."}];
let QAPPLY=0;
async function renderTiers(){
 const el=document.getElementById("qtiers"); if(!el)return;
 try{
  const d=await(await fetch("/api/quality_tier")).json();
  const ap=d.applying||{};
  let h="";
  for(const t of QTIERS){
   const cur=d.tier===t.id, busy=ap.state==="applying"&&ap.tier===t.id;
   const dl=((d.needs&&d.needs[t.id])||[]).length;
   h+=`<div style="display:flex;align-items:center;gap:8px;padding:7px 0;border-top:1px solid #334155">
    <input type="radio" name="qtier" ${cur?"checked":""} ${ap.state==="applying"?"disabled":""} onchange="applyTier('${t.id}')" style="margin:0">
    <div style="flex:1;min-width:0">
     <div style="font-size:12.5px;font-weight:600">${t.name}
      <span style="color:#94a3b8;font-weight:400">— ${t.mult}</span>
      <span style="font-size:11px;border-radius:5px;padding:1px 7px;margin-left:4px;background:${t.stage==="Good"?"#374151":t.stage==="Better"?"#1e3a8a":"#14532d"};color:${t.stage==="Good"?"#d1d5db":t.stage==="Better"?"#bfdbfe":"#86efac"}">${t.stage} accuracy</span></div>
     <div style="font-size:11px;color:#94a3b8">${t.desc}</div>
     ${busy?`<div style="font-size:11px;color:#fbbf24">${ap.step||"applying…"}</div>`:""}
    </div>
    ${!cur&&dl?`<span style="font-size:11px;color:#9ca3af;white-space:nowrap">${dl} download${dl>1?"s":""}</span>`:""}
   </div>`;
  }
  if(!d.tier&&ap.state!=="applying")h+=`<div style="font-size:11px;color:#fbbf24;padding-top:5px">Current selection: Custom (models picked individually below)</div>`;
  if(ap.state==="error")h+=`<div style="font-size:11px;color:#f87171;padding-top:5px">${ap.error}</div>`;
  h+=`<div style="font-size:11px;color:#64748b;padding-top:6px">Higher tiers download larger models on demand (person/plate models are AGPL/MIT licensed — shown per model below). For the strongest face detection, SCRFD (non-commercial license) can be selected manually in Detection models.</div>`;
  el.innerHTML=h;
  if(ap.state==="applying"){QAPPLY=1;setTimeout(renderTiers,900);}
  else if(QAPPLY){QAPPLY=0;refreshModelPanel();}
 }catch(e){el.textContent="quality tiers unavailable";}
}
async function applyTier(id){
 const d=await(await fetch("/api/quality_tier")).json();
 const need=(d.needs&&d.needs[id])||[];
 if(need.length&&!confirm(`Switching to this tier downloads ${need.length} model file(s) first (SHA-256 verified). Continue?`)){renderTiers();return;}
 const r=await fetch("/api/quality_tier",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({tier:id})});
 if(!r.ok){let e={};try{e=await r.json();}catch(_){/**/}alert(e.error||"could not apply tier");}
 renderTiers();
}
refreshModelPanel();renderTiers();
let CUR=null, EN={}, MAN=[], DUR=0, POLL=null, PHIST=[], PHPH="", LOGN=0, SHELLPH=null, JOBSJSON="";

async function loadJobs(){
 const r=await fetch("api/jobs");
 if(r.status===423){jobs.innerHTML='<span style="color:#f87171">&#128274; locked — unlock in the Encryption panel below</span>';JOBSJSON="";return;}
 const js=await r.json();
 const s=JSON.stringify(js);
 if(s===JOBSJSON)return;
 JOBSJSON=s;
 jobs.innerHTML=js.length?js.map(j=>
  `<div class="row" style="justify-content:space-between;padding:4px 0">
   <a href="#" onclick="openJob('${j.id}');return false">${j.name}</a>
   <span style="display:flex;gap:10px;align-items:center"><span class="badge">${j.phase}</span>
   ${(j.phase=="error"||j.phase=="cancelled")?`<a href="#" title="Retry the scan — reuses the file already on the server, nothing is re-uploaded" style="text-decoration:none;font-size:15px" onclick="retryJob('${j.id}');return false">&#8635;</a>`:""}
   <a href="#" title="Delete this job and all of its files" style="text-decoration:none;font-size:15px" onclick="delJob('${j.id}');return false">&#128465;&#65039;</a></span></div>`).join(""):"none yet";
}

async function retryJob(id){
 const r=await fetch("api/jobs/"+id+"/retry",{method:"POST"});
 let j={};try{j=await r.json();}catch(e){}
 if(!r.ok){alert(j.error||"could not retry the job");return;}
 JOBSJSON="";loadJobs();if(typeof openJob==="function")openJob(id);
}
async function delJob(id){
 if(!confirm("Delete this job and ALL of its files — upload, report, and rendered output?\\n\\nThis cannot be undone."))return;
 const r=await fetch("api/jobs/"+id,{method:"DELETE"});
 if(!r.ok){
  let m="could not delete the job";
  try{const e=await r.json();m=e.error||e.description||m;}catch(_){}
  alert(m);return;
 }
 if(CUR===id){CUR=null;if(POLL)clearInterval(POLL);detail.innerHTML="";}
 JOBSJSON="";loadJobs();
}
async function openJob(id){
 CUR=id; EN={}; MAN=[]; PHIST=[]; PHPH=""; LOGN=0; SHELLPH=null;
 detail.innerHTML="";
 if(POLL)clearInterval(POLL);
 POLL=setInterval(refresh,900); refresh();
}

function shellHtml(j){
 return `<div class="card" id="jobcard"><h2>${j.name}
  <span class="badge" id="ph"></span><small id="eta"></small></h2>
 <progress id="prog" value="0" max="1"></progress>
 <div class="row" id="actions" style="margin-top:8px"></div>
 <div style="margin-top:8px;text-align:center"><img id="pimg"
   style="max-width:100%;border-radius:8px;display:none;margin:0 auto"></div>
 <div id="pcap" style="font-size:12px;color:#94a3b8"></div>
 <div id="log" style="margin-top:8px"></div>
 <div class="warn" id="warnbox" style="display:none;margin-top:8px"></div>
 </div>`;
}

async function refresh(){
 if(!CUR)return;
 const j=await (await fetch("api/jobs/"+CUR)).json();
 if(SHELLPH===null){
  detail.insertAdjacentHTML("afterbegin",shellHtml(j));SHELLPH="";
  const im=document.getElementById("pimg");
  im.onload=()=>{im.style.display="block";};   // show only once a real frame arrives
  im.onerror=()=>{im.style.display="none";};   // 404 before first preview: stay hidden
 }

 // progress + ETA (updated in place — nothing is rebuilt).
 // The server sends a smoothed per-stage estimate (j.eta, seconds) built
 // from the stage's average processing rate — prefer it. The old
 // client-side extrapolation from bar movement stays only as a fallback
 // (rehydrated jobs mid-phase), with its history reset on phase change so
 // it never extrapolates a scan-speed rate across the render phase.
 if(PHPH!==j.phase){PHIST=[];PHPH=j.phase;}
 PHIST.push([Date.now(),j.progress]); if(PHIST.length>40)PHIST.shift();
 let sec=null;
 if(typeof j.eta==="number"&&j.progress<1)sec=j.eta;
 else if(j.progress>0&&j.progress<1&&PHIST.length>3){
  const[t0,p0]=PHIST[0],[t1,p1]=PHIST[PHIST.length-1];
  if(p1>p0)sec=(1-p1)*(t1-t0)/(p1-p0)/1000;}
 const eta=sec===null?"":` ~${sec>90?Math.round(sec/60)+" min":Math.round(sec)+" s"} left`;
 document.getElementById("ph").textContent=j.phase;
 document.getElementById("eta").textContent=eta;
 document.getElementById("prog").value=j.progress;

 // incremental log append with stick-to-bottom (respects manual scroll-up)
 const lg=document.getElementById("log");
 const stick=lg.scrollTop+lg.clientHeight>=lg.scrollHeight-40;
 const nl=await (await fetch(`api/jobs/${CUR}/log?from=${LOGN}`)).json();
 if(LOGN===0&&nl.len>400){LOGN=nl.len-400;nl.lines=nl.lines.slice(-400);}
 if(nl.lines.length){
  const NL=String.fromCharCode(10);
  lg.textContent+=(lg.textContent?NL:"")+nl.lines.join(NL);
  LOGN=nl.len;
  if(stick)lg.scrollTop=lg.scrollHeight;
 }

 // live preview: swap src in place (browser keeps old frame until new loads)
 const img=document.getElementById("pimg");
 if(j.phase=="scanning"){
  img.src=`api/jobs/${CUR}/preview.jpg?x=${Date.now()}`;
 }

 const wb=document.getElementById("warnbox");
 if(j.error){wb.style.display="block";wb.textContent=j.error;}
 else wb.style.display="none";

 // action buttons rebuilt ONLY when the phase changes
 if(SHELLPH!==j.phase){
  SHELLPH=j.phase;
  let a="";
  if(j.phase=="scanning"||j.phase=="rendering")
   a=`<button class="danger" onclick="cancelJob()">Cancel</button>`;
  if(j.phase=="error"||j.phase=="cancelled")
   a=`<button onclick="retryJob(CUR)">Retry scan (no re-upload)</button>
    <div style="width:100%;font-size:12px;color:#9ca3af">The uploaded file
    is still on the server — Retry re-runs the scan without uploading it
    again. Delete the job (&#128465;&#65039; in the list) to free its disk
    space.</div>`;
  if(j.phase=="review"){
   // no interstitial button: review is the ONLY next step after a scan,
   // so open it directly — both on a live scan finishing and on
   // selecting a job that is already waiting in review
   a="";
   loadReview();
  }
  if(j.phase=="done"&&j.has_output)
   a=`<a href="api/jobs/${CUR}/download"><button>Download redacted video</button></a>
    <a href="api/jobs/${CUR}/report"><button class="sec">Download audit report</button></a>
    <button class="sec" onclick="loadReview()">Re-open review</button>
    <button class="sec" onclick="loadCompare()">Compare before/after</button>
    <button class="sec" onclick="loadBoxEdit()">Preview &amp; edit blur boxes</button>
    <div class="warn" style="width:100%">Reminder: scrub the result before
    sharing. This tool is best-effort, not a compliance guarantee.</div>
    <div id="compare" style="width:100%"></div>
    <div id="beslot_done" style="width:100%"></div>`;
  document.getElementById("actions").innerHTML=a;
  if(j.phase!="scanning")img.style.display="none";
 }
 loadJobs();
}

let BE={t:0,ox:0,oy:0,boxes:[],sel:-1,ov:{},dis:{},times:{},adds:[],
        add:false,addAnchor:null,drag:null,scale:1,dur:10};
async function loadBoxEdit(fromReview){
 showPanel(fromReview?"boxedit_rev":"boxedit");
 const mi=await (await fetch(`api/jobs/${CUR}/mediainfo`)).json();
 // in review: the slot right under the Preview button; on done: the actions slot
 let c=document.getElementById("beslot")||document.getElementById("beslot_done");
 if(!c){c=document.createElement("div");c.id="beslot";c.style.width="100%";
  (document.getElementById("review")||document.getElementById("jobcard")||detail)
   .appendChild(c);}
 BE={t:0,ox:0,oy:0,boxes:[],sel:-1,ov:{},dis:{},times:{},adds:[],
     add:false,addAnchor:null,drag:null,scale:1,dur:mi.duration,
     win:[0,mi.duration],trk:false,muteArm:false,tlDrag:null,
     tlspans:[],audio:[],audioSel:-1};
 c.innerHTML=`<div class="row" style="margin-top:8px">
  <button class="sec" id="bePlay" style="padding:3px 11px" title="Play the video with live boxes — pause to edit them" onclick="beTogglePlay()">&#9654;</button>t=
  <input type="range" id="beT" min="0" max="${Math.max(0.2,mi.duration-0.1).toFixed(1)}"
   step="0.1" value="0" style="flex:1" oninput="beScrub()"><span id="beL">0s</span></div>
  <div style="position:relative;display:inline-block;max-width:100%">
   <img id="beImg" style="max-width:100%;border-radius:8px">
   <video id="beVid" style="max-width:100%;border-radius:8px;display:none" playsinline preload="none"></video>
   <canvas id="beCv" style="position:absolute;left:0;top:0;touch-action:none"></canvas></div>
  <canvas id="beTL" style="width:100%;height:72px;display:block;margin-top:6px;
   border-radius:6px;touch-action:none;cursor:crosshair"
   title="Timeline: colored spans = detections. Drag the orange handles to set the active window; click to seek."></canvas>
  <div class="row" style="font-size:12.5px;align-items:center;margin-top:2px">
   <span id="beWinL" style="color:#94a3b8">window: whole video</span>
   <button class="sec" style="padding:3px 8px;font-size:12px" onclick="beWinReset()">reset window</button>
   <span style="flex:1"></span>
   <select id="beAMode" style="font-size:12px"><option value="mute">mute</option>
    <option value="bleep">bleep</option></select>
   <button class="tog" id="beMute" onclick="beMuteMode()">&#128263; Audio span</button>
   <button class="danger" id="beARm" style="display:none" onclick="beAudioRm()">Delete span</button></div>
  <div id="beASugg" style="display:none;margin-top:6px"></div>
  <div id="beATx" style="display:none;margin-top:6px"></div>
  <div class="row" style="margin-top:6px">
   <button class="tog" id="beAdd" onclick="beAddMode()">&#65291; Add box</button>
   <button class="tog" id="beTrk" onclick="beTrackMode()">&#8857; Track object</button>
   <button class="danger" id="beRm" style="display:none" onclick="beRemove()">Remove blur</button>
   <span id="beTimes" style="display:none;align-items:center;gap:4px;font-size:13px">
    from <input type="number" id="beT0" step="0.1" min="0" style="width:74px">
    to <input type="number" id="beT1" step="0.1" style="width:74px"> s
    <button class="sec" onclick="beApplyTimes()">Apply times</button></span>
   <span id="beTrkSt" style="display:none;font-size:13px;color:#fbbf24">tracking&#8230;</span>
   <button onclick="beSave()">Save changes &amp; re-render</button></div>
  <p style="font-size:12px;color:#94a3b8;margin:4px 0 0">&#9654; plays the
   video with the boxes moving live (pause to edit). Click a red box to
   select — drag inside to move, a corner to resize, edit its from/to times,
   or remove its blur. &#65291; Add box: drag a static region. &#8857; Track object:
   drag the timeline handles to the part of the video you care about, scrub
   to a frame where the object is clear, draw a box around it — it will be
   followed and blurred through the window. &#128263; Audio span: drag on the
   timeline's bottom lane to silence (or bleep) that stretch of sound.</p>`;
 const img=document.getElementById("beImg");
 img.onload=()=>{if(BE.playing)return;const cv=document.getElementById("beCv");
  cv.width=img.clientWidth;cv.height=img.clientHeight;
  BE.scale=img.clientWidth/(img.naturalWidth||1);beDraw();};
 const bv=document.getElementById("beVid");
 bv.addEventListener("pause",()=>{if(BE.playing)bePlayStop();});
 bv.addEventListener("ended",()=>{if(BE.playing)bePlayStop();});
 beHook();tlHook();await tlInit();beScrub();
}

// ---- playback with live boxes (issue #17: review was scrub-only) ----
async function beTogglePlay(){
 const v=document.getElementById("beVid"),img=document.getElementById("beImg");
 if(!v)return;
 if(BE.playing){v.pause();return;}          // the pause handler cleans up
 if(!v.src)v.src=`api/jobs/${CUR}/video`;
 BE.playing=true;
 v.style.display="block";img.style.display="none";
 // boxes are view-only while playing: freeze pointer edits so a moving
 // box can't be grabbed mid-flight
 const cv=document.getElementById("beCv");cv.style.pointerEvents="none";
 document.getElementById("bePlay").innerHTML="&#10074;&#10074;";
 try{
  if(v.readyState<1)await new Promise((res,rej)=>{
   v.onloadedmetadata=res;
   v.onerror=()=>rej(new Error("the browser cannot decode this file"));});
  v.currentTime=BE.t||0;
  await v.play();
 }catch(e){
  bePlayStop();
  alert("Could not play the video in this browser ("+(e&&e.message||e)
   +") — the scrub slider still works frame by frame.");
  return;
 }
 if(v.clientWidth){cv.width=v.clientWidth;cv.height=v.clientHeight;
  BE.scale=v.clientWidth/(v.videoWidth||1);}
 // boxes come from the server per timestamp; refresh them on a throttle
 // while rAF keeps the playhead, label and box painting per-frame smooth
 let lastQ=0,inFlight=false;
 const step=()=>{
  if(!BE.playing)return;
  BE.t=v.currentTime;
  document.getElementById("beT").value=BE.t;
  document.getElementById("beL").textContent=BE.t.toFixed(1)+"s";
  const now=performance.now();
  if(!inFlight&&now-lastQ>150){
   inFlight=true;lastQ=now;
   fetch(`api/jobs/${CUR}/boxes_at?t=${BE.t.toFixed(2)}&all=1`)
    .then(r=>r.json())
    .then(d=>{BE.ox=d.ox;BE.oy=d.oy;BE.raw=d.boxes;beFilter();})
    .catch(()=>{}).finally(()=>{inFlight=false;});
  }
  beDraw();beTLDraw();
  requestAnimationFrame(step);
 };
 requestAnimationFrame(step);
}
function bePlayStop(){
 BE.playing=false;
 const v=document.getElementById("beVid");
 if(v){try{v.pause();}catch(e){}v.style.display="none";}
 const img=document.getElementById("beImg");if(img)img.style.display="";
 const b=document.getElementById("bePlay");if(b)b.innerHTML="&#9654;";
 const cv=document.getElementById("beCv");if(cv)cv.style.pointerEvents="auto";
 beScrub();   // crisp frame + authoritative boxes at the pause point
}

const TLC={name:"#3b82f6",dob:"#22c55e",phone:"#f59e0b",ssn:"#ef4444",
 mrn:"#8b5cf6",email:"#14b8a6",address:"#f97316",card:"#db2777",
 apikey:"#0891b2",ipaddr:"#65a30d",plate:"#7c3aed",face:"#ec4899",
 person:"#0ea5e9",manual:"#eab308"};
async function tlInit(){
 // one fetch of the full report: detection spans for the lanes (dense
 // tracks collapse to one span per track) + stored audio redactions
 try{
  const doc=await (await fetch(`api/jobs/${CUR}/report`)).json();
  const per={};
  for(const d of (doc.detections||[])){
   if(d.enabled===false)continue;
   const key=d.category+((d.track??-1)>=0?(":t"+d.track):(":i"+Math.random()));
   const s=per[key]||(per[key]={cat:d.category,t0:d.t_start,t1:d.t_end});
   s.t0=Math.min(s.t0,d.t_start);s.t1=Math.max(s.t1,d.t_end);
  }
  BE.tlspans=Object.values(per);
  BE.audio=(doc.audio_redactions||[]).map(s=>({t0:s.t0,t1:s.t1,mode:s.mode||"mute"}));
  BE.audioSugg=doc.audio_suggestions||[];
  BE.audioTx=doc.audio_transcript||[];BE.txAnchor=-1;
  renderAudioSugg();renderTranscript();
 }catch(e){BE.tlspans=[];}
 beTLDraw();
}
function tlX(t,w){return Math.max(0,Math.min(w,t/Math.max(0.1,BE.dur)*w));}
function beTLDraw(){
 const cv=document.getElementById("beTL");if(!cv)return;
 const w=cv.clientWidth||600;cv.width=w;cv.height=72;
 const g=cv.getContext("2d");
 g.fillStyle="#0f172a";g.fillRect(0,0,w,72);
 // category lanes
 const cats=[...new Set(BE.tlspans.map(s=>s.cat))];
 const laneH=cats.length?Math.min(10,44/Math.max(1,cats.length)):0;
 BE.tlspans.forEach(s=>{
  const row=cats.indexOf(s.cat);
  g.fillStyle=TLC[s.cat]||"#94a3b8";
  g.globalAlpha=0.9;
  g.fillRect(tlX(s.t0,w),4+row*laneH,
             Math.max(2,tlX(s.t1,w)-tlX(s.t0,w)),Math.max(3,laneH-2));
 });
 g.globalAlpha=1;
 // audio lane (bottom 14px)
 g.fillStyle="#1e293b";g.fillRect(0,54,w,14);
 BE.audio.forEach((s,i)=>{
  g.fillStyle=i===BE.audioSel?"#f87171":(s.mode==="bleep"?"#fb923c":"#dc2626");
  g.fillRect(tlX(s.t0,w),55,Math.max(2,tlX(s.t1,w)-tlX(s.t0,w)),12);
 });
 g.fillStyle="#64748b";g.font="9px sans-serif";g.fillText("audio",3,64);
 // dim outside the active window + orange handles
 g.fillStyle="rgba(2,6,23,0.72)";
 g.fillRect(0,0,tlX(BE.win[0],w),72);
 g.fillRect(tlX(BE.win[1],w),0,w-tlX(BE.win[1],w),72);
 g.fillStyle="#f59e0b";
 g.fillRect(tlX(BE.win[0],w)-2,0,4,72);g.fillRect(tlX(BE.win[1],w)-2,0,4,72);
 // playhead
 g.strokeStyle="#f8fafc";g.beginPath();
 g.moveTo(tlX(BE.t,w),0);g.lineTo(tlX(BE.t,w),72);g.stroke();
 const full=BE.win[0]<0.05&&BE.win[1]>BE.dur-0.05;
 document.getElementById("beWinL").textContent=full?"window: whole video"
  :`window: ${BE.win[0].toFixed(1)}–${BE.win[1].toFixed(1)}s`;
}
function tlHook(){
 const cv=document.getElementById("beTL");if(!cv)return;
 const tAt=e=>{const r=cv.getBoundingClientRect();
  return Math.max(0,Math.min(BE.dur,(e.clientX-r.left)/r.width*BE.dur));};
 const yAt=e=>{const r=cv.getBoundingClientRect();return e.clientY-r.top;};
 cv.addEventListener("pointerdown",e=>{
  cv.setPointerCapture(e.pointerId);
  const t=tAt(e),w=cv.clientWidth,px=e.clientX-cv.getBoundingClientRect().left;
  if(Math.abs(px-tlX(BE.win[0],w))<7){BE.tlDrag={k:"w0"};return;}
  if(Math.abs(px-tlX(BE.win[1],w))<7){BE.tlDrag={k:"w1"};return;}
  if(yAt(e)>=54){                                  // audio lane
   if(BE.muteArm){BE.tlDrag={k:"anew",t0:t};
    BE.audio.push({t0:t,t1:t,mode:document.getElementById("beAMode").value});
    BE.audioSel=BE.audio.length-1;beTLDraw();return;}
   const hit=BE.audio.findIndex(s=>t>=s.t0&&t<=s.t1);
   BE.audioSel=hit;
   document.getElementById("beARm").style.display=hit>=0?"inline-block":"none";
   beTLDraw();return;
  }
  BE.tlDrag={k:"seek"};
  document.getElementById("beT").value=t.toFixed(1);beScrub();
 });
 cv.addEventListener("pointermove",e=>{
  if(!BE.tlDrag)return;
  const t=tAt(e);
  if(BE.tlDrag.k==="w0")BE.win[0]=Math.min(t,BE.win[1]-0.2);
  else if(BE.tlDrag.k==="w1")BE.win[1]=Math.max(t,BE.win[0]+0.2);
  else if(BE.tlDrag.k==="anew"){
   const s=BE.audio[BE.audioSel];
   s.t0=Math.min(BE.tlDrag.t0,t);s.t1=Math.max(BE.tlDrag.t0,t);
  }else if(BE.tlDrag.k==="seek"){
   document.getElementById("beT").value=t.toFixed(1);beScrub();}
  beTLDraw();
 });
 cv.addEventListener("pointerup",()=>{
  if(BE.tlDrag&&BE.tlDrag.k==="anew"){
   const s=BE.audio[BE.audioSel];
   if(s.t1-s.t0<0.15){BE.audio.pop();BE.audioSel=-1;}   // stray click
   BE.muteArm=false;document.getElementById("beMute").classList.remove("on");
   document.getElementById("beARm").style.display=BE.audioSel>=0?"inline-block":"none";
   renderTranscript();
  }
  BE.tlDrag=null;beTLDraw();
 });
}
function beWinReset(){BE.win=[0,BE.dur];beTLDraw();}
function beMuteMode(){
 BE.muteArm=!BE.muteArm;BE.trk=false;BE.add=false;BE.addAnchor=null;
 document.getElementById("beMute").classList.toggle("on",BE.muteArm);
 document.getElementById("beTrk").classList.remove("on");
 document.getElementById("beAdd").classList.remove("on");
}
function beAudioRm(){
 if(BE.audioSel>=0){BE.audio.splice(BE.audioSel,1);BE.audioSel=-1;
  document.getElementById("beARm").style.display="none";
  renderTranscript();renderAudioSugg();beTLDraw();}
}
function beTrackMode(){
 BE.trk=!BE.trk;BE.add=false;BE.addAnchor=null;BE.muteArm=false;
 document.getElementById("beTrk").classList.toggle("on",BE.trk);
 document.getElementById("beAdd").classList.remove("on");
 document.getElementById("beMute").classList.remove("on");
}
async function beTrackGo(box){
 const st=document.getElementById("beTrkSt");st.style.display="inline";
 st.textContent=`tracking ${BE.win[0].toFixed(1)}–${BE.win[1].toFixed(1)}s…`;
 const r=await fetch(`api/jobs/${CUR}/track_object`,{method:"POST",
  headers:{"Content-Type":"application/json"},
  body:JSON.stringify({box,t_ref:BE.t,t0:BE.win[0],t1:BE.win[1]})});
 if(!r.ok){st.textContent="tracking failed to start";return;}
 const poll=setInterval(async()=>{
  const d=await (await fetch(`api/jobs/${CUR}/track_status`)).json();
  if(d.state!=="running"){
   clearInterval(poll);
   st.textContent=d.error?("⚠ "+d.error)
    :`tracked ✓ ${d.added} position(s) — review card added`;
   if(!d.error){await tlInit();beScrub();
    if(document.getElementById("review"))loadReview();}
  }
 },1500);
}
async function beScrub(){
 const sl=document.getElementById("beT");if(!sl)return; // editor was closed
 if(BE.playing){               // dragging the slider while playing = seek
  const v=document.getElementById("beVid");
  if(v)v.currentTime=+sl.value;
  return;                      // the rAF loop keeps label/boxes in sync
 }
 BE.sel=-1;document.getElementById("beRm").style.display="none";
 document.getElementById("beTimes").style.display="none";
 BE.t=+document.getElementById("beT").value;
 document.getElementById("beL").textContent=BE.t.toFixed(1)+"s";
 document.getElementById("beImg").src=`api/jobs/${CUR}/frame_at?t=${BE.t}`;
 const d=await (await fetch(`api/jobs/${CUR}/boxes_at?t=${BE.t}&all=1`)).json();
 BE.ox=d.ox;BE.oy=d.oy;BE.raw=d.boxes;
 beFilter();beDraw();beTLDraw();
}
function beFilter(){
 BE.boxes=(BE.raw||[]).filter(b=>{
  const on=(b.i in EN)?EN[b.i]:b.enabled;   // live: review toggles apply here
  return on;
 }).map(b=>{
  let bb=b;
  if(BE.ov[b.i]){const o=BE.ov[b.i];
   bb={...b,box:[o[0]+BE.ox,o[1]+BE.oy,o[2]+BE.ox,o[3]+BE.oy]};}
  if(BE.times[b.i]){bb={...bb,t_start:BE.times[b.i][0],t_end:BE.times[b.i][1]};}
  return bb;
 });
}
function beDraw(){
 const cv=document.getElementById("beCv");if(!cv)return;
 const x=cv.getContext("2d"),s=BE.scale;
 x.clearRect(0,0,cv.width,cv.height);
 for(const a of BE.adds){
  if(BE.t<a.t0-0.01||BE.t>a.t1+0.01)continue;
  const[a1,b1,a2,b2]=a.box.map(v=>v*s);
  x.fillStyle="rgba(245,158,11,.25)";x.strokeStyle="#f59e0b";x.lineWidth=2;
  x.fillRect(a1,b1,a2-a1,b2-b1);x.strokeRect(a1,b1,a2-a1,b2-b1);
 }
 if(BE.add&&BE.addAnchor&&BE.addFloat){
  const[p,q]=[BE.addAnchor,BE.addFloat];
  x.strokeStyle="#f59e0b";x.setLineDash([6,4]);x.lineWidth=2;
  x.strokeRect(Math.min(p[0],q[0])*s,Math.min(p[1],q[1])*s,
   Math.abs(q[0]-p[0])*s,Math.abs(q[1]-p[1])*s);x.setLineDash([]);
 }
 for(const b of BE.boxes){
  const[a1,b1,a2,b2]=b.box.map(v=>v*s);
  x.fillStyle=b.i===BE.sel?"rgba(37,99,235,.25)":"rgba(220,38,38,.22)";
  x.strokeStyle=b.i===BE.sel?"#2563eb":"#dc2626";x.lineWidth=2;
  x.fillRect(a1,b1,a2-a1,b2-b1);x.strokeRect(a1,b1,a2-a1,b2-b1);
  if(b.i===BE.sel)for(const[hx,hy] of [[a1,b1],[a2,b1],[a1,b2],[a2,b2]]){
   x.fillStyle="#fff";x.fillRect(hx-5,hy-5,10,10);
   x.strokeRect(hx-5,hy-5,10,10);}
 }
}
function beAddMode(){
 BE.add=!BE.add;BE.addAnchor=null;BE.sel=-1;
 BE.trk=false;BE.muteArm=false;
 document.getElementById("beAdd").classList.toggle("on",BE.add);
 const tb=document.getElementById("beTrk");if(tb)tb.classList.remove("on");
 const mb=document.getElementById("beMute");if(mb)mb.classList.remove("on");
 document.getElementById("beRm").style.display="none";
 document.getElementById("beTimes").style.display="none";
 beDraw();
}
function beApplyTimes(){
 if(BE.sel<0)return;
 const t0=+document.getElementById("beT0").value,
       t1=+document.getElementById("beT1").value;
 if(!(t1>t0&&t0>=0)){alert("'to' must be after 'from'.");return;}
 BE.times[BE.sel]=[t0,Math.min(t1,BE.dur)];
 const b=BE.boxes.find(x=>x.i===BE.sel);
 if(b){b.t_start=t0;b.t_end=t1;}
 beDraw();
}
function beShowTimes(b){
 const el=document.getElementById("beTimes");
 el.style.display="inline-flex";
 document.getElementById("beT0").value=b.t_start.toFixed(1);
 document.getElementById("beT1").value=b.t_end.toFixed(1);
}
function beHook(){
 const cv=document.getElementById("beCv");
 const pt=e=>{const r=cv.getBoundingClientRect();
  return[(e.clientX-r.left)/BE.scale,(e.clientY-r.top)/BE.scale];};
 cv.addEventListener("pointerdown",e=>{
  const p=pt(e);cv.setPointerCapture(e.pointerId);
  if(BE.trk){
   // Track object: same two-click box draw as Add box, but on completion
   // the region is template-tracked through the active timeline window
   if(!BE.addAnchor){BE.addAnchor=p;BE.addFloat=p;}
   else{
    const a=BE.addAnchor,q=p;BE.addAnchor=null;BE.addFloat=null;
    const box=[Math.min(a[0],q[0]),Math.min(a[1],q[1]),
               Math.max(a[0],q[0]),Math.max(a[1],q[1])];
    BE.trk=false;document.getElementById("beTrk").classList.remove("on");
    if(box[2]-box[0]>10&&box[3]-box[1]>10)beTrackGo(box);
    beDraw();
   }
   return;
  }
  if(BE.add){
   if(!BE.addAnchor){BE.addAnchor=p;BE.addFloat=p;}
   else{
    const a=BE.addAnchor,q=p;BE.addAnchor=null;BE.addFloat=null;
    const box=[Math.min(a[0],q[0]),Math.min(a[1],q[1]),
               Math.max(a[0],q[0]),Math.max(a[1],q[1])];
    if(box[2]-box[0]>6&&box[3]-box[1]>6){
     const t0=Math.max(0,+(BE.t-0.5).toFixed(1)),
           t1=Math.min(BE.dur,+(BE.t+3).toFixed(1));
     const fr=prompt("Blur this region FROM (seconds):",t0);
     if(fr===null){beDraw();return;}
     const to=prompt("...TO (seconds):",t1);
     if(to===null){beDraw();return;}
     BE.adds.push({box,t0:Math.max(0,+fr||0),
                   t1:Math.min(BE.dur,+to||t1),tref:BE.t});
    }
    beDraw();
   }
   return;
  }
  const sel=BE.boxes.find(b=>b.i===BE.sel);
  if(sel){const[a1,b1,a2,b2]=sel.box,hs=9/BE.scale;
   const corners=[[a1,b1,0],[a2,b1,1],[a1,b2,2],[a2,b2,3]];
   for(const[hx,hy,ci] of corners)
    if(Math.abs(p[0]-hx)<hs&&Math.abs(p[1]-hy)<hs){
     BE.drag={kind:"corner",ci};return;}
   if(p[0]>=a1&&p[0]<=a2&&p[1]>=b1&&p[1]<=b2){
    BE.drag={kind:"move",off:[p[0]-a1,p[1]-b1]};return;}
  }
  const hit=[...BE.boxes].reverse().find(b=>{
   const[a1,b1,a2,b2]=b.box;
   return p[0]>=a1&&p[0]<=a2&&p[1]>=b1&&p[1]<=b2;});
  BE.sel=hit?hit.i:-1;
  document.getElementById("beRm").style.display=hit?"inline-block":"none";
  if(hit)beShowTimes(hit);
  else document.getElementById("beTimes").style.display="none";
  beDraw();
 });
 cv.addEventListener("pointermove",e=>{
  if(BE.add&&BE.addAnchor){BE.addFloat=pt(e);beDraw();return;}
  if(!BE.drag||BE.sel<0)return;
  const p=pt(e),b=BE.boxes.find(x=>x.i===BE.sel);if(!b)return;
  let[a1,b1,a2,b2]=b.box;
  if(BE.drag.kind==="move"){
   const w0=a2-a1,h0=b2-b1;a1=p[0]-BE.drag.off[0];b1=p[1]-BE.drag.off[1];
   a2=a1+w0;b2=b1+h0;
  }else{
   if(BE.drag.ci===0){a1=p[0];b1=p[1];}
   if(BE.drag.ci===1){a2=p[0];b1=p[1];}
   if(BE.drag.ci===2){a1=p[0];b2=p[1];}
   if(BE.drag.ci===3){a2=p[0];b2=p[1];}
  }
  b.box=[Math.min(a1,a2),Math.min(b1,b2),Math.max(a1,a2),Math.max(b1,b2)];
  BE.ov[BE.sel]=[b.box[0]-BE.ox,b.box[1]-BE.oy,b.box[2]-BE.ox,b.box[3]-BE.oy];
  beDraw();
 });
 cv.addEventListener("pointerup",()=>{BE.drag=null;});
}
function zoomDet(i){
 let ov=document.getElementById("lb");
 if(!ov){
  ov=document.createElement("div");ov.id="lb";
  ov.style.cssText="position:fixed;inset:0;background:rgba(0,0,0,.82);"+
   "z-index:100;display:flex;align-items:center;justify-content:center;"+
   "cursor:zoom-out;padding:18px";
  ov.onclick=()=>ov.remove();
  document.body.appendChild(ov);
 }
 ov.innerHTML=`<img src="api/jobs/${CUR}/detframe/${i}"
  style="max-width:96%;max-height:96%;border-radius:8px;
  box-shadow:0 12px 50px rgba(0,0,0,.6)">`;
}
function beRemove(){
 if(BE.sel<0)return;
 applyDet(BE.sel,false);   // syncs thumbnail + refilters editor
 BE.sel=-1;
 document.getElementById("beRm").style.display="none";
 document.getElementById("beTimes").style.display="none";
}
async function beSave(){
 await saveAndRender();
 const c=document.querySelector("#beslot");
 if(c)c.innerHTML="rendering with your edits…";
}
async function cancelJob(){await fetch("api/jobs/"+CUR+"/cancel",{method:"POST"})}

// the three post-render views (compare, review, box editor) are mutually
// exclusive: opening one closes the others instead of stacking them
function showPanel(which){
 // a playing box-editor video must be PAUSED before its DOM is wiped —
 // an element removed via innerHTML can keep its audio running
 try{const v=document.getElementById("beVid");
  if(v&&!v.paused){BE.playing=false;v.pause();}}catch(e){}
 // "boxedit_rev" = the editor button INSIDE the review card: the editor
 // mounts in the review's own slot, so the review stays. Everything else
 // is standalone and closes the other panels.
 if(which!=="compare"){
  const c=document.getElementById("compare");if(c)c.innerHTML="";}
 const b=document.getElementById("beslot_done");
 const b2=document.getElementById("beslot");
 if(which==="boxedit_rev"){if(b)b.innerHTML=""}
 else{
  if(which!=="boxedit"){if(b)b.innerHTML=""}
  if(b2)b2.innerHTML="";
  if(which!=="review"){
   const rev=document.getElementById("review");if(rev)rev.remove();}
 }
}

async function loadCompare(){
 showPanel("compare");
 const d=await (await fetch(`api/jobs/${CUR}/detections`)).json();
 const c=document.getElementById("compare");
 c.innerHTML=`<div class="row" style="margin-top:8px">t=
  <input type="range" id="cmpT" min="0" max="${d.duration.toFixed(1)}" step="0.2"
   value="0" style="flex:1" oninput="cmpShow()">
  <span id="cmpLbl">0s</span></div>
  <div class="grid2"><div><b>Original</b><br><img id="cmpO" style="max-width:100%"></div>
  <div><b>Redacted</b><br><img id="cmpR" style="max-width:100%"></div></div>`;
 cmpShow();
}
function cmpShow(){
 const t=document.getElementById("cmpT").value;
 document.getElementById("cmpLbl").textContent=t+"s";
 document.getElementById("cmpO").src=`api/jobs/${CUR}/frame_at?t=${t}`;
 document.getElementById("cmpR").src=`api/jobs/${CUR}/frame_at?t=${t}&src=output`;
}

async function loadReview(){
 showPanel("review");
 const d=await (await fetch(`api/jobs/${CUR}/detections`)).json();
 DUR=d.duration;
 const groups={}; const zdrop=[]; TRKMEM={};
 d.detections.forEach(x=>{
  EN[x.i]=x.enabled;
  if(x.zone_dropped){zdrop.push(x);return;}
  (groups[x.category]=groups[x.category]||[]).push(x);});
 let html=`<div class="card" id="review"><h2>Review — red = will be blurred,
 green = kept visible. Drag a box around several to bulk-set.</h2>
 <div class="row" style="margin:0 0 8px">
  <button class="sec" onclick="loadBoxEdit(1)">▶ Preview video &amp; edit boxes
  (before rendering)</button></div>
 <div id="beslot"></div>
 <div id="detwrap" style="position:relative;user-select:none">`;
 if(zdrop.length){
  html+=`<details style="margin:4px 0 10px;border:1px dashed #f59e0b;border-radius:9px;padding:8px 10px;background:#26200a">
   <summary style="cursor:pointer;color:#fbbf24;font-weight:600">
    ⚠ ${zdrop.length} detection(s) outside your zones — NOT blurred
    (mostly logos/labels by design; open only if something real was zoned out)
   </summary>
   <div class="row" style="margin:8px 0 4px">
    <button class="sec" onclick="setAllZd(true)">blur all of these</button>
    <button class="sec" onclick="setAllZd(false)">keep all</button></div>
   <div class="grid3">`;
  for(const x of zdrop){
   html+=`<div class="det ${EN[x.i]?'':'off'}" id="det${x.i}" data-cat="zdrop">
    <img src="api/jobs/${CUR}/thumb/${x.i}" loading="lazy"
     style="cursor:zoom-in" onclick="zoomDet(${x.i})" onerror="thumbRetry(this)">
    <div>"${x.text}" <br>${x.t_start.toFixed(1)}–${x.t_end.toFixed(1)}s</div>
    <button class="blurbtn ${EN[x.i]?"blur":"keep"}" id="bb${x.i}"
     onclick="toggleDet(${x.i})">${EN[x.i]?"Blur":"Keep"}</button>
   </div>`;
  }
  html+=`</div></details>`;
 }
 for(const[cat,rawItems] of Object.entries(groups)){
  // collapse dense tracks: one card per physical object, not per frame
  const byGroup={},items=[];
  for(const x of rawItems){
   // identity first: one card per PERSON (all their tracks); then per
   // track; ungrouped detections stand alone
   const key=x.person>=0?("p"+x.person):(x.track>=0?("t"+x.track):null);
   if(key){(byGroup[key]=byGroup[key]||[]).push(x);}
   else{TRKMEM[x.i]=[x.i];items.push(x);}
  }
  for(const [key,members] of Object.entries(byGroup)){
   members.sort((a,b)=>a.t_start-b.t_start);
   let best=members[0];             // clearest thumbnail = highest-confidence
   for(const m of members)if((m.confidence||0)>(best.confidence||0))best=m;
   const rep={...best};
   rep.t_start=members[0].t_start;
   rep.t_end=members[members.length-1].t_end;
   rep.frames=members.length;
   rep.personcard=key[0]==="p";
   TRKMEM[rep.i]=members.map(m=>m.i);
   items.push(rep);
  }
  // person cards first, then everything else chronologically
  items.sort((a,b)=>((b.personcard?1:0)-(a.personcard?1:0))||a.t_start-b.t_start);
  html+=`<h3 style="margin:10px 0 6px">${CATDN[cat]||cat} <span class="badge">${items.length}</span>
  <button class="sec" style="padding:3px 8px;font-size:12px"
   onclick="setAll('${cat}',true)">all on</button>
  <button class="sec" style="padding:3px 8px;font-size:12px"
   onclick="setAll('${cat}',false)">all off</button></h3><div class="grid3">`;
  for(const x of items){
   html+=`<div class="det ${EN[x.i]?'':'off'}" id="det${x.i}" data-cat="${cat}">
    <img src="api/jobs/${CUR}/thumb/${x.i}"
     style="cursor:zoom-in" onclick="zoomDet(${x.i})"
     onerror="thumbRetry(this)">
    <div>${x.personcard?`<b>Person ${x.person+1}</b> — one decision for ALL their appearances`:`"${x.text}"`}${x.frames?` <span class="badge">×${x.frames} frames</span>`:""}${x.confidence?` <span class="badge" title="detector confidence — low values on a non-face thumbnail usually mean a false detection">${Math.round(x.confidence*100)}%</span>`:""} <br>${x.t_start.toFixed(1)}–${x.t_end.toFixed(1)}s</div>
    <button class="blurbtn ${EN[x.i]?"blur":"keep"}" id="bb${x.i}"
     onclick="toggleDet(${x.i})">${EN[x.i]?"Blur":"Keep"}</button>
   </div>`}
  html+=`</div>`}
 html+=`</div>
 <div class="row" style="margin-top:12px">
 <button onclick="saveAndRender()">Save edits &amp; render</button>
 <span style="font-size:12px;color:#94a3b8">missed something? use
  ▶ Preview video &amp; edit boxes above — its ＋ Add box replaces the old
  add-region tool</span></div></div>`;
 const old=document.getElementById("review"); if(old)old.remove();
 detail.insertAdjacentHTML("beforeend",html);
 initMarquee();
}

let TRKMEM={};
function applyDet(i,blur){
 for(const m of (TRKMEM[i]||[i]))EN[m]=blur;
 const b=document.getElementById("bb"+i),t=document.getElementById("det"+i);
 if(b){b.className="blurbtn "+(blur?"blur":"keep");
       b.textContent=blur?"Blur":"Keep";}
 if(t)t.classList.toggle("off",!blur);
 if(document.getElementById("beCv")){beFilter();beDraw();}   // live sync
}
function toggleDet(i){applyDet(i,!EN[i]);}
function setAll(cat,on){document.querySelectorAll(`.det[data-cat=${cat}]`)
 .forEach(el=>applyDet(+el.id.slice(3),on));}
function thumbRetry(img){
 const n=+(img.dataset.r||0);
 if(n>=3)return;
 img.dataset.r=n+1;
 setTimeout(()=>{img.src=img.src.split("?r=")[0]+"?r="+Date.now();},
            600*(n+1));
}
function setAllZd(on){document.querySelectorAll(`.det[data-cat=zdrop]`)
 .forEach(el=>applyDet(+el.id.slice(3),on));}

let selSet=new Set(),marqEl=null,menuEl=null,mStart=null;
function clearSel(){
 selSet.forEach(i=>{const t=document.getElementById("det"+i);
  if(t)t.classList.remove("selected");});
 selSet.clear();
 if(menuEl){menuEl.remove();menuEl=null;}
}
function initMarquee(){
 const wrap=document.getElementById("detwrap");
 if(!wrap||wrap.dataset.mq)return;
 wrap.dataset.mq=1;
 wrap.addEventListener("pointerdown",e=>{
  if(e.pointerType==="touch")return;         // touch keeps normal scrolling
  if(e.target.closest("button"))return;      // button clicks stay clicks
  clearSel();
  mStart=[e.pageX,e.pageY];
  marqEl=document.createElement("div");marqEl.className="marq";
  document.body.appendChild(marqEl);
  const move=ev=>{
   const x1=Math.min(mStart[0],ev.pageX),y1=Math.min(mStart[1],ev.pageY),
         x2=Math.max(mStart[0],ev.pageX),y2=Math.max(mStart[1],ev.pageY);
   Object.assign(marqEl.style,{left:x1+"px",top:y1+"px",
    width:(x2-x1)+"px",height:(y2-y1)+"px"});
  };
  const up=ev=>{
   document.removeEventListener("pointermove",move);
   document.removeEventListener("pointerup",up);
   const r=marqEl.getBoundingClientRect();
   marqEl.remove();marqEl=null;
   if(r.width<8&&r.height<8)return;          // just a click — not a drag
   document.querySelectorAll("#detwrap .det").forEach(t=>{
    const b=t.getBoundingClientRect();
    if(b.left<r.right&&b.right>r.left&&b.top<r.bottom&&b.bottom>r.top){
     selSet.add(+t.id.slice(3));t.classList.add("selected");}});
   if(selSet.size)showSelMenu(ev.pageX,ev.pageY);
  };
  document.addEventListener("pointermove",move);
  document.addEventListener("pointerup",up);
  e.preventDefault();
 });
}
function showSelMenu(x,y){
 menuEl=document.createElement("div");menuEl.className="selmenu";
 menuEl.innerHTML=`<span>${selSet.size} selected</span>
  <button class="mkeep" onclick="bulkSet(false)">Keep</button>
  <button class="mblur" onclick="bulkSet(true)">Blur</button>`;
 Object.assign(menuEl.style,{left:x+"px",top:(y+10)+"px"});
 document.body.appendChild(menuEl);
}
function bulkSet(blur){selSet.forEach(i=>applyDet(i,blur));clearSel();}
document.addEventListener("pointerdown",e=>{
 if(menuEl&&!e.target.closest(".selmenu")
    &&!e.target.closest("#detwrap"))clearSel();});
// "?" help tips: keep the bubble fully on screen (a tip beside a phone's
// screen edge used to be cut off), and a tap on a "?" inside a checkbox
// label must open the tip, not tick the box
function qmPlace(q){
 const w=Math.min(250,window.innerWidth-24),r=q.getBoundingClientRect(),
       c=r.left+r.width/2;
 let dx=0;
 if(c-w/2<12)dx=12-(c-w/2);
 else if(c+w/2>window.innerWidth-12)dx=(window.innerWidth-12)-(c+w/2);
 q.style.setProperty("--qw",w+"px");q.style.setProperty("--qx",dx+"px");
 q.classList.toggle("below",r.top<260);}   // no room above: open downward
document.addEventListener("mouseover",e=>{
 const q=e.target.closest&&e.target.closest(".qm");if(q)qmPlace(q);});
document.addEventListener("click",e=>{
 const q=e.target.closest(".qm");
 document.querySelectorAll(".qm.open").forEach(x=>{if(x!==q)x.classList.remove("open");});
 if(q){e.preventDefault();qmPlace(q);q.classList.toggle("open");}});
document.addEventListener("keydown",e=>{
 if(e.key==="Escape"){clearSel();
  const lb=document.getElementById("lb");if(lb)lb.remove();}});

async function saveAndRender(){
 const manual=[...MAN,...BE.adds.map(a=>({t_start:a.t0,t_end:a.t1,
  t_ref:a.tref,screen_box:a.box}))];
 const payload={enabled:EN,manual,box_overrides:BE.ov,
   time_overrides:BE.times};
 // only send audio spans when the box editor actually loaded them —
 // otherwise a save from plain review would wipe stored spans with []
 if(Array.isArray(BE.audio)&&BE.tlspans!==undefined)payload.audio=BE.audio;
 const r=await (await fetch(`api/jobs/${CUR}/detections`,{method:"POST",
  headers:{"Content-Type":"application/json"},
  body:JSON.stringify(payload)})).json();
 BE.adds=[];BE.ov={};BE.times={};
 if(r.suggest_allowlist&&r.suggest_allowlist.length){
  if(confirm("You disabled every instance of: "+r.suggest_allowlist.join(", ")+". Add these to the permanent allow-list so future scans skip them?"))
   {await fetch("api/allowlist",{method:"POST",
    headers:{"Content-Type":"application/json"},
    body:JSON.stringify({words:r.suggest_allowlist})});
    loadPersist();}}
 MAN=[];
 await fetch(`api/jobs/${CUR}/render`,{method:"POST"});
 const rv=document.getElementById("review"); if(rv)rv.remove();
}
async function loadPersist(){
 const a=await (await fetch("api/allowlist")).json();
 const el=document.getElementById("persistlist"),
       nt=document.getElementById("persistnote");
 el.innerHTML=(a.words||[]).map(x=>
  `<div class="pw">${x}<span title="remove from allow-list"
    onclick="rmPersist('${x.replace(/'/g,"")}')">✕</span></div>`).join("");
 if((a.words||[]).length){
  nt.style.display="block";
  nt.textContent="Green words load automatically from "+a.path+
   " — marked safe during previous reviews. They are always applied in "+
   "addition to anything typed above. Click ✕ to remove one.";
 }else nt.style.display="none";
 document.getElementById("clearpersist").style.display=
  (a.words||[]).length?"inline-block":"none";
}
async function clearPersist(){
 if(!confirm("Remove ALL learned safe words? Future scans will flag them again until re-reviewed."))return;
 await fetch("api/allowlist",{method:"POST",
  headers:{"Content-Type":"application/json"},
  body:JSON.stringify({clear:true})});
 loadPersist();
}
async function rmPersist(word){
 await fetch("api/allowlist",{method:"POST",
  headers:{"Content-Type":"application/json"},
  body:JSON.stringify({remove:[word]})});
 loadPersist();
}
async function loadCertInfo(){
 try{
  const c=await (await fetch("api/certinfo")).json();
  document.getElementById("certinfo").textContent=
   `Current: ${c.mode} certificate — ${c.subject}, expires ${c.expires}`;
 }catch(e){
  document.getElementById("certinfo").textContent=
   "Running over plain HTTP (started with --http).";
 }
}
async function uploadCerts(){
 const cf=document.getElementById("certfile").files[0],
       kf=document.getElementById("keyfile").files[0];
 if(!cf||!kf){alert("Choose both a certificate file and a key file.");return;}
 const fd=new FormData();fd.append("cert",cf);fd.append("key",kf);
 const r=await fetch("api/certs",{method:"POST",body:fd});
 alert(r.ok?(await r.json()).note:"Upload failed: "+await r.text());
 loadCertInfo();
}
async function removeCerts(){
 if(!confirm("Remove the custom certificate and return to self-signed on next restart?"))return;
 const r=await fetch("api/certs",{method:"DELETE"});
 alert((await r.json()).note);
 loadCertInfo();
}
async function updCheck(){
 try{
  const d=await (await fetch("/api/update_check")).json();
  if(!d.available)return;
  const el=document.getElementById("upd");
  if(d.can_update===false){
   // Docker/Podman: the in-place updater would write into the ephemeral
   // container and be lost on recreate — inform only, never offer.
   el.innerHTML='· <span style="color:#fbbf24" title="Pull the new image tag and recreate the container — job data lives in the mounted volume and is preserved.">v'
    +d.latest+' available — pull the new image to update</span> ';
  }else{
   el.innerHTML='· <a href="#" style="color:#fbbf24" onclick="updRun();return false">v'
    +d.latest+' available — update</a> ';
  }
 }catch(e){}
}
async function updRun(){
 if(!confirm("Update OpenScrub to the newest release now?\\n\\nJobs must be idle, and the server needs a restart afterwards to run the new version."))return;
 const r=await fetch("/api/update_run",{method:"POST"});
 if(!r.ok){alert(await r.text());return;}
 const el=document.getElementById("upd");
 el.textContent="· updating… ";
 const t=setInterval(async()=>{
  const s=await (await fetch("/api/update_status")).json();
  if(!s.running&&s.ok!==null){
   clearInterval(t);
   el.textContent=s.ok?"· updated — restart the server to finish ":"· update failed ";
   alert((s.ok?"Update installed.\\nRestart the OpenScrub server to run the new version.":"Update failed:")+"\\n\\n"+s.log.slice(-8).join("\\n"));
  }
 },2000);
}
async function vaultStatus(){
 try{
  const d=await (await fetch("/api/vault")).json();
  const st=document.getElementById("vstat");
  document.getElementById("vsetup").style.display=d.enabled?"none":"block";
  document.getElementById("vunlock").style.display=(d.enabled&&d.locked)?"flex":"none";
  document.getElementById("vlock").style.display=(d.enabled&&!d.locked)?"flex":"none";
  if(!d.enabled){st.textContent="Disabled — job files (PII) are stored in plaintext. Set a password to enable at-rest encryption.";st.style.color="#fbbf24";}
  else if(d.locked){st.textContent="LOCKED — "+d.encrypted_files+" file(s) encrypted on disk. Unlock to work with jobs.";st.style.color="#f87171";}
  else{st.textContent="Unlocked — files decrypt while you work; they re-encrypt when you lock or shut down. Losing the password makes encrypted files unrecoverable.";st.style.color="#4ade80";}
  if(d.enabled&&!d.locked){
   document.getElementById("valk").checked=d.autolock_min>0;
   if(d.autolock_min>0)document.getElementById("valkmin").value=d.autolock_min;
  }
 }catch(e){}
}
async function vaultSetup(){
 const a=document.getElementById("vpw1").value,b=document.getElementById("vpw2").value;
 if(a.length<8){alert("Password must be at least 8 characters.");return;}
 if(a!==b){alert("Passwords do not match.");return;}
 if(!confirm("Enable at-rest encryption?\\n\\nTHERE IS NO PASSWORD RESET. If you lose this password, every encrypted job file is PERMANENTLY UNRECOVERABLE.\\n\\nContinue?"))return;
 const r=await fetch("/api/vault/setup",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({password:a})});
 alert(r.ok?(await r.json()).note:await r.text());
 vaultStatus();
}
async function vaultUnlock(){
 const r=await fetch("/api/vault/unlock",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({password:document.getElementById("vpw").value})});
 if(!r.ok){alert(await r.text());return;}
 document.getElementById("vpw").value="";
 vaultStatus();loadJobs();
}
async function vaultAutolockSave(){
 const on=document.getElementById("valk").checked;
 const m=on?parseInt(document.getElementById("valkmin").value||"30",10):0;
 await fetch("/api/vault/autolock",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({minutes:m})});
 vaultStatus();
}
async function vaultDoLock(){
 if(!confirm("Encrypt all job files now?\\n\\nYou will need the password to access them again."))return;
 const r=await fetch("/api/vault/lock",{method:"POST"});
 alert(r.ok?("Locked — "+(await r.json()).encrypted+" file(s) encrypted."):await r.text());
 vaultStatus();loadJobs();
}
let EXTPOLL=null;
async function extrasStatus(){
 try{
  const d=await (await fetch("/api/extras")).json();
  const el=document.getElementById("extras");
  if(d.frozen){el.innerHTML='This standalone install has no pip, so optional engines cannot be added here. Use the pip install of OpenScrub (<code>pip install "OpenScrub[ner]"</code>) if you need spaCy NER or PaddleOCR.';return;}
  el.innerHTML=d.items.map(i=>{
   let right;
   if(i.installed)right='<span style="color:#4ade80">installed</span>';
   else if(d.state==="installing"&&d.target===i.id)right='<span style="color:#fbbf24">installing… '+(d.log.length?d.log[d.log.length-1]:'')+'</span>';
   else right=`<button onclick="extraInstall('${i.id}')">Install</button>`;
   return '<div class="row" style="justify-content:space-between;gap:10px;padding:5px 0"><span><b>'+i.label+'</b><br><span style="color:#94a3b8;font-size:12px">'+i.desc+'</span></span>'+right+'</div>';
  }).join("");
  if(d.state==="installing"){if(!EXTPOLL)EXTPOLL=setInterval(extrasStatus,3000);}
  else if(EXTPOLL){clearInterval(EXTPOLL);EXTPOLL=null;
   if(d.state==="error")alert("Engine install failed:\\n"+d.log.join("\\n"));}
 }catch(e){}
}
async function extraInstall(id){
 const r=await fetch("/api/extras/"+id+"/install",{method:"POST"});
 if(!r.ok){alert(await r.text());return;}
 extrasStatus();
}
loadPersist();loadCertInfo();loadJobs();setInterval(loadJobs,5000);
function showView(){
 const s=location.hash==="#settings";
 document.getElementById("mainview").style.display=s?"none":"block";
 document.getElementById("settingsview").style.display=s?"block":"none";
 if(s)window.scrollTo(0,0);
}
window.addEventListener("hashchange",showView);
updCheck();vaultStatus();extrasStatus();showView();
"""

PAGE = (zones_ui.ZONES_PAGE
        .replace("%%FAVICON%%", FAVICON_URI)
        .replace("%%LOGO%%", LOGO_URI)
        .replace("%%WORDMARK%%", WORDMARK_URI)
        .replace("%%APP_CSS%%", APP_CSS)
        .replace("%%JOBS_HTML%%", JOBS_HTML)
        .replace("%%SETTINGS_HTML%%", SETTINGS_HTML)
        .replace("%%FOOT_HTML%%", FOOT_HTML)
        .replace("%%APP_JS%%", APP_JS))


ASSET_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets")
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


# ----------------------------------------------------------------------------
# Self-update (openscrub_update.py does the heavy lifting). The update
# endpoints refuse to run while any job is queued or processing, and an
# installed update only takes effect after the server restarts.
# ----------------------------------------------------------------------------
try:
    import openscrub_update
except Exception:                       # module missing: endpoints degrade
    openscrub_update = None

UPD = {"running": False, "log": [], "ok": None, "cache": (0.0, None)}
UPD_LOCK = threading.Lock()


def _in_container():
    """True inside Docker/Podman. The in-place updater writes into the
    container's ephemeral filesystem — the "update" would vanish on the
    next recreate while the UI claimed success. Containers update by
    pulling the new image, so the web UI must inform, never offer."""
    return (os.environ.get("OPENSCRUB_IN_DOCKER", "") not in ("", "0")
            or os.path.exists("/.dockerenv")
            or os.path.exists("/run/.containerenv"))


@app.route("/api/update_check")
def update_check():
    if openscrub_update is None:
        return jsonify({"current": openscrub.VERSION, "latest": None,
                        "available": False, "can_update": False})
    now = time.time()
    with UPD_LOCK:
        ts, latest = UPD["cache"]
        if now - ts > 6 * 3600 or request.args.get("force"):
            try:
                latest = openscrub_update.get_latest(timeout=6)
            except Exception:
                latest = None       # offline / PyPI down: just no notice
            UPD["cache"] = (now, latest)
    avail = bool(latest and openscrub_update.is_newer(latest["version"],
                                                      openscrub.VERSION))
    return jsonify({"current": openscrub.VERSION,
                    "latest": latest["version"] if latest else None,
                    "available": avail,
                    "can_update": not _in_container()})


@app.route("/api/update_run", methods=["POST"])
def update_run():
    if _in_container():
        abort(400, "running in a container — update by pulling the new "
                   "image and recreating the container (job data lives in "
                   "the mounted volume and is preserved)")
    if openscrub_update is None:
        abort(400, "updater module not available")
    with JOBS_LOCK:
        busy = any(j.get("phase") in ("queued", "scanning", "rendering",
                                      "queued_render")
                   for j in JOBS.values())
    if busy:
        abort(409, "a job is queued or running — update after it finishes")
    with UPD_LOCK:
        if UPD["running"]:
            return jsonify({"started": False, "reason": "already running"})
        UPD["running"], UPD["log"], UPD["ok"] = True, [], None

    def _go():
        def log(msg):
            with UPD_LOCK:
                UPD["log"].append(str(msg))
        try:
            openscrub_update.run_update(log=log)
            ok = True
        except Exception as e:
            log("update failed: %s" % e)
            ok = False
        with UPD_LOCK:
            UPD["ok"], UPD["running"] = ok, False

    threading.Thread(target=_go, daemon=True).start()
    return jsonify({"started": True})


@app.route("/api/update_status")
def update_status():
    with UPD_LOCK:
        return jsonify({"running": UPD["running"], "ok": UPD["ok"],
                        "log": list(UPD["log"])})


# ----------------------------------------------------------------------------
# Vault: password-based at-rest encryption of the job store (PII!).
# LOCKED = job files encrypted on disk, job APIs refuse to run.
# UNLOCKED = decrypted in place so the pipeline works unchanged.
# NO PASSWORD RESET EXISTS — a lost password means the data is gone.
# ----------------------------------------------------------------------------
import openscrub_vault as vault

VAULT = {"key": None}          # data key while unlocked; None = locked
VAULT_LOCK = threading.Lock()
WEB_SETTINGS_PATH = os.path.join(_data_root(), "web_settings.json")
LAST_ACTIVITY = {"t": time.time()}


def _web_settings():
    try:
        with open(WEB_SETTINGS_PATH, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def _save_web_settings(d):
    with open(WEB_SETTINGS_PATH, "w", encoding="utf-8") as f:
        json.dump(d, f, indent=2)


def _autolock_watcher():
    """Opt-in: when enabled in App settings, re-lock the vault after N
    minutes with no web activity and no running jobs. Default OFF —
    people should never find their data locked unless they asked for it."""
    while True:
        time.sleep(30)
        try:
            mins = int(_web_settings().get("vault_autolock_min", 0) or 0)
            if mins <= 0 or not vault_enabled() or VAULT["key"] is None:
                continue
            if time.time() - LAST_ACTIVITY["t"] < mins * 60:
                continue
            with JOBS_LOCK:
                busy = any(j.get("phase") in ("queued", "scanning",
                                              "rendering", "queued_render")
                           for j in JOBS.values())
            if busy:
                continue
            n = _vault_lock_now()
            print("vault: auto-locked after %d idle minute(s) — "
                  "%d file(s) encrypted" % (mins, n))
        except Exception:
            pass


def vault_enabled():
    return vault.keystore_exists(_data_root())


def vault_locked():
    return vault_enabled() and VAULT["key"] is None


def _vault_lock_now():
    """Encrypt the job store and forget the key. Returns files encrypted."""
    with VAULT_LOCK:
        key = VAULT["key"]
        if key is None:
            return 0
        n = vault.encrypt_tree(key, JOBS_DIR)
        VAULT["key"] = None
        return n


def _vault_lock_atexit():
    try:
        if vault_enabled() and VAULT["key"] is not None:
            busy = any(j.get("phase") in ("queued", "scanning", "rendering",
                                          "queued_render") for j in JOBS.values())
            if busy:
                print("vault: NOT locking on exit — a job was still running; "
                      "job files remain in plaintext. Restart and lock.")
                return
            n = _vault_lock_now()
            print("vault: locked on shutdown (%d file(s) encrypted)" % n)
    except Exception as e:
        # never die silently here: a swallowed error means plaintext on disk
        print("vault: LOCK ON SHUTDOWN FAILED (%s) — job files may remain "
              "in plaintext. Restart the server and use the Lock button." % e)


@app.route("/api/vault")
def vault_status():
    enc, plain = (0, 0)
    if vault_enabled():
        enc, plain = vault.tree_locked_state(JOBS_DIR)
    return jsonify({"enabled": vault_enabled(), "locked": vault_locked(),
                    "encrypted_files": enc, "plaintext_files": plain,
                    "autolock_min": int(_web_settings().get(
                        "vault_autolock_min", 0) or 0)})


@app.route("/api/vault/setup", methods=["POST"])
def vault_setup():
    pw = (request.json or {}).get("password") or ""
    if vault_enabled():
        abort(409, "vault already set up")
    if len(pw) < 8:
        abort(400, "password must be at least 8 characters")
    with VAULT_LOCK:
        VAULT["key"] = vault.create_keystore(_data_root(), pw)
    return jsonify({"ok": True, "note":
                    "Encryption enabled. Jobs encrypt when you lock or "
                    "shut down. LOSING THIS PASSWORD MAKES THE ENCRYPTED "
                    "FILES PERMANENTLY UNRECOVERABLE."})


@app.route("/api/vault/unlock", methods=["POST"])
def vault_unlock():
    pw = (request.json or {}).get("password") or ""
    if not vault_enabled():
        abort(400, "vault is not set up")
    try:
        key = vault.open_keystore(_data_root(), pw)
    except ValueError:
        abort(403, "wrong password")
    with VAULT_LOCK:
        VAULT["key"] = key
        n = vault.decrypt_tree(key, JOBS_DIR)
    rehydrate_jobs()               # pick up jobs that were locked at startup
    return jsonify({"ok": True, "decrypted": n})


# ----------------------------------------------------------------------------
# Optional engines (spaCy NER, PaddleOCR) — installable from the web UI on
# pip/folder installs. Frozen (Program Files) builds have no pip, so the
# endpoints report that instead of pretending.
# ----------------------------------------------------------------------------
# ----------------------------------------------------------------------------
# Custom regex categories — user-defined, stored in the data root, injected
# into the category checkboxes, job args, and the zones page.
# ----------------------------------------------------------------------------
CUSTOM_CATS_PATH = os.path.join(_data_root(), "custom_categories.json")
BUILTIN_CATS = {"name", "dob", "phone", "ssn", "mrn", "email", "address",
                "card", "apikey", "ipaddr", "plate", "face", "person",
                "qrcode", "screen", "anytext", "manual", "bank", "crypto",
                "passport", "phrase"}


def load_custom_cats():
    try:
        with open(CUSTOM_CATS_PATH, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return []


def _cat_color(cid):
    import colorsys, hashlib
    h = int(hashlib.sha256(cid.encode()).hexdigest()[:6], 16) / 0xFFFFFF
    r, g, b = colorsys.hls_to_rgb(h, 0.45, 0.75)
    return "#%02x%02x%02x" % (int(r * 255), int(g * 255), int(b * 255))


def _regex_min_width(pattern):
    """Shortest text a regex can match, from its parse tree (0 = it can
    match empty text). Pure analysis — the pattern is never executed."""
    try:
        from re import _parser as sre      # Python 3.11+
    except ImportError:                      # pragma: no cover — 3.10
        import sre_parse as sre
    try:
        return sre.parse(pattern).getwidth()[0]
    except Exception:
        return 0                             # unparseable: treat as unsafe


@app.route("/api/custom_cats", methods=["GET", "POST"])
def custom_cats():
    cats = load_custom_cats()
    if request.method == "GET":
        return jsonify(cats)
    d = request.json or {}
    name = (d.get("name") or "").strip()
    pattern = (d.get("regex") or "").strip()
    if not name:
        abort(400, "the category needs a name")
    cid = "".join(ch for ch in name.lower().replace(" ", "_")
                  if ch.isalnum() or ch == "_")[:24]
    if not cid:
        abort(400, "name must contain letters or digits")
    if cid in BUILTIN_CATS or any(c["id"] == cid for c in cats):
        abort(409, "a category with that name already exists")
    try:
        import re as _re
        _re.compile(pattern)          # syntax check only — never executed
    except Exception as e:
        abort(400, "invalid regex: %s" % e)
    if not pattern:
        abort(400, "a regex pattern is required")
    # a pattern that can match EMPTY text "matches" every OCR word (e.g.
    # `\d*`, `x|`, `\b`) — the category would blur the whole screen.
    # Decided STATICALLY from the parsed pattern's minimum match width,
    # never by running the user's regex here: executing request-supplied
    # patterns on the server is a ReDoS risk (code-scanning #22,
    # py/regex-injection — the v1.0.91 version test-ran it on samples).
    if _regex_min_width(pattern) == 0:
        abort(400, "this pattern can match empty text, so it would blur "
                   "every word — make it require at least one character "
                   "(for example use + instead of *)")
    cats.append({"id": cid, "label": name, "regex": pattern,
                 "color": _cat_color(cid)})
    with open(CUSTOM_CATS_PATH, "w", encoding="utf-8") as f:
        json.dump(cats, f, indent=2)
    return jsonify({"ok": True, "id": cid})


@app.route("/api/custom_cats/<cid>", methods=["DELETE"])
def custom_cats_delete(cid):
    cats = [c for c in load_custom_cats() if c["id"] != cid]
    with open(CUSTOM_CATS_PATH, "w", encoding="utf-8") as f:
        json.dump(cats, f, indent=2)
    return jsonify({"ok": True})


def _spec(name):
    import importlib.util
    try:
        return importlib.util.find_spec(name) is not None
    except Exception:
        return False


EXTRAS = {
    "ner": {
        "label": "spaCy NER (name detection)",
        "desc": "The primary name detector. Without it, names rely on "
                "the built-in heuristics.",
        "pip": ["spacy"],
        "post": [["-m", "spacy", "download", "en_core_web_sm"]],
        "check": lambda: _spec("spacy") and _spec("en_core_web_sm"),
    },
    "paddle": {
        "label": "PaddleOCR — CPU (better OCR on small fonts)",
        "desc": "Stronger OCR engine, picked automatically once "
                "installed. Large download.",
        "pip": ["paddleocr", "paddlepaddle"],
        "post": [],
        "check": lambda: _spec("paddleocr") and _spec("paddle"),
    },
    "paddle_gpu": {
        "label": "PaddleOCR — NVIDIA GPU (CUDA 12.x)",
        "desc": "GPU-accelerated build for NVIDIA cards — much faster "
                "OCR. Very large download. Shows installed if either "
                "Paddle build is present.",
        "pip": ["paddleocr", "paddlepaddle-gpu==3.2.2", "-i",
                "https://www.paddlepaddle.org.cn/packages/stable/cu126/"],
        "post": [["-m", "pip", "install", "-U", "nvidia-cudnn-cu12"]],
        "check": lambda: _spec("paddleocr") and _spec("paddle"),
    },
}
_EXT = {"state": "idle", "target": "", "log": []}


@app.route("/api/extras")
def extras_status():
    frozen = bool(getattr(sys, "frozen", False))
    items = [{"id": k, "label": v["label"], "desc": v["desc"],
              "installed": (False if frozen else v["check"]())}
             for k, v in EXTRAS.items()]
    return jsonify({"frozen": frozen, "items": items,
                    "state": _EXT["state"], "target": _EXT["target"],
                    "log": _EXT["log"][-4:]})


@app.route("/api/extras/<eid>/install", methods=["POST"])
def extras_install(eid):
    if getattr(sys, "frozen", False):
        abort(400, "this is a standalone (Program Files) install without "
                   "pip — optional engines need the pip install of "
                   "OpenScrub")
    spec = EXTRAS.get(eid) or abort(404)
    if _EXT["state"] == "installing":
        abort(409, "another install is already running")
    _EXT.update(state="installing", target=eid, log=[])

    def work():
        import subprocess
        try:
            cmds = [[sys.executable, "-m", "pip", "install"] + spec["pip"]]
            cmds += [[sys.executable] + p for p in spec["post"]]
            for cmd in cmds:
                _EXT["log"].append("$ " + " ".join(cmd[1:]))
                r = subprocess.run(cmd, capture_output=True, text=True)
                if r.returncode != 0:
                    tail = (r.stderr or r.stdout or "").strip().splitlines()
                    _EXT["log"] += tail[-3:] or ["exit %d" % r.returncode]
                    _EXT["state"] = "error"
                    return
            _EXT["log"].append("done — takes effect on the next scan")
            _EXT["state"] = "done"
        except Exception as e:
            _EXT["log"].append(str(e))
            _EXT["state"] = "error"
    threading.Thread(target=work, daemon=True).start()
    return jsonify({"ok": True})


@app.route("/api/vault/autolock", methods=["POST"])
def vault_autolock():
    mins = int((request.json or {}).get("minutes") or 0)
    if mins < 0 or mins > 24 * 60:
        abort(400, "minutes must be between 0 (off) and 1440")
    d = _web_settings()
    d["vault_autolock_min"] = mins
    _save_web_settings(d)
    return jsonify({"ok": True, "autolock_min": mins})


@app.route("/api/vault/lock", methods=["POST"])
def vault_lock_route():
    with JOBS_LOCK:
        busy = any(j.get("phase") in ("queued", "scanning", "rendering",
                                      "queued_render")
                   for j in JOBS.values())
    if busy:
        abort(409, "a job is queued or running — lock after it finishes")
    n = _vault_lock_now()
    return jsonify({"ok": True, "encrypted": n})


@app.route("/license")
def license_page():
    p = os.path.join(SCRIPT_DIR, "LICENSE")
    if os.path.exists(p):
        with open(p, encoding="utf-8") as f:
            body = f.read()
    else:
        body = ("OpenScrub is licensed under the Apache License 2.0.\n"
                "See https://www.apache.org/licenses/LICENSE-2.0")
    from flask import Response
    return Response(body, mimetype="text/plain")


@app.route("/logo.png")
def logo():
    p = os.path.join(ASSET_DIR, "logo.png")
    if not os.path.exists(p):
        abort(404)
    return send_file(p,
                     mimetype="image/png", max_age=86400)


@app.route("/logo_dark.png")
def logo_dark():
    p = os.path.join(ASSET_DIR, "logo_dark.png")
    if not os.path.exists(p):
        abort(404)
    return send_file(p,
                     mimetype="image/png", max_age=86400)


@app.route("/favicon.ico")
def favicon():
    p = os.path.join(ASSET_DIR, "openscrub.ico")
    if not os.path.exists(p):
        abort(404)
    return send_file(p,
                     mimetype="image/x-icon", max_age=86400)


@app.route("/")
def index():
    # inject user-defined categories into the editor's color map so they can
    # be zoned exactly like built-ins (per request: customs change at runtime)
    page = PAGE
    extra = "".join(',%s:"%s"' % (c["id"], c.get("color", "#64748b"))
                    for c in load_custom_cats())
    if extra:
        page = page.replace('face:"#ec4899"', 'face:"#ec4899"%s' % extra)
    page = page.replace("%%MAXUP%%",
                        str(app.config.get("MAX_CONTENT_LENGTH") or 0))
    # free disk at serve time, so the editor can refuse an upload that
    # cannot fit BEFORE hours of transfer (issue #16: repeated 18 GB
    # re-uploads filled the disk). The server-side guard on POST
    # /api/jobs stays authoritative — this is only the early warning.
    try:
        free = _disk_free(JOBS_DIR)
    except OSError:
        free = 0                       # unknown -> preflight disabled
    page = page.replace("%%FREEDISK%%", str(free))
    return page.replace("%%VERSION%%", openscrub.VERSION)


@app.route("/zones")
def zones_page():
    """The editor IS the homepage now; keep old bookmarks working."""
    return redirect("/")


@app.route("/api/server_video")
def server_video():
    """Stream a server-side video for the Scan Setup preview. The path is
    request data: the same server_path_error confinement that gates job
    intake runs BEFORE any filesystem access. conditional=True gives Range
    support so the <video> element can seek/scrub."""
    p = os.path.realpath(request.args.get("path", ""))
    err = server_path_error(p)
    if err:
        return jsonify({"error": err}), 400
    # Containment guard REPEATED inline: server_path_error already enforces
    # it, but CodeQL's path-injection barrier analysis is function-local —
    # the sink below must be dominated by the single-startswith shape in
    # THIS function or the alert re-opens (same lesson as the models route).
    root = os.environ.get("OPENSCRUB_MEDIA_ROOT")
    r = os.path.realpath(root) if root else os.path.realpath(
        os.path.splitdrive(p)[0] + os.sep)
    if not p.startswith(r.rstrip(os.sep) + os.sep):
        return jsonify({"error": "server path is outside OPENSCRUB_MEDIA_ROOT"}), 400
    return send_file(p, conditional=True)


@app.route("/api/waveform")
def waveform():
    """Audio peak envelope for a server-side video's track — powers the
    editor's waveform lanes. Same confinement as every server-path route:
    server_path_error runs first, and the containment guard is repeated
    inline in the CodeQL-recognized shape before any use."""
    p = os.path.realpath(request.args.get("path", ""))
    err = server_path_error(p)
    if err:
        return jsonify({"error": err}), 400
    root = os.environ.get("OPENSCRUB_MEDIA_ROOT")
    r = os.path.realpath(root) if root else os.path.realpath(
        os.path.splitdrive(p)[0] + os.sep)
    if not p.startswith(r.rstrip(os.sep) + os.sep):
        return jsonify({"error": "server path is outside OPENSCRUB_MEDIA_ROOT"}), 400
    try:
        track = max(0, min(15, int(request.args.get("track", 0) or 0)))
    except ValueError:
        track = 0
    import subprocess
    import numpy as np
    try:
        raw = subprocess.run(
            ["ffmpeg", "-v", "error", "-i", p, "-map", "a:%d" % track,
             "-ac", "1", "-ar", "1000", "-f", "s16le", "-"],
            capture_output=True, timeout=180).stdout
    except Exception:
        raw = b""
    if len(raw) < 4:
        return jsonify({"peaks": []})
    a = np.abs(np.frombuffer(raw[:len(raw) // 2 * 2], dtype=np.int16)
               .astype(np.int32))
    N = 2000
    per = max(1, len(a) // N)
    a = a[:(len(a) // per) * per].reshape(-1, per).max(axis=1)
    mx = int(a.max()) or 1
    return jsonify({"peaks": [round(float(v) / mx, 3) for v in a[:N]]})


@app.route("/api/certinfo")
def certinfo():
    cert_path, _, mode = active_cert_pair()
    from cryptography import x509
    with open(cert_path, "rb") as f:
        c = x509.load_pem_x509_certificate(f.read())
    return jsonify({
        "mode": mode,
        "subject": c.subject.rfc4514_string(),
        "issuer": c.issuer.rfc4514_string(),
        "expires": c.not_valid_after_utc.strftime("%Y-%m-%d"),
    })


@app.route("/api/certs", methods=["POST", "DELETE"])
def upload_certs():
    if request.method == "DELETE":
        for p in (CUSTOM_CERT, CUSTOM_KEY):
            if os.path.exists(p):
                os.remove(p)
        return jsonify({"ok": True,
                        "note": "custom certificate removed — restart the "
                                "server to return to the self-signed one"})
    cert_f, key_f = request.files.get("cert"), request.files.get("key")
    if not cert_f or not key_f:
        abort(400, "both certificate and key PEM files are required")
    cert_pem, key_pem = cert_f.read(), key_f.read()
    from cryptography import x509
    from cryptography.hazmat.primitives.serialization import load_pem_private_key
    try:
        cert = x509.load_pem_x509_certificate(cert_pem)
        key = load_pem_private_key(key_pem, password=None)
        if key.public_key().public_numbers() != cert.public_key().public_numbers():
            abort(400, "private key does not match the certificate")
    except ValueError as e:
        abort(400, f"could not parse PEM files: {e}")
    os.makedirs(CERT_DIR, exist_ok=True)
    with open(CUSTOM_CERT, "wb") as f:
        f.write(cert_pem)
    with open(CUSTOM_KEY, "wb") as f:
        f.write(key_pem)
    try:
        os.chmod(CUSTOM_KEY, 0o600)
    except Exception:
        pass
    return jsonify({"ok": True,
                    "note": "certificate installed — restart the server to apply"})


@app.route("/api/zones", methods=["GET", "POST"])
def api_zones():
    if request.method == "POST":
        data = request.get_json(force=True) or {}
        clean = {}
        for cat, rects in data.items():
            rs = []
            for r in rects or []:
                if len(r) == 4:
                    x1, y1, x2, y2 = [max(0.0, min(1.0, float(v))) for v in r]
                    if x2 - x1 > 0.004 and y2 - y1 > 0.004:
                        rs.append([round(x1, 4), round(y1, 4),
                                   round(x2, 4), round(y2, 4)])
            if rs:
                clean[cat] = rs
        with open(ZONES_PATH, "w", encoding="utf-8") as f:
            json.dump(clean, f, indent=1)
        return jsonify({"ok": True, "classes": len(clean)})
    if os.path.exists(ZONES_PATH):
        with open(ZONES_PATH, encoding="utf-8") as f:
            return jsonify(json.load(f))
    return jsonify({})


def lan_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


def rehydrate_jobs():
    """Re-register jobs found on disk after a restart. A job with a report
    is a reviewable job; one with an output file is a finished one — either
    way the person's work survives the server going down."""
    n = 0
    for jid in sorted(os.listdir(JOBS_DIR)):
        jdir = os.path.join(JOBS_DIR, jid)
        rep = os.path.join(jdir, "report.json")
        if not os.path.isdir(jdir):
            continue
        if os.path.exists(os.path.join(jdir, DELETE_MARKER)):
            # the user deleted this job but a file was still held open at
            # the time — finish the removal instead of resurrecting the
            # job as a zombie (restarts release whatever held the lock)
            _reap_job_dir(jdir, jid, retries=1)
            continue
        if jid in JOBS:
            continue
        if not os.path.exists(rep):
            # NO report: the scan never completed (crashed or the server
            # went down mid-scan). If the dir still holds an uploaded
            # input, surface it as a FAILED job instead of skipping it —
            # a skipped dir was an invisible orphan the UI could neither
            # retry nor delete, silently eating an 18 GB upload per
            # failed attempt (issue #16).
            up = next((os.path.join(jdir, "input" + e)
                       for e in sorted(MEDIA_EXTS)
                       if os.path.exists(os.path.join(jdir, "input" + e))),
                      None)
            if not up:
                continue
            try:
                size = os.path.getsize(up)
            except OSError:
                size = 0
            opts = {}
            try:
                with open(os.path.join(jdir, OPTIONS_FILE),
                          encoding="utf-8") as f:
                    opts = json.load(f)
                if not isinstance(opts, dict):
                    opts = {}
            except (OSError, ValueError):
                opts = {}
            job = {
                "id": jid, "dir": jdir, "video": up,
                "name": os.path.basename(up), "options": opts,
                "phase": "error", "progress": 0.0, "size": size,
                "log": ["(recovered after server restart — the scan had "
                        "not completed)"],
                "error": "recovered after a server restart before the "
                         "scan finished — Retry re-runs it with "
                         + ("its original settings" if opts else
                            "default settings")
                         + " (the uploaded file was kept), or "
                         "Delete frees its disk space",
                "output": None, "created": os.path.getmtime(jdir),
                "cancel": threading.Event(), "stats": {},
            }
            with JOBS_LOCK:
                JOBS[jid] = job
            n += 1
            continue
        try:
            with open(rep, encoding="utf-8") as f:
                prov = json.load(f).get("provenance", {})
            video = prov.get("input")
            if not video or not os.path.exists(video):
                continue
            out = os.path.join(jdir, "output.mp4")
            has_out = os.path.exists(out)
            job = {
                "id": jid, "dir": jdir, "video": video,
                "name": os.path.basename(prov.get("original_input")
                                          or video),
                "options": prov.get("settings", {}) or {},
                "phase": "done" if has_out else "review",
                "progress": 1.0 if has_out else 0.5,
                "log": ["(recovered after server restart)"],
                "error": None, "output": out if has_out else None,
                "created": os.path.getmtime(jdir),
                "cancel": threading.Event(), "stats": {},
            }
            try:
                # original upload size, for the editor's duplicate-upload
                # warning (prov input may be the normalized scan copy)
                orig = next((os.path.join(jdir, "input" + e)
                             for e in sorted(MEDIA_EXTS)
                             if os.path.exists(
                                 os.path.join(jdir, "input" + e))), video)
                job["size"] = os.path.getsize(orig)
            except OSError:
                pass
            with JOBS_LOCK:
                JOBS[jid] = job
            n += 1
        except Exception:
            continue
    if n:
        print(f"  recovered {n} job(s) from {JOBS_DIR}")


def retention_sweep(days):
    import shutil as _sh
    cutoff = time.time() - days * 86400
    for jid in os.listdir(JOBS_DIR):
        p = os.path.join(JOBS_DIR, jid)
        if not os.path.isdir(p):
            continue
        if os.path.exists(os.path.join(p, DELETE_MARKER)):
            _reap_job_dir(p, jid, retries=1)     # condemned: age-independent
            continue
        if os.path.getmtime(p) < cutoff:
            _sh.rmtree(p, ignore_errors=True)
            with JOBS_LOCK:
                JOBS.pop(jid, None)


def retention_loop(days):
    while True:
        retention_sweep(days)
        time.sleep(6 * 3600)


def main():
    global TOKEN
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=8384)
    ap.add_argument("--host", default="0.0.0.0")
    ap.add_argument("--token",
                    default=os.environ.get("OPENSCRUB_TOKEN") or None,
                    help="require this access token on every "
                    "request (default: open — anyone on the network can use "
                    "the server)")
    ap.add_argument("--http", action="store_true",
                    help="serve plain HTTP (not recommended: video uploads "
                         "and previews contain PII and would cross the "
                         "network unencrypted)")
    ap.add_argument("--retain-days", type=int, default=7,
                    help="auto-delete job folders (which contain PII) after "
                         "this many days (default 7; 0 = keep forever)")
    ap.add_argument("--max-upload-gb", default=None,
                    help="largest browser upload accepted, in GB (default 8; "
                         "0 = unlimited; env OPENSCRUB_MAX_UPLOAD_GB works "
                         "too). Very large files are better served in place "
                         "via the 'path on the server' box than uploaded.")
    args = ap.parse_args()
    TOKEN = args.token or None
    app.config["MAX_CONTENT_LENGTH"] = _max_upload_bytes(args.max_upload_gb)
    os.makedirs(JOBS_DIR, exist_ok=True)
    import atexit
    atexit.register(_vault_lock_atexit)
    # docker stop sends SIGTERM. Python's default SIGTERM disposition kills
    # the process WITHOUT running atexit hooks — and as PID 1 in a container
    # an unhandled SIGTERM is ignored outright, so the container just waits
    # out the grace period and gets SIGKILLed: either way the vault never
    # locked and job files stayed in plaintext (verified empirically).
    # sys.exit() is NOT enough here — cheroot's serve loop swallows the
    # SystemExit (also verified) — so the handler locks the vault itself and
    # then hard-exits. os._exit skips atexit, so the lock cannot run twice.
    # NOTE: encryption must finish within the stop grace period — give
    # Docker a generous one (docker stop -t 120).
    import signal
    _terming = []

    def _on_sigterm(sig, frm):
        if _terming:                      # second SIGTERM: just die
            os._exit(1)
        _terming.append(1)
        print("SIGTERM — locking vault before exit…")
        _vault_lock_atexit()
        os._exit(0)
    signal.signal(signal.SIGTERM, _on_sigterm)
    threading.Thread(target=_autolock_watcher, daemon=True).start()
    rehydrate_jobs()
    start_worker()
    threading.Thread(target=_worker_watchdog, daemon=True).start()
    if args.retain_days > 0:
        threading.Thread(target=retention_loop, args=(args.retain_days,),
                         daemon=True).start()
    print("=" * 60)
    ssl_ctx = None
    scheme = "http"
    if not args.http:
        try:
            import cryptography  # noqa: F401 — needed for cert generation
        except ImportError:
            print("=" * 60)
            print("HTTPS needs the 'cryptography' package, which isn't")
            print("installed. Fix it with ONE of these:")
            print()
            print("    pip install cryptography      (recommended)")
            print("    python install.py --yes       (installs everything)")
            print()
            print("or start with --http to serve unencrypted")
            print("(not recommended: PII would cross the network in plain text).")
            print("=" * 60)
            if os.name == "nt":
                input("Press Enter to close.")
            sys.exit(1)
        cert, key, mode = active_cert_pair()
        ssl_ctx = (cert, key)
        scheme = "https"
    in_docker = _in_container()
    # Inside a container lan_ip() returns the CONTAINER's bridge address
    # (172.17.x.x) — unreachable from a macOS/Windows host, where only the
    # published port on localhost works. A real Mac user followed that IP
    # straight to a dead end while the server sat healthy on localhost:8384
    # (and Python's block-buffered stdout kept this whole banner invisible
    # in `docker logs` — the images now set PYTHONUNBUFFERED=1).
    url_host = "localhost" if in_docker else lan_ip()
    print("openscrub web — open from any device on your LAN:")
    if TOKEN:
        print(f"    {scheme}://{url_host}:{args.port}/?token={TOKEN}")
    else:
        print(f"    {scheme}://{url_host}:{args.port}/")
        print("    (open access: no token — everyone on this network can use it;")
        print("     add --token <secret> if you ever want a gate back)")
    if in_docker:
        print("    Docker: open the PUBLISHED port on localhost (or this")
        print("    machine's LAN IP from other devices). The container's")
        print("    internal 172.17.x.x address is NOT reachable from a")
        print("    Mac/Windows host.")
    if vault_enabled():
        print("Encryption: vault is LOCKED — unlock in the web UI "
              "(Encryption panel) to access jobs."
              if vault_locked() else "Encryption: vault unlocked.")
    print("Jobs folder (contains PII):", JOBS_DIR,
          f"— auto-deleted after {args.retain_days} day(s)" if args.retain_days else "— kept forever")
    print("Do NOT expose this port to the internet.")
    print("=" * 60)
    if ssl_ctx:
        if mode == "self-signed":
            print("    HTTPS with a self-signed certificate: your browser will")
            print("    warn once — choose Advanced -> Proceed, or install your")
            print("    own certificate at the bottom of the main page.")
        else:
            print("    HTTPS with your installed custom certificate.")
    else:
        print("    WARNING: plain HTTP — PII crosses the network unencrypted.")
    sys.stdout.flush()      # the banner must reach redirected logs NOW, not
    # when an 8KB block buffer eventually fills (a container ran "silent"
    # for minutes and the user debugged a healthy server)
    _serve(args.host, args.port, ssl_ctx)


def _serve(host, port, ssl_ctx):
    """Run under cheroot (a production WSGI server that supports TLS and
    Windows) when available; otherwise fall back to Flask's built-in dev
    server, which works fine for a small LAN but prints a warning."""
    try:
        from cheroot.wsgi import Server
    except ImportError:
        print("    (running on Flask's built-in server — `pip install cheroot`")
        print("     to switch to a production server and silence its warning)")
        app.run(host=host, port=port, threaded=True, ssl_context=ssl_ctx)
        return
    # A browser opens several connections per host (Safari preconnects up to
    # ~6), and each idle keep-alive connection holds a cheroot worker until
    # it times out — so the pool needs headroom well past one browser's
    # connection count or real requests queue behind idle sockets. 16 was
    # tight enough that a phone plus a laptop could stall; 64 is ample and
    # cheroot worker threads are cheap.
    server = Server((host, port), app, server_name="openscrub",
                    numthreads=64)
    # Browsers probing/rejecting the self-signed certificate abort mid-
    # handshake on every new socket, and cheroot logs each one. Harmless
    # noise (install a trusted cert to stop the aborts themselves) —
    # filter just that class of message, pass everything else through.
    _orig_log = server.error_log
    _TLS_NOISE = ("during handshake", "certificate unknown", "unknown ca",
                  "peer dropped the tls connection", "http request")

    def _quiet_log(msg="", level=20, traceback=False):
        if any(s in str(msg).lower() for s in _TLS_NOISE):
            return
        _orig_log(msg, level, traceback)

    server.error_log = _quiet_log
    if ssl_ctx:
        from cheroot.ssl.builtin import BuiltinSSLAdapter

        class RedirectingTLS(BuiltinSSLAdapter):
            """When a browser sends plain HTTP to the TLS port (user typed
            http:// or left the scheme off), answer with a redirect to the
            https URL instead of cheroot's default 400 error page."""
            redirect_url = "https://%s:%d/" % (lan_ip(), port)

            def wrap(self, sock):
                # peek the first byte before TLS: a real TLS ClientHello
                # starts with 0x16; anything else is plaintext HTTP (user
                # typed http://) and gets a redirect to the https URL.
                #
                # The peek MUST NOT block. cheroot runs this on a worker
                # thread, and a blocking recv() parks that thread until the
                # client sends data. Normal Safari (unlike Private mode)
                # opens speculative *preconnect* sockets that finish the TCP
                # handshake but delay their first byte — each blocking peek
                # would wedge a worker, and enough of them starve the whole
                # 16-thread pool so real requests never get served (the
                # "loads over and over, never finishes" bug; Private mode has
                # no preconnect so it's unaffected). A plaintext HTTP client
                # sends "GET ..." immediately, so its bytes are already in
                # the buffer here; a near-instant select catches that. If no
                # byte is ready yet we assume TLS and hand straight to
                # cheroot's normal handshake path — exactly how preconnects
                # behaved before this adapter existed, so there's no
                # starvation and no regression.
                from cheroot import errors as _cherr
                import select as _select
                try:
                    ready = _select.select([sock], [], [], 0.1)[0]
                    first = sock.recv(1, socket.MSG_PEEK) if ready else b""
                except OSError:
                    first = b""
                if first and first[0] != 0x16:
                    try:
                        sock.sendall((
                            "HTTP/1.1 301 Moved Permanently\r\n"
                            "Location: %s\r\n"
                            "Content-Length: 0\r\n"
                            "Connection: close\r\n\r\n"
                            % self.redirect_url).encode())
                    except OSError:
                        pass
                    raise _cherr.FatalSSLAlert(
                        "plain HTTP redirected to %s" % self.redirect_url)
                # Bound the TLS handshake itself. A bare TCP preconnect that
                # completes the socket connect but never sends a ClientHello
                # would otherwise park this worker thread in the handshake
                # read forever — just six of them (a normal Safari per-host
                # count) starve the 16-thread pool and real requests never
                # get served. A short timeout frees the thread; a genuine
                # handshake finishes in well under a second even on mobile.
                # cheroot resets the socket timeout for request handling.
                try:
                    sock.settimeout(4.0)
                except OSError:
                    pass
                return super().wrap(sock)

        server.ssl_adapter = RedirectingTLS(ssl_ctx[0], ssl_ctx[1])
    try:
        server.start()
    except KeyboardInterrupt:
        server.stop()


if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        raise
    except BaseException:
        import traceback
        traceback.print_exc()
        if os.name == "nt":
            input("\nStartup failed — see the error above. Press Enter to close.")
        raise
