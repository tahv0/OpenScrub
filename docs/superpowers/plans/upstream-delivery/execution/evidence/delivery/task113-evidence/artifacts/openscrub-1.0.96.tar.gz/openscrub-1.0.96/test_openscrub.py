#!/usr/bin/env python3
"""Regression tests for openscrub. Run: pytest test_openscrub.py -v
For this tool a regression is not a bug, it's a PHI leak — these tests are
the gate for any change."""

import json
import os
import re
import subprocess
import threading
import time

# the plate category self-heals by DOWNLOADING its model (issue #18) —
# never from inside the test suite: e2e runs with default categories
# would otherwise hit the network and change later tests' model state
# (a real 9 MB download landed in models/ mid-suite before this guard)
os.environ.setdefault("OPENSCRUB_NO_AUTOFETCH", "1")

import cv2
import numpy as np
import pytest

import openscrub

FONT = cv2.FONT_HERSHEY_SIMPLEX


def make_video(path, lines, seconds=1.5, fps=30):
    img = np.full((720, 1280, 3), 245, np.uint8)
    for y, txt in lines:
        cv2.putText(img, txt, (60, y), FONT, 0.9, (20, 20, 20), 2)
    out = cv2.VideoWriter(path, cv2.VideoWriter_fourcc(*"mp4v"), fps, (1280, 720))
    for _ in range(int(seconds * fps)):
        out.write(img)
    out.release()
    return path


def run(video, *extra):
    parser = openscrub.build_parser()
    args = parser.parse_args([video, "--engine", "tesseract",
                              "-o", video.replace(".mp4", "_red.mp4"),
                              "--report", video.replace(".mp4", "_aud.json"),
                              *extra])
    args = openscrub._prep_args(args, parser)

    class Quiet(openscrub.Callbacks):
        def log(self, m):
            pass
    res = openscrub.run_pipeline(args, Quiet())
    dets = json.load(open(video.replace(".mp4", "_aud.json")))["detections"]
    return res, dets


def sharp(path, t, box):
    cap = cv2.VideoCapture(path)
    cap.set(cv2.CAP_PROP_POS_MSEC, t * 1000)
    _, f = cap.read()
    cap.release()
    x1, y1, x2, y2 = [int(v) for v in box]
    roi = cv2.cvtColor(f[y1:y2, x1:x2], cv2.COLOR_BGR2GRAY)
    return cv2.Laplacian(roi, cv2.CV_64F).var()


# ---------------------------------------------------------------- unit tests

def test_mrn_regex_precision():
    """RE_MRN_DEFAULT is the DOCUMENTED EXAMPLE pattern for the mrn ID
    category (the category itself is bring-your-own-regex: --mrn-regex
    defaults to empty and the category stays inactive without one). The
    example shape: standalone 6-10 digit runs with an optional short letter
    prefix; detect_phi separately requires a nearby id-ish label OR 7+
    digits before flagging."""
    rx = openscrub.RE_MRN_DEFAULT
    import re
    r = re.compile(rx)
    assert r.search("1234567")               # plain 7-digit run
    assert r.search("MM0123456789")          # letter prefix + digits
    assert r.search("4829173")               # any 7 digits — no magic prefix
    assert r.search("123456")                # 6 digits (label-gated upstream)
    assert not r.search("12345")             # too short
    assert not r.search("12345678901")       # too long (11+): not MRN-shaped
    assert not r.search("ABCD123456")        # prefix too long
    assert not r.search("4111111111111111")  # card-length: left to card/Luhn

    # empty --mrn-regex = category INACTIVE: detect_phi must not flag digit
    # runs when no pattern is configured (an empty regex would match every
    # word — the guard has to be None, not re.compile(""))
    words = [("1234567", (10, 10, 90, 30), 0.95)]
    lines = [{"text": "1234567", "box": (10, 10, 90, 30), "words": words}]
    dets = openscrub.detect_phi(words, lines, 0.0, (0, 0), None, None)
    assert not any(d.category == "mrn" for d in dets), \
        "no regex configured -> mrn category must detect nothing"


def test_memory_two_sighting_gate():
    m = openscrub.PhiMemory()
    m.add("Henderson", "name", primary=True)
    assert m.recall("Henderson") is None            # 1 sighting: gated
    m.add("Henderson", "name", primary=True)
    assert m.recall("Henderson") == "name"          # 2 sightings: recalls
    m.add("5015550142", "phone", primary=True)
    assert m.recall("5015550142") == "phone"        # regex cats: immediate
    m.add("face", "face")                           # never memorized
    assert "face" not in m.items


def test_memory_fuzzy_recall_never_scans_the_full_history():
    m = openscrub.PhiMemory()
    for i in range(2000):
        m.add("unrelated-token-%04d" % i, "name", primary=True)
        m.add("unrelated-token-%04d" % i, "name", primary=True)
    m.add("Henderson", "name", primary=True)
    m.add("Henderson", "name", primary=True)
    m.add("5015550142", "phone", primary=True)

    class NoFullIteration(dict):
        def items(self):
            raise AssertionError("recall walked the complete remembered-string history")

    m.items = NoFullIteration(m.items)
    assert m.recall("Henders0n") == "name"
    assert m.recall("5015550143") == "phone"


def test_indexed_memory_preserves_first_remembered_fuzzy_match():
    m = openscrub.PhiMemory(threshold=50)
    m.add("alpha", "first", primary=True)
    m.add("alpha", "first", primary=True)
    m.add("alphaaa", "second", primary=True)
    m.add("alphaaa", "second", primary=True)
    assert m.recall("alphaa") == "first"


def test_batched_memory_recall_matches_reference_scan():
    """The indexed + batched recall must return EXACTLY what the original
    linear scan returned (same scores, thresholds, first-remembered tie
    break, name gating) — a privacy tool can't trade recall for speed.
    Differential check against a verbatim copy of the old algorithm."""
    import random
    import string
    from rapidfuzz import fuzz

    def reference(m, word):
        n = m.norm(word)
        if len(n) < 3 or n in openscrub.STOPWORDS:
            return None
        if n in m.items:
            return m._gated(n, m.items[n])
        if n.isdigit():
            for k, cat in m.items.items():
                if (k.isdigit() and len(k) == len(n)
                        and sum(a != b for a, b in zip(k, n)) <= 1):
                    return m._gated(k, cat)
            return None
        if len(n) >= 4:
            for k, cat in m.items.items():
                if (not k.isdigit() and abs(len(k) - len(n)) <= 2
                        and fuzz.ratio(k, n) >= m.threshold):
                    return m._gated(k, cat)
        return None

    rng = random.Random(7)

    def mutate(s):
        s = list(s)
        for _ in range(rng.randint(0, 3)):
            i = rng.randrange(len(s))
            op = rng.random()
            if op < 0.4:
                s[i] = rng.choice("abcdeh0123")
            elif op < 0.7:
                s.insert(i, rng.choice("abcdeh"))
            elif len(s) > 3:
                s.pop(i)
        return "".join(s)

    for thr in (50, 82, 90):
        m = openscrub.PhiMemory(threshold=thr)
        pool = []
        for _ in range(300):        # tiny alphabet => many ties
            if pool and rng.random() < 0.3:
                w = mutate(rng.choice(pool))
            elif rng.random() < 0.3:
                w = "".join(rng.choice(string.digits)
                            for _ in range(rng.randint(3, 11)))
            else:
                w = "".join(rng.choice("abcdeh")
                            for _ in range(rng.randint(3, 12)))
            m.add(w, rng.choice(["name", "phone", "ssn", "plate"]),
                  primary=rng.random() < 0.7)
            pool.append(w)
        for _ in range(400):
            q = mutate(rng.choice(pool))
            assert m.recall(q) == reference(m, q), (thr, q)


def test_probe_vfr(tmp_path):
    cfr = make_video(str(tmp_path / "cfr.mp4"), [(150, "hello world")])
    is_vfr, avg = openscrub.probe_vfr(cfr)
    assert not is_vfr and abs(avg - 30) < 1
    vfr = str(tmp_path / "vfr.mp4")
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", cfr,
                    "-vf", "select='not(mod(n\\,3))'", "-fps_mode", "vfr",
                    vfr], check=True)
    is_vfr, _ = openscrub.probe_vfr(vfr)
    assert is_vfr


def test_config_profile(tmp_path):
    cfg = tmp_path / "p.yaml"
    cfg.write_text("pad: 3\nignore_regions:\n  - [0, 600, 1280, 720]\n")
    parser = openscrub.build_parser()
    args = parser.parse_args(["x.mp4", "--config", str(cfg)])
    args = openscrub.apply_config(args, parser)
    assert args.pad == 3
    assert args.ignore_regions == [(0, 600, 1280, 720)]
    # CLI wins over config
    args2 = parser.parse_args(["x.mp4", "--config", str(cfg), "--pad", "11"])
    args2 = openscrub.apply_config(args2, parser)
    assert args2.pad == 11


# ------------------------------------------------------------ pipeline tests

@pytest.fixture(scope="module")
def chart(tmp_path_factory):
    d = tmp_path_factory.mktemp("vids")
    v = make_video(str(d / "chart.mp4"),
                   [(150, "Patient: Robert Henderson"),
                    (230, "MRN: 1234567   DOB: 03/15/1978"),
                    (310, "Assessment and Plan documented")])
    # mrn is CLI-only now (retired from the default list — the web UI
    # replaces it with custom regex categories), so the fixture opts in
    res, dets = run(v, "--mrn-regex", openscrub.RE_MRN_DEFAULT,
                    "--categories",
                    "name,dob,phone,ssn,mrn,email,address,card,apikey,"
                    "ipaddr,plate,face")
    return v, res, dets


def test_categories_detected(chart):
    _, _, dets = chart
    cats = {d["category"] for d in dets}
    assert {"name", "mrn", "dob"} <= cats


def test_openscrubred_benign_readable(chart):
    v, res, dets = chart
    red = v.replace(".mp4", "_red.mp4")
    name = [d for d in dets if d["text"] == "Henderson"][0]["cbox"]
    assert sharp(red, 0.7, name) < sharp(v, 0.7, name) * 0.15
    benign = [60, 285, 700, 320]   # "Assessment and Plan" line
    assert sharp(red, 0.7, benign) > sharp(v, 0.7, benign) * 0.7


def test_provenance(chart):
    v, _, _ = chart
    prov = json.load(open(v.replace(".mp4", "_aud.json")))["provenance"]
    assert prov["version"] == openscrub.VERSION
    assert len(prov["input_sha256"]) == 64
    assert len(prov["output_sha256"]) == 64


def test_from_report_respects_edits(chart, tmp_path):
    v, _, _ = chart
    doc = json.load(open(v.replace(".mp4", "_aud.json")))
    for d in doc["detections"]:
        if d["text"] == "Henderson":
            d["enabled"] = False
    doc["detections"].append({
        "t_start": 0, "t_end": 1.5, "cbox": [60, 285, 700, 320],
        "category": "manual", "text": "user", "confidence": 1.0,
        "aoff": [0, 0], "last_seen": 0, "enabled": True})
    edited = str(tmp_path / "edited.json")
    json.dump(doc, open(edited, "w"))
    parser = openscrub.build_parser()
    args = parser.parse_args([v, "--from-report", edited,
                              "-o", str(tmp_path / "rr.mp4")])
    args = openscrub._prep_args(args, parser)

    class Quiet(openscrub.Callbacks):
        def log(self, m):
            pass
    openscrub.run_pipeline(args, Quiet())
    rr = str(tmp_path / "rr.mp4")
    hend = [d for d in doc["detections"] if d.get("text") == "Henderson"][0]["cbox"]
    assert sharp(rr, 0.7, hend) > 500                       # disable honored
    assert sharp(rr, 0.7, [60, 285, 700, 320]) < 100        # manual honored


def test_ignore_region(tmp_path):
    v = make_video(str(tmp_path / "ign.mp4"),
                   [(150, "Patient: Maria Gonzalez"),
                    (700, "03/15/1978")])
    res, dets = run(v, "--ignore-region", "0,650,1280,720")
    assert not any(d["cbox"][1] > 600 for d in dets)         # corner suppressed
    assert any(d["category"] == "name" for d in dets)        # name still caught


def test_update_version_compare():
    import openscrub_update as u
    assert u.is_newer("1.0.10", "1.0.9")
    assert u.is_newer("1.1.0", "1.0.99")
    assert not u.is_newer("1.0.4", "1.0.4")
    assert not u.is_newer("0.9.9", "1.0.0")


def test_update_registry_pin_merge():
    """Locally pinned TOFU hashes must survive an update — but only when
    the download URL is unchanged; a moved URL must NOT inherit trust."""
    import openscrub_update as u
    old = [
        {"id": "a", "download_url": "https://x/a.onnx", "sha256": "aaa"},
        {"id": "b", "download_url": "https://x/b.onnx", "sha256": "bbb"},
        {"id": "c", "download_url": "https://x/c.onnx", "sha256": ""},
    ]
    new = [
        {"id": "a", "download_url": "https://x/a.onnx", "sha256": ""},
        {"id": "b", "download_url": "https://MOVED/b.onnx", "sha256": ""},
        {"id": "c", "download_url": "https://x/c.onnx", "sha256": ""},
        {"id": "d", "download_url": "https://x/d.onnx", "sha256": "ddd"},
    ]
    carried = u.merge_registry_pins(old, new)
    assert carried == 1
    assert new[0]["sha256"] == "aaa"      # same URL: pin carried
    assert new[1]["sha256"] == ""          # URL moved: trust reset
    assert new[2]["sha256"] == ""          # never pinned: stays empty
    assert new[3]["sha256"] == "ddd"       # shipped hash untouched


def test_registry_user_copy_and_pin_survival(tmp_path, monkeypatch):
    """Read-only installs (pip/frozen) must keep TOFU pins in a per-user
    registry copy: seeded once, new release models merged in, existing
    pinned hashes never overwritten."""
    monkeypatch.setattr(openscrub, "install_is_readonly", lambda: True)
    monkeypatch.setattr(openscrub, "user_data_dir", lambda: str(tmp_path))

    # first call seeds the user copy from the packaged registry
    p = openscrub.plate_registry_path()
    assert p == str(tmp_path / "plate_models.json")
    with open(p, encoding="utf-8") as f:
        reg = json.load(f)
    assert reg["models"], "seeded registry should carry the packaged models"

    # pin a hash locally, then simulate a release that adds a new model
    reg["models"][0]["sha256"] = "f" * 64
    with open(p, "w", encoding="utf-8") as f:
        json.dump(reg, f)
    packaged = os.path.join(os.path.dirname(os.path.abspath(
        openscrub.__file__)), "plate_models.json")
    with open(packaged, encoding="utf-8") as f:
        shipped = json.load(f)
    shipped["models"].append({"id": "brand-new", "sha256": "",
                              "download_url": "https://x/new.onnx"})
    fake_pkg = tmp_path / "pkg"; fake_pkg.mkdir()
    (fake_pkg / "plate_models.json").write_text(json.dumps(shipped),
                                                encoding="utf-8")
    real_dirname = os.path.dirname

    def fake_dirname(path):
        if path == os.path.abspath(openscrub.__file__):
            return str(fake_pkg)
        return real_dirname(path)
    monkeypatch.setattr(openscrub.os.path, "dirname", fake_dirname)

    p2 = openscrub.plate_registry_path()
    with open(p2, encoding="utf-8") as f:
        merged = json.load(f)
    ids = [m["id"] for m in merged["models"]]
    assert "brand-new" in ids, "new release model should merge in"
    assert merged["models"][0]["sha256"] == "f" * 64, "local pin must survive"


def test_vault_roundtrip_and_wrong_password(tmp_path):
    import openscrub_vault as v
    key = v.create_keystore(str(tmp_path), "correct horse battery")
    assert v.open_keystore(str(tmp_path), "correct horse battery") == key
    with pytest.raises(ValueError):
        v.open_keystore(str(tmp_path), "wrong password")

    big = tmp_path / "job" / "video.mp4"
    big.parent.mkdir()
    data = os.urandom(5 * 1024 * 1024)      # spans two 4MiB chunks
    big.write_bytes(data)
    (tmp_path / "job" / "report.json").write_text('{"phi": "synthetic"}')

    n = v.encrypt_tree(key, str(tmp_path / "job"))
    assert n == 2
    names = sorted(p.name for p in (tmp_path / "job").iterdir())
    assert names == ["report.json.osvault", "video.mp4.osvault"]
    enc, plain = v.tree_locked_state(str(tmp_path / "job"))
    assert (enc, plain) == (2, 0)

    n = v.decrypt_tree(key, str(tmp_path / "job"))
    assert n == 2
    assert big.read_bytes() == data
    assert (tmp_path / "job" / "report.json").read_text() == '{"phi": "synthetic"}'


def test_vault_tamper_fails_closed(tmp_path):
    import openscrub_vault as v
    key = v.create_keystore(str(tmp_path), "a strong password")
    f = tmp_path / "report.json"
    f.write_text("sensitive")
    enc = v.encrypt_file(key, str(f))
    raw = bytearray(open(enc, "rb").read())
    raw[-1] ^= 0xFF                          # flip one ciphertext bit
    open(enc, "wb").write(bytes(raw))
    with pytest.raises(Exception):
        v.decrypt_file(key, enc)
    assert not f.exists(), "tampered file must NOT decrypt to plaintext"


def test_custom_regex_category(tmp_path):
    """A user-defined regex category detects, reports, and survives the
    full pipeline like a built-in."""
    v = make_video(str(tmp_path / "c.mp4"), [(200, "Claim CLM-123456 filed")])
    _, dets = run(v, "--categories", "claim",
                  "--custom-regex", r"claim=CLM-\d+")
    hits = [d for d in dets if d["category"] == "claim"]
    assert hits, "custom category should appear in the report"


def test_custom_regex_spans_words_on_a_line(tmp_path):
    """A regex containing a space used to NEVER match: OCR hands the
    engine one word at a time. Line-level matching now finds multi-word
    patterns and blurs the union of the words, while single-word matches
    are still reported exactly once."""
    words = [("Client:", (10, 10, 70, 30), 0.9),
             ("Acme", (80, 10, 130, 30), 0.9),
             ("Corp", (138, 10, 185, 30), 0.8),
             ("ref", (300, 10, 330, 30), 0.9),
             ("CLM-123456", (340, 10, 450, 30), 0.9)]
    lines = openscrub.group_lines(words)
    res = [("client", re.compile(r"Acme\s+Corp")),
           ("claim", re.compile(r"CLM-\d+"))]
    dets = openscrub.detect_phi(words, lines, 0.0, (0, 0), None, None, res)
    cl = [d for d in dets if d.category == "client"]
    assert [(d.text, tuple(d.cbox)) for d in cl] == \
        [("Acme Corp", (80, 10, 185, 30))]
    assert cl[0].confidence == 0.8
    claims = [d for d in dets if d.category == "claim"]
    assert len(claims) == 1 and tuple(claims[0].cbox) == (340, 10, 450, 30)
    # and through the whole pipeline on a real frame
    v = make_video(str(tmp_path / "m.mp4"), [(200, "Client Acme Corp today")])
    _, rep = run(v, "--categories", "client",
                 "--custom-regex", r"client=(?i)acme\s+corp")
    assert any(d["category"] == "client" and "acme" in d["text"].lower()
               for d in rep), "multi-word regex should be detected"


def test_custom_category_rejects_patterns_matching_empty_text(tmp_path,
                                                              monkeypatch):
    """`\\d*`, `x|` or `\\b` 'match' every OCR word with zero characters,
    so the category would blur the whole screen — refuse it at add time,
    with the reason shown to the user."""
    import openscrub_web as w
    monkeypatch.setattr(w, "CUSTOM_CATS_PATH", str(tmp_path / "cc.json"))
    c = w.app.test_client()
    for bad in (r"\d*", "x|", r"\b"):
        r = c.post("/api/custom_cats", json={"name": "t1", "regex": bad})
        assert r.status_code == 400 and b"empty text" in r.data, bad
    r = c.post("/api/custom_cats", json={"name": "t1", "regex": r"CLM-\d+"})
    assert r.status_code == 200
    # decided by parsing, NEVER by running the request's regex on the
    # server (code-scanning #22, py/regex-injection / ReDoS)
    import inspect
    src = inspect.getsource(w.custom_cats)
    assert not re.search(r"\.(finditer|search|match|fullmatch|findall|sub)\(",
                         src)
    assert w._regex_min_width(r"(?=CLM)") == 0
    assert w._regex_min_width(r"(?i)acme\s+corp") == 9
    assert w._regex_min_width("(unclosed") == 0     # unparseable = unsafe
    assert 'Could not add the category"+(why?": "+why' in w.PAGE


def test_plate_threshold_exposed_in_editor_and_clamped(tmp_path):
    """The editor's Advanced panel sets the plate confidence cutoff (users
    saw hands/labels flagged as plates and had no web control). The server
    clamps it to 0.05-0.95 — a cutoff of 1.0+ detects nothing at all, a
    silent fail-open — and empty/garbage falls back to the 0.35 default."""
    import zones_ui
    import openscrub_web as w
    page = zones_ui.ZONES_PAGE
    assert 'id="pthr"' in page and 'value="0.35"' in page
    assert 'plate_threshold:$("pthr").value.trim()===""?null' in page
    job = {"video": str(tmp_path / "x.mp4"), "dir": str(tmp_path), "log": [],
           "options": {}}
    for given, want in ((0.5, 0.5), (5, 0.95), (-1, 0.05), (None, 0.35),
                        ("abc", 0.35), (float("nan"), 0.35), ("0.6", 0.6)):
        job["options"] = {"plate_threshold": given}
        assert w.build_args(job).plate_threshold == want, given


def test_every_advanced_setting_has_a_help_tip():
    """Every control in the editor's Advanced panel carries a '?' tip that
    explains it; tips stay on screen and a tap on a '?' inside a checkbox
    label opens the tip instead of ticking the box."""
    import zones_ui
    import openscrub_web as w
    page = zones_ui.ZONES_PAGE
    adv = page[page.index("<summary>Advanced settings"):
               page.index("</div></details>")]
    blocks = re.split(r"\n  <div", adv)[1:]
    controls = re.findall(r'id="([a-z]+)"', adv)
    assert len(controls) >= 26
    for cid in controls:
        holder = next(b for b in blocks if 'id="%s"' % cid in b)
        if 'class="full" style="display:flex' in holder:   # checkbox row
            lab = re.search(r'<label[^>]*><input[^>]*id="%s"[^>]*>(.*?)</label>'
                            % cid, holder, re.S).group(1)
        else:
            lab = re.search(r"<label>(.*?)</label>", holder, re.S).group(1)
        m = re.search(r'class="qm" data-tip="([^"]+)"', lab)
        assert m and len(m.group(1)) > 40, "no help tip for #" + cid
    assert "function qmPlace" in w.PAGE and "e.preventDefault();qmPlace(q)" \
        in w.PAGE


def test_ocr_dash_and_slash_lookalikes_are_still_detected():
    """OCR returns en/em dashes, Unicode hyphens/minus and look-alike
    slashes; every structured pattern expects '-' and '/'. Before v1.0.94
    '123–45–6789' slipped past SSN, phone, DOB, card AND custom regex
    (issue #22, found by Tuomas Aho). read_adaptive — the one point where
    every OCR engine's text enters detection — now normalizes them."""
    dashes = ["‐", "‑", "‒", "–", "—", "―",
              "−", "﹣", "－", "-—"]
    samples = {"ssn": "123{d}45{d}6789", "phone": "555{d}201{d}0142",
               "dob": "03{d}15{d}1978", "card": "4111{d}1111{d}1111{d}1111",
               "cust": "CLM{d}123456"}
    res = [("cust", re.compile(r"CLM-\d+"))]

    class FakeOCR:
        def __init__(self, text):
            self.text = text

        def read(self, frame):
            return [(self.text, (10, 10, 200, 30), 0.95)]
    frame = np.zeros((40, 400, 3), np.uint8)
    for d in dashes:
        for cat, tpl in samples.items():
            words = openscrub.read_adaptive(FakeOCR(tpl.format(d=d)), frame,
                                            "off")
            dets = openscrub.detect_phi(words, openscrub.group_lines(words),
                                        0, (0, 0), None, None, res)
            assert any(x.category == cat for x in dets), (repr(d), cat)
    for sl in ("⁄", "∕", "／"):
        words = openscrub.read_adaptive(FakeOCR("03%s15%s1978" % (sl, sl)),
                                        frame, "off")
        dets = openscrub.detect_phi(words, openscrub.group_lines(words), 0,
                                    (0, 0), None, None)
        assert any(x.category == "dob" for x in dets), repr(sl)
    # ordinary text is untouched; no digits/letters are ever rewritten
    assert openscrub.normalize_ocr_text("Bulletin 2010, A-1 b/c") == \
        "Bulletin 2010, A-1 b/c"
    # spoken numbers in a transcript get the same treatment
    words = [(0.0, 0.5, " call"), (0.5, 1.5, " 555–201–0142")]
    sugg = openscrub._speech_suggestions(words, {"phone"})
    assert [s["category"] for s in sugg] == ["phone"]


def test_text_scan_cadence_notices_small_new_text():
    """The self-tuning OCR cadence doubled its interval whenever the WHOLE
    frame barely changed — and a small SSN popping up moves the whole-frame
    mean by <1 gray level, so text shown for under a second was never
    scanned (issue #22, found by Tuomas Aho). Local 16px cells now catch
    it: scan sooner, not later."""
    base = np.full((360, 640), 245, np.uint8)
    step = 15
    assert openscrub.text_scan_stride(base, base.copy(), step) == 30
    txt = base.copy()
    cv2.putText(txt, "SSN 123-45-6789", (350, 300), FONT, 0.45, 20, 1)
    assert float(cv2.absdiff(txt, base).mean()) < 1.0   # globally "static"
    assert openscrub.text_scan_stride(txt, base, step) == 7
    speck = base.copy()
    speck[98:106, 98:106] = 0      # a speck inside ONE 16px cell (96-112)
    assert openscrub.text_scan_stride(speck, base, step) == 30
    busy = np.zeros_like(base)
    assert openscrub.text_scan_stride(busy, base, step) == 7


def test_brief_text_on_static_screen_is_scanned(tmp_path):
    """End to end: an SSN shown for 0.8s on an otherwise static screen was
    missed entirely before v1.0.94 (the doubled interval jumped over it)."""
    path = str(tmp_path / "flash.mp4")
    fps = 30
    base = np.full((720, 1280, 3), 245, np.uint8)
    cv2.putText(base, "Quarterly status report", (60, 120), FONT, 0.9,
                (20, 20, 20), 2)
    txt = base.copy()
    cv2.putText(txt, "SSN 123-45-6789", (700, 600), FONT, 0.9, (20, 20, 20), 2)
    out = cv2.VideoWriter(path, cv2.VideoWriter_fourcc(*"mp4v"), fps,
                          (1280, 720))
    for i in range(3 * fps):
        out.write(txt if 1.05 <= i / fps < 1.85 else base)
    out.release()
    _, dets = run(path, "--categories", "ssn")
    assert any(d["category"] == "ssn" for d in dets), \
        "an SSN shown for 0.8s must be scanned and blurred"


def test_phrase_matcher_is_forgiving_of_ocr():
    """'Specific text' must find what the user typed the way OCR actually
    reads it: any case/punctuation, phrases across words, words OCR split
    or welded, 0/o and 1/l confusions, possessives, and 4+ character text
    inside longer words — while short text stays whole-word only."""
    P = openscrub.load_phrases(["Acme Corp", "Al", "Project Bluebird",
                                "555-0142", "  acme   CORP ", "!!!"])
    assert [k for _, k in P] == ["acmecorp", "al", "projectblueblrd",
                                 "555ol42"], "dedupe + drop empty terms"
    m = lambda toks: openscrub.phrase_spans(toks, P)
    assert m(["Contact", "ACME,", "Corp.", "today"]) == [(1, 2)]
    assert m(["Ac", "me", "Corp"]) == [(0, 2)]              # OCR split
    assert m(["AcmeCorp's", "office"]) == [(0, 0)]          # OCR welded
    assert m(["Pr0ject", "B1uebird"]) == [(0, 1)]          # confusables
    assert m(["call", "555", "0142"]) == [(1, 2)]
    assert m(["also", "Al’s", "AL."]) == [(1, 1), (2, 2)]  # whole word
    assert m(["Bluebirds", "here"]) == []     # partial needs the WHOLE term
    assert m(["nothing", "to", "see"]) == []
    assert openscrub.phrase_spans(["a"], []) == []


def test_phrase_category_end_to_end(tmp_path):
    """Typed text is found on screen, blurred as one box spanning the
    phrase's words, and reported under the 'phrase' category."""
    v = make_video(str(tmp_path / "p.mp4"),
                   [(200, "Contact Acme Corp today"),
                    (300, "Nothing else to see")])
    _, dets = run(v, "--categories", "phrase", "--phrase", "acme corp")
    hits = [d for d in dets if d["category"] == "phrase"]
    assert hits, "specific text should be detected"
    assert any("acme" in d["text"].lower() for d in hits)
    assert all("nothing" not in d["text"].lower() for d in hits)
    # nothing entered: the category can't find anything — refuse, loudly
    with pytest.raises(RuntimeError, match="nothing to detect"):
        run(v, "--categories", "phrase")


def test_phrase_spoken_suggestions():
    """With spoken-PII on, the same typed text is suggested as a mute span
    when it's heard in the audio (whisper splits/punctuates like OCR)."""
    words = [(0.0, 0.4, " We"), (0.4, 0.8, " met"), (0.8, 1.2, " Acme"),
             (1.2, 1.6, " Corp."), (1.6, 2.0, " today")]
    P = openscrub.load_phrases(["acme corp"])
    sugg = openscrub._speech_suggestions(words, {"phrase"}, phrases=P)
    assert [(s["category"], s["t0"], s["t1"]) for s in sugg] == \
        [("phrase", 0.3, 2.1)]
    assert openscrub._speech_suggestions(words, {"name"}, phrases=P) == []


def test_phrase_category_wired_through_web(tmp_path):
    """Editor: the category, its text box and the empty-box guard exist;
    server: the text reaches the engine as a FILE (never argv) and the id
    can't be claimed by a custom category."""
    import zones_ui
    import openscrub_web as w
    page = zones_ui.ZONES_PAGE
    assert 'phrase:"#6366f1"' in page and 'phrase:"specific text"' in page
    assert 'id="phrasebox"' in page and 'id="phrases"' in page
    assert 'phrases:cats.includes("phrase")' in page
    assert 'Specific text is checked but no text is entered' in page
    assert 'phrase:"specific text"' in w.PAGE          # review heading
    assert "phrase" in w.BUILTIN_CATS
    job = {"video": str(tmp_path / "x.mp4"), "dir": str(tmp_path), "log": [],
           "options": {"categories": "phrase",
                       "phrases": "Acme Corp\nProject Bluebird\n"}}
    a = w.build_args(job)
    assert a.phrases == str(tmp_path / "phrases.txt")
    assert [t for t, _ in openscrub.load_phrases(path=a.phrases)] == \
        ["Acme Corp", "Project Bluebird"]
    job["options"]["phrases"] = "   "
    assert w.build_args(job).phrases is None


def test_deep_backtrack_finds_true_onset(tmp_path):
    """A region whose first frame lies beyond the RAM backtrack buffer must
    still get its true onset via the post-scan deep file search — and must
    not be extended earlier than it actually appeared."""
    path = str(tmp_path / "late.mp4")
    fps, seconds, appear_at = 30, 6, 3.0
    blank = np.full((720, 1280, 3), 245, np.uint8)
    with_text = blank.copy()
    cv2.putText(with_text, "SSN 123-45-6789", (60, 300), FONT, 1.1,
                (20, 20, 20), 2)
    out = cv2.VideoWriter(path, cv2.VideoWriter_fourcc(*"mp4v"), fps,
                          (1280, 720))
    for i in range(seconds * fps):
        out.write(with_text if i / fps >= appear_at else blank)
    out.release()

    _, dets = run(path, "--categories", "ssn",
                  "--sample-interval", "2.0",
                  "--backtrack-window", "0.5")
    ssn = [d for d in dets if d["category"] == "ssn"]
    assert ssn, "SSN should be detected"
    start = min(d["t_start"] for d in ssn)
    assert start <= appear_at + 0.30, \
        f"deep backtrack should reach the true onset, got {start}"
    assert start >= appear_at - 1.0, \
        f"must not extend far before the text existed, got {start}"


def test_gap_verification_refuses_real_absence(tmp_path):
    """A gap where the content GENUINELY left the screen must not be
    bridged, no matter the verification pass — over-blur is fine but a
    6s bogus bridge across truly-absent content means merge is wrong."""
    path = str(tmp_path / "gap.mp4")
    fps = 30
    blank = np.full((720, 1280, 3), 245, np.uint8)
    wt = blank.copy()
    cv2.putText(wt, "SSN 123-45-6789", (60, 300), FONT, 1.1, (20, 20, 20), 2)
    out = cv2.VideoWriter(path, cv2.VideoWriter_fourcc(*"mp4v"), fps,
                          (1280, 720))
    for i in range(12 * fps):
        t = i / fps
        out.write(wt if (t < 3 or t >= 9) else blank)
    out.release()
    _, dets = run(path, "--categories", "ssn")
    ssn = sorted((d for d in dets if d["category"] == "ssn"),
                 key=lambda d: d["t_start"])
    assert ssn, "SSN should be detected"
    assert not any(d["t_start"] < 4 and d["t_end"] > 8 for d in ssn), \
        "the true 6s absence must not be blurred straight through"


def test_ignore_zone_blocks_detection(tmp_path):
    """Normalized ignore regions (zone-editor rects) suppress detection
    inside them — and only inside them."""
    v1 = make_video(str(tmp_path / "a.mp4"), [(300, "SSN 123-45-6789")])
    _, dets = run(v1, "--categories", "ssn")
    assert [d for d in dets if d["category"] == "ssn"], "control run detects"
    v2 = make_video(str(tmp_path / "b.mp4"), [(300, "SSN 123-45-6789")])
    _, dets = run(v2, "--categories", "ssn",
                  "--ignore-region", "0,0,1,0.6")
    assert not [d for d in dets if d["category"] == "ssn"], \
        "text centered inside a normalized ignore region must not detect"


def test_dense_hold_not_extended_by_merge():
    """Dense per-frame samples must keep their sub-frame hold through
    merge_detections: stamping them with the multi-second OCR hold left a
    trail of stale blur boxes along a moving face's path (v1.0.21 bug)."""
    d = openscrub.Detection(5.0, 5.01, (100, 100, 160, 160), "face", "face",
                            0.9, (0, 0), dense=True)
    merged = openscrub.merge_detections([d], hold=2.3)
    assert merged[0].t_end <= 5.02, \
        "dense sample t_end must not be extended by the OCR hold"


def test_dense_track_flicker_interpolation():
    """A short detector flicker inside a dense track is filled by
    interpolating the box between the surrounding samples: the blur must
    MOVE with the face across the gap, not vanish or hang at the pre-gap
    position (the v1.0.21 sideways-trail bug, inverted)."""
    fps = 30.0
    speed = 150.0                      # face drifting right, px/s
    dets = []
    for i in range(6):                 # samples at 0.00 .. 0.17
        t = i / fps
        x = int(speed * t)
        dets.append(openscrub.Detection(t, t + 0.01, (x, 100, x + 60, 160),
                                        "face", "face", 0.9, (0, 0),
                                        dense=True))
    t2 = 0.6                           # detector missed 0.17 .. 0.60
    x2 = int(speed * t2)
    dets.append(openscrub.Detection(t2, t2 + 0.01, (x2, 100, x2 + 60, 160),
                                    "face", "face", 0.9, (0, 0), dense=True))
    openscrub.assign_dense_tracks(dets)
    assert len({d.track for d in dets}) == 1, "one physical face = one track"
    openscrub.smooth_dense_tracks(dets, fps, video=None)
    for t in np.arange(0.20, 0.58, 0.02):
        true_cx = speed * t + 30
        cover = [d for d in dets if d.t_start - 1e-6 <= t <= d.t_end + 1e-6]
        assert cover, f"flicker gap not covered at t={t:.2f}"
        assert any(abs((d.cbox[0] + d.cbox[2]) / 2 - true_cx) < 45
                   for d in cover), \
            f"box does not track the moving face at t={t:.2f}"


def test_stride_gap_frames_get_interpolated_cover():
    """With samples 2 or 3 frames apart (--dense-face-stride / scan-speed
    balanced/fast), every in-between frame must be covered by a box that
    follows the moving face. The old interpolation stretched the EARLIER
    sample's own box over the in-between frame, so the blur lagged one
    frame behind a moving face on every other frame — measured: stride 2
    under-covered ~40% of moving-face frames on a synthetic clip."""
    fps = 30.0
    for stride in (2, 3):
        speed = 30.0 * fps                 # 30 px per frame, rightward
        dets = []
        for k in range(8):
            t = k * stride / fps
            x = speed * t
            dets.append(openscrub.Detection(
                t, t + 0.3 * stride / fps, (x, 100, x + 60, 160),
                "face", "face", 0.9, (0, 0), dense=True))
        openscrub.assign_dense_tracks(dets)
        openscrub.smooth_dense_tracks(dets, fps, video=None)
        for f in range(1, 7 * stride):
            if f % stride == 0:
                continue                    # a real sample frame
            t = f / fps
            act = [d for d in dets if d.t_start - 0.01 <= t <= d.t_end + 0.01]
            act = openscrub._dedupe_dense(act)
            assert act, f"stride {stride}: frame {f} has no cover"
            tx = speed * t                  # where the face really is
            assert any(d.cbox[0] <= tx + 1 and d.cbox[2] >= tx + 59
                       for d in act), \
                f"stride {stride}: frame {f} cover lags the moving face"


def test_scan_speed_presets_never_slow_explicit_flags():
    """--scan-speed maps to (stride, face-detection scale), and a preset
    can only make a scan FASTER than explicit flags: stride takes the max,
    scale the min. thorough leaves everything as given."""
    def prep(*extra):
        p = openscrub.build_parser()
        return openscrub._prep_args(p.parse_args(["x.mp4", *extra]), p)
    a = prep()
    assert (a.dense_face_stride, a.detect_scale) == (1, 1.0)
    for name, (stride, scale) in openscrub.SCAN_SPEEDS.items():
        a = prep("--scan-speed", name)
        assert (a.dense_face_stride, a.detect_scale) == (stride, scale), name
    a = prep("--scan-speed", "balanced", "--detect-scale", "0.4")
    assert (a.dense_face_stride, a.detect_scale) == (2, 0.4)
    a = prep("--scan-speed", "fastest", "--dense-face-stride", "5")
    assert (a.dense_face_stride, a.detect_scale) == (5, 0.5)
    assert set(openscrub.SCAN_SPEEDS) == {"thorough", "balanced", "fast",
                                          "fastest"}


def test_scan_speed_wired_through_web(tmp_path):
    """The editor's Scan speed select must reach the engine, every option
    must be a real preset, and anything unrecognized falls back to
    thorough (fail closed: unknown never means faster)."""
    import zones_ui
    import openscrub_web as w
    page = zones_ui.ZONES_PAGE
    assert 'id="sspeed"' in page and "scan_speed:$(\"sspeed\").value" in page
    for name in openscrub.SCAN_SPEEDS:
        assert 'value="%s"' % name in page, name
    job = {"video": str(tmp_path / "x.mp4"), "dir": str(tmp_path),
           "options": {"scan_speed": "fast"}}
    assert w.build_args(job).scan_speed == "fast"
    assert w.build_args(job).dense_face_stride == 3
    job["options"]["scan_speed"] = "ludicrous"
    assert w.build_args(job).scan_speed == "thorough"
    assert w.build_args(job).dense_face_stride == 1


def test_dense_onset_walkback(tmp_path):
    """The first dense detection of a track is template-matched backward
    through the file: frames where the object was visible before the
    detector's first hit must end up covered (the v1.0.21 onset leak),
    and the walked boxes must follow the object's true positions."""
    path = str(tmp_path / "onset.mp4")
    fps = 30
    rng = np.random.default_rng(7)
    patch = rng.integers(0, 255, (64, 64, 3)).astype(np.uint8)

    def pos(t):                        # moving right at 120 px/s
        return int(60 + 120 * t), 140

    appear = 0.5
    out = cv2.VideoWriter(path, cv2.VideoWriter_fourcc(*"mp4v"), fps,
                          (640, 360))
    for i in range(3 * fps):
        t = i / fps
        fr = np.full((360, 640, 3), 200, np.uint8)
        if t >= appear:
            x, y = pos(t)
            fr[y:y + 64, x:x + 64] = patch
        out.write(fr)
    out.release()

    t0 = 1.5                           # detector "first fires" a second late
    x0, y0 = pos(t0)
    dets = [openscrub.Detection(t0, t0 + 0.01, (x0, y0, x0 + 64, y0 + 64),
                                "face", "face", 0.9, (0, 0), dense=True)]
    openscrub.assign_dense_tracks(dets)
    openscrub.smooth_dense_tracks(dets, fps, path)
    start = min(d.t_start for d in dets)
    assert start <= appear + 0.35, \
        f"walk-back should reach near the true first frame, got {start:.2f}"
    assert start >= appear - 0.40, \
        f"must not extend far before the object existed, got {start:.2f}"
    early = [d for d in dets if appear <= d.t_start < 1.0]
    assert early, "walk-back should add pre-detection samples"
    for e in early:
        true_cx = pos(e.t_start)[0] + 32
        got_cx = (e.cbox[0] + e.cbox[2]) / 2
        assert abs(got_cx - true_cx) < 40, \
            f"walked box off the object at t={e.t_start:.2f}"


def test_hdr_probe_and_tonemap(tmp_path):
    """HDR input (PQ transfer / BT.2020 tags) is detected and tone-mapped
    to tagged SDR BT.709 at intake; SDR input is left untouched."""
    import shutil as _sh
    if not (_sh.which("ffmpeg") and _sh.which("ffprobe")):
        pytest.skip("ffmpeg not available")
    if not (openscrub._ffmpeg_has("zscale") and openscrub._ffmpeg_has("tonemap")):
        pytest.skip("ffmpeg lacks zscale/tonemap")
    hdr = str(tmp_path / "hdr.mp4")
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error",
                    "-f", "lavfi", "-i", "testsrc2=duration=1:size=320x240:rate=30",
                    "-c:v", "libx264", "-pix_fmt", "yuv420p",
                    "-color_primaries", "bt2020", "-color_trc", "smpte2084",
                    "-colorspace", "bt2020nc",
                     "-x264-params", "colorprim=bt2020:transfer=smpte2084:colormatrix=bt2020nc", hdr], check=True)
    is_hdr, desc = openscrub.probe_hdr(hdr)
    assert is_hdr and desc == "HDR10/PQ"

    class A:
        video = hdr
        output = str(tmp_path / "out.mp4")
        encoder = "cpu"
    args = A()
    openscrub.normalize_vfr(args, openscrub.Callbacks())
    assert args.video.endswith(".sdr.mp4") and os.path.exists(args.video)
    assert args.hdr_tonemapped and args.original_video == hdr
    again, _ = openscrub.probe_hdr(args.video)
    assert not again, "normalized file must probe as SDR"

    sdr = str(tmp_path / "sdr.mp4")
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error",
                    "-f", "lavfi", "-i", "testsrc2=duration=1:size=320x240:rate=30",
                    "-c:v", "libx264", "-pix_fmt", "yuv420p", sdr], check=True)
    assert openscrub.probe_hdr(sdr) == (False, None)

    class B:
        video = sdr
        output = str(tmp_path / "out2.mp4")
        encoder = "cpu"
    args2 = B()
    openscrub.normalize_vfr(args2, openscrub.Callbacks())
    assert args2.video == sdr, "CFR SDR input must be a no-op"


def test_report_roundtrip_preserves_tracks(tmp_path):
    """dense/track must survive report write -> load: rendering rewrites
    the report through this round trip, and losing the track ids exploded
    the re-opened review into one card per frame sample (v1.0.25 bug)."""
    d = openscrub.Detection(1.0, 1.5, (10, 10, 50, 50), "face", "face",
                            0.9, (0, 0), dense=True, track=3)
    args = openscrub.build_parser().parse_args(["dummy.mp4"])
    state = {"fps": 30.0, "cum": [(0.0, 0.0)], "bands": [(0.0, 0.0)],
             "detections": [d], "input_sha256": "x"}
    rp = str(tmp_path / "r.json")
    d.person = 2
    openscrub.write_report(rp, args, state)
    dets, _, _ = openscrub.load_report(rp)
    assert dets[0].dense is True and dets[0].track == 3
    assert dets[0].person == 2, "person id must survive the round trip"


def _hdr_clip(path):
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error",
                    "-f", "lavfi",
                    "-i", "testsrc2=duration=2:size=1280x720:rate=30",
                    "-vf", "drawbox=x=50:y=260:w=400:h=60:color=white:t=fill",
                    "-c:v", "libx264", "-pix_fmt", "yuv420p",
                    "-color_primaries", "bt2020", "-color_trc", "smpte2084",
                    "-colorspace", "bt2020nc",
                     "-x264-params", "colorprim=bt2020:transfer=smpte2084:colormatrix=bt2020nc", path], check=True)


def _vstream(path):
    p = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0",
                        "-show_entries",
                        "stream=codec_name,pix_fmt,color_transfer",
                        "-of", "json", path], capture_output=True, text=True)
    return json.loads(p.stdout)["streams"][0]


def test_hdr_output_preserved(tmp_path):
    """HDR source + default --hdr-output match: output must be 10-bit HEVC
    with the PQ transfer preserved, and the blur must land in it."""
    import shutil as _sh
    if not (_sh.which("ffmpeg") and _sh.which("ffprobe")):
        pytest.skip("ffmpeg not available")
    if openscrub.hevc10_encoder("x264") is None:
        pytest.skip("no 10-bit HEVC encoder in this environment")
    src = str(tmp_path / "hdrsrc.mp4")
    out = cv2.VideoWriter(src + ".tmp.mp4", cv2.VideoWriter_fourcc(*"mp4v"),
                          30, (1280, 720))
    fr = np.full((720, 1280, 3), 245, np.uint8)
    cv2.putText(fr, "SSN 123-45-6789", (60, 300), FONT, 1.1, (20, 20, 20), 2)
    for _ in range(60):
        out.write(fr)
    out.release()
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error",
                    "-i", src + ".tmp.mp4", "-c:v", "libx264",
                    "-color_primaries", "bt2020", "-color_trc", "smpte2084",
                    "-colorspace", "bt2020nc",
                     "-x264-params", "colorprim=bt2020:transfer=smpte2084:colormatrix=bt2020nc", src], check=True)
    _, dets = run(src, "--categories", "ssn", "--encoder", "x264")
    st = _vstream(src.replace(".mp4", "_red.mp4"))
    assert st["codec_name"] == "hevc", st
    assert "10" in st["pix_fmt"], st
    assert st.get("color_transfer") == "smpte2084", st
    ssn = [d for d in dets if d["category"] == "ssn"]
    assert ssn, "SSN detected on the tone-mapped scan copy"
    b = ssn[0]["cbox"]
    v = sharp(src.replace(".mp4", "_red.mp4"), 1.0,
              (b[0] + 4, b[1] + 4, b[2] - 4, b[3] - 4))
    assert v < 300, f"HDR output not blurred inside the detection ({v:.0f})"


def test_hdr_output_sdr_toggle(tmp_path):
    """--hdr-output sdr on an HDR source: output must be plain SDR H.264
    (the tone-mapped path), never HDR."""
    import shutil as _sh
    if not (_sh.which("ffmpeg") and _sh.which("ffprobe")):
        pytest.skip("ffmpeg not available")
    if not (openscrub._ffmpeg_has("zscale") and openscrub._ffmpeg_has("tonemap")):
        pytest.skip("ffmpeg lacks zscale/tonemap")
    src = str(tmp_path / "hdrsrc2.mp4")
    _hdr_clip(src)
    _, _ = run(src, "--categories", "ssn", "--encoder", "x264",
               "--hdr-output", "sdr")
    st = _vstream(src.replace(".mp4", "_red.mp4"))
    assert st["codec_name"] == "h264", st
    assert st.get("color_transfer") in (None, "bt709", "unknown"), st
    assert openscrub.probe_hdr(src.replace(".mp4", "_red.mp4")) == (False, None)


def test_codec_and_container_honored(tmp_path):
    """--codec hevc must produce an HEVC stream, and a .mkv/.mov output
    path must produce that actual container (the web download previously
    renamed everything .mp4)."""
    import shutil as _sh
    if not (_sh.which("ffmpeg") and _sh.which("ffprobe")):
        pytest.skip("ffmpeg not available")
    if openscrub.hevc10_encoder("x264") is None:
        pytest.skip("no HEVC encoder in this environment")
    src = make_video(str(tmp_path / "c.mp4"), [(300, "SSN 123-45-6789")])
    parser = openscrub.build_parser()
    out = str(tmp_path / "out.mkv")
    args = parser.parse_args([src, "--engine", "tesseract", "-o", out,
                              "--categories", "ssn", "--encoder", "x264",
                              "--codec", "hevc"])
    args = openscrub._prep_args(args, parser)

    class Quiet(openscrub.Callbacks):
        def log(self, m):
            pass
    openscrub.run_pipeline(args, Quiet())
    p = subprocess.run(["ffprobe", "-v", "error", "-show_entries",
                        "format=format_name", "-select_streams", "v:0",
                        "-show_entries", "stream=codec_name",
                        "-of", "json", out], capture_output=True, text=True)
    doc = json.loads(p.stdout)
    assert doc["streams"][0]["codec_name"] == "hevc", doc
    assert "matroska" in doc["format"]["format_name"], doc


def test_detector_only_scan_skips_ocr(tmp_path, monkeypatch):
    """A faces/plates-only job must not load the OCR engine, spaCy, or
    PHI memory — detector-only scan. Loading them anyway cost seconds of
    startup and gigabytes of RAM for detectors that read no text."""
    called = []
    monkeypatch.setattr(openscrub, "make_ocr",
                        lambda *a, **k: called.append("ocr"))
    monkeypatch.setattr(openscrub, "NameDetector",
                        lambda *a, **k: called.append("namer"))
    src = make_video(str(tmp_path / "f.mp4"), [(300, "SSN 123-45-6789")])
    parser = openscrub.build_parser()
    args = parser.parse_args([src, "--engine", "tesseract",
                              "-o", str(tmp_path / "f_red.mp4"),
                              "--categories", "face", "--encoder", "x264"])
    args = openscrub._prep_args(args, parser)
    logs = []

    class CB(openscrub.Callbacks):
        def log(self, m):
            logs.append(m)
    state = openscrub.run_scan(args, CB())
    assert called == [], f"loaded needlessly: {called}"
    assert any("detector-only scan" in l for l in logs)
    assert any("names: skipped" in l for l in logs)
    # the SSN text in the video must NOT be detected (face-only job) and
    # the run must complete cleanly
    assert not [d for d in state["detections"] if d.category == "ssn"]


def test_face_model_registry_and_fallback(tmp_path):
    """The face-model registry loads with pinned hashes, and a face model
    that can't load falls back LOUDLY to the built-in YuNet — face
    detection must never silently disappear."""
    reg = openscrub.load_model_registry("face")
    assert any(m["id"] == "centerface" for m in reg)
    assert all(m.get("sha256") for m in reg), "face models must ship pinned"
    logs = []

    class CB(openscrub.Callbacks):
        def log(self, m):
            logs.append(m)
    fd = openscrub.FaceDetector(CB(), model_path=str(tmp_path / "nope.onnx"))
    assert fd.net is None, "missing model must not leave a broken detector"
    assert any("falling back" in l for l in logs)
    assert fd.yunet is not None or fd.haar is not None


def test_mosaic_and_ellipse_blur_shapes():
    """Mosaic must actually pixelate (it silently fell back to Gaussian
    blur before), and the ellipse shape must leave region corners intact."""
    rng = np.random.default_rng(1)
    base = np.clip(rng.normal(128, 40, (200, 200, 3)), 0, 255).astype(np.uint8)
    mos = base.copy()
    openscrub.blur_region(mos, 40, 40, 160, 160, "mosaic")
    blur = base.copy()
    openscrub.blur_region(blur, 40, 40, 160, 160, "blur")
    assert np.abs(mos.astype(int) - blur.astype(int)).mean() > 3, \
        "mosaic must differ from Gaussian blur"
    # mosaic tiles: many identical adjacent pixels
    inner = mos[60:140, 60:140]
    same = (inner[:, 1:] == inner[:, :-1]).all(axis=2).mean()
    assert same > 0.5, "mosaic should produce flat tiles"

    ell = base.copy()
    openscrub.blur_region(ell, 40, 40, 160, 160, "blur", shape="ellipse")
    assert (ell[41:47, 41:47] == base[41:47, 41:47]).all(), \
        "ellipse must leave the region corner untouched"
    c = 100
    assert np.abs(ell[c-3:c+3, c-3:c+3].astype(int)
                  - blur[c-3:c+3, c-3:c+3].astype(int)).mean() < 1, \
        "ellipse center must be blurred like the rect blur"


def test_ellipse_blur_covers_frame_border():
    """A face cut off by the frame border used to get an ellipse inscribed in
    the CLAMPED box — a squat ellipse that pinched away from the border,
    leaking the face right at the frame edge (the boat-video top-of-frame
    leak). An edge-touching region must now be covered all the way to the
    border; a region away from every border keeps the corner-preserving
    inscribed ellipse."""
    rng = np.random.default_rng(2)
    base = np.clip(rng.normal(128, 40, (200, 200, 3)), 0, 255).astype(np.uint8)

    # region touching the TOP border: full width of the region must be
    # blurred at the border, including both border-side corners
    img = base.copy()
    openscrub.blur_region(img, 40, 0, 160, 90, "blur", shape="ellipse")
    assert (img[0:4, 42:52] != base[0:4, 42:52]).any(), \
        "border-side left corner must be blurred"
    assert (img[0:4, 148:158] != base[0:4, 148:158]).any(), \
        "border-side right corner must be blurred"
    assert (img[0:2, 95:105] != base[0:2, 95:105]).any(), \
        "border row center must be blurred"

    # two-border corner contact (top-left): the corner itself must be covered
    img = base.copy()
    openscrub.blur_region(img, 0, 0, 100, 100, "blur", shape="ellipse")
    assert (img[0:4, 0:4] != base[0:4, 0:4]).any(), \
        "frame corner must be blurred when the region sits in the corner"

    # away from every border: inscribed ellipse still leaves region corners
    # untouched (the existing aesthetic contract)
    img = base.copy()
    openscrub.blur_region(img, 40, 40, 160, 160, "blur", shape="ellipse")
    assert (img[41:47, 41:47] == base[41:47, 41:47]).all(), \
        "interior regions keep corner-preserving inscribed ellipse"

    # HDR twin: same coverage guarantee on the 10-bit luma plane
    yp = np.clip(rng.normal(512, 100, (200, 200)), 64, 940).astype(np.uint16)
    up = np.full((100, 100), 512, np.uint16)
    vp = np.full((100, 100), 512, np.uint16)
    ybase = yp.copy()
    openscrub._blur_yuv10(yp, up, vp, 40, 0, 160, 90, "blur",
                          shape="ellipse")
    assert (yp[0:4, 42:52] != ybase[0:4, 42:52]).any(), \
        "HDR path must cover the border-side corner too"


def _moving_square_video(path, frames=150, fps=30):
    """Textured square marching right over static noise — trackable."""
    w = cv2.VideoWriter(path, cv2.VideoWriter_fourcc(*"mp4v"), fps, (640, 360))
    rng = np.random.default_rng(11)
    bg = rng.integers(0, 60, (360, 640, 3), np.uint8)
    obj = ((np.indices((60, 60)).sum(0) % 16 < 8) * 200).astype(np.uint8)
    for i in range(frames):
        fr = bg.copy()
        x = 40 + i * 3
        fr[150:210, x:x + 60] = np.dstack([obj, obj // 2 + 60, obj])
        w.write(fr)
    w.release()
    return path


def test_track_manual_region(tmp_path):
    """Targeted redaction: a user-circled region is template-tracked through
    the chosen time window, both directions, and never escapes the window."""
    v = _moving_square_video(str(tmp_path / "move.mp4"))
    s = openscrub.track_manual_region(v, (218, 148, 282, 212), 2.0, 1.0, 4.0)
    assert len(s) > 30
    assert s[0][0] >= 0.99 and s[-1][0] <= 4.01, "window must bound the track"
    mid = min(s, key=lambda q: abs(q[0] - 3.0))     # true x at t=3.0 is 310
    assert abs(mid[1][0] - 310) < 15, "forward track must follow the object"
    early = min(s, key=lambda q: abs(q[0] - 1.2))   # true x at t=1.2 is 148
    assert abs(early[1][0] - 148) < 15, "backward track must follow too"
    # unusable inputs fail cleanly, not loudly
    assert openscrub.track_manual_region(v, (0, 0, 4, 4), 2.0, 1.0, 4.0) == []
    assert openscrub.track_manual_region(
        str(tmp_path / "nope.mp4"), (10, 10, 60, 60), 1.0, 0.0, 2.0) == []


def test_audio_redaction_mute_and_report_roundtrip(tmp_path):
    """Audio spans silence the output inside the span, keep it outside, and
    survive the write_report/from-report round trip."""
    src = str(tmp_path / "a.mp4")
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error",
                    "-f", "lavfi", "-i", "color=c=gray:s=320x240:d=5:r=30",
                    "-f", "lavfi", "-i", "sine=frequency=440:duration=5",
                    "-c:v", "libx264", "-c:a", "aac", src], check=True)
    assert openscrub.probe_has_audio(src)
    det = openscrub.Detection(0.5, 1.0, (10, 10, 60, 60), "manual", "x",
                              1.0, (0, 0), last_seen=0.5)
    n = 150
    dst = str(tmp_path / "out.mp4")

    class Q(openscrub.Callbacks):
        def log(self, m):
            pass
    openscrub.render(src, dst, [det], [(0.0, 0.0)] * n, [(0.0, 0.0)] * n,
                     30.0, pad=4, mode="blur", preview=False,
                     audio_spans=[(2.0, 4.0, "mute")], cb=Q())
    raw = subprocess.run(["ffmpeg", "-loglevel", "error", "-i", dst,
                          "-f", "f32le", "-ac", "1", "-ar", "8000", "-"],
                         capture_output=True).stdout
    a = np.frombuffer(raw, np.float32)
    sr = 8000

    def rms(x):
        return float(np.sqrt(np.mean(x ** 2))) if len(x) else 0.0
    assert rms(a[int(2.4 * sr):int(3.6 * sr)]) < 0.01, "span must be silent"
    assert rms(a[int(0.5 * sr):int(1.5 * sr)]) > 0.02, "rest must survive"
    # spans parse + no-audio sources degrade to stream copy
    assert openscrub.parse_audio_spans("1-2,3.5-4", "bleep") == [
        (1.0, 2.0, "bleep"), (3.5, 4.0, "bleep")]
    silent = _moving_square_video(str(tmp_path / "sil.mp4"), frames=30)
    amap, acodec = openscrub.audio_ffmpeg_args(silent, [(0, 1, "mute")])
    assert acodec == ["-c:a", "copy"], "no audio stream -> plain copy"


def test_textless_band_suppression():
    """A scan with ZERO OCR text hits must drop its safety bands: bands
    exist to cover unscanned text, and on handheld footage the camera-
    motion probe reads as static, camera bob fakes scroll offsets — a
    real address-only selfie job shipped a thin phantom blur bar at the
    bottom edge. Any text hit at all keeps bands untouched (fail
    closed)."""
    moving = [(0.0, 0.0), (0.0, -4.0), (3.0, 0.0), (0.0, 0.0)]
    out, sup = openscrub._suppress_textless_bands(list(moving), 0)
    assert sup and all(x == 0 and y == 0 for x, y in out)
    assert len(out) == len(moving)
    # text WAS found -> bands untouched, no matter the offsets
    out, sup = openscrub._suppress_textless_bands(list(moving), 7)
    assert not sup and out == moving
    # already-quiet bands (sub-threshold jitter) -> untouched, not "suppressed"
    quiet = [(0.0, 0.0), (1.0, -1.5)]
    out, sup = openscrub._suppress_textless_bands(list(quiet), 0)
    assert not sup and out == quiet


def test_rate_cap_args_nvenc_only():
    """The balanced/share bitrate ceiling applies to NVENC only (constant-
    quality NVENC has no size anchor — a 12s 4K 'share' render came out
    123MB), scales with resolution/fps, and never touches archival or the
    CPU/QSV encoders."""
    a = openscrub._rate_cap_args("hevc_nvenc", "share", 3840, 2160, 60.0)
    assert a[0] == "-maxrate" and a[2] == "-bufsize"
    cap = int(a[1])
    assert cap == int(3840 * 2160 * 60 * 0.04) and int(a[3]) == 2 * cap
    small = int(openscrub._rate_cap_args(
        "h264_nvenc", "share", 1080, 1920, 30.0)[1])
    assert small < cap                                    # scales down
    assert openscrub._rate_cap_args("hevc_nvenc", "archival",
                                    3840, 2160, 60.0) == []
    assert openscrub._rate_cap_args("libx264", "share", 3840, 2160, 60.0) == []
    assert openscrub._rate_cap_args("hevc_qsv", "share", 3840, 2160, 60.0) == []


def test_out_quality_tiers_shrink_output(tmp_path):
    """--out-quality maps to per-encoder constant-quality values: share <
    balanced < archival in file size, with identical frame counts (the
    tier changes bitrate only — never timeline or redaction strength)."""
    src = str(tmp_path / "q.mp4")
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi",
                    "-i", "testsrc2=s=320x240:r=30:d=2", "-c:v", "libx264",
                    "-pix_fmt", "yuv420p", src], check=True)

    class Q(openscrub.Callbacks):
        def log(self, m):
            pass
    n, sizes, frames = 60, {}, {}
    for q in ("archival", "balanced", "share"):
        dst = str(tmp_path / f"q_{q}.mp4")
        openscrub.render(src, dst, [], [(0, 0)] * n, [(0, 0)] * n, 30.0,
                         pad=4, mode="blur", preview=False, cb=Q(),
                         out_quality=q)
        sizes[q] = os.path.getsize(dst)
        frames[q] = int(cv2.VideoCapture(dst).get(cv2.CAP_PROP_FRAME_COUNT))
    assert sizes["share"] < sizes["balanced"] < sizes["archival"], sizes
    assert len(set(frames.values())) == 1, frames
    # every ladder codec has all three tiers defined
    for codec, tiers in openscrub._OUT_QUALITY.items():
        assert set(tiers) == {"archival", "balanced", "share"}, codec


def test_audio_transcript_report_persistence(tmp_path):
    """The review transcript view reads audio_transcript from the report:
    write_report must persist it beside audio_suggestions, and the
    no-whisper/no-audio paths must return the ([], []) tuple shape (the
    caller unpacks two values)."""
    d = openscrub.Detection(1.0, 1.5, (10, 10, 50, 50), "face", "face",
                            0.9, (0, 0))
    args = openscrub.build_parser().parse_args(["dummy.mp4"])
    tx = [[0.7, 1.3, " My"], [1.3, 1.9, " address"]]
    sugg = [{"t0": 0.35, "t1": 2.4, "category": "address", "text": "x"}]
    state = {"fps": 30.0, "cum": [(0.0, 0.0)], "bands": [(0.0, 0.0)],
             "detections": [d], "input_sha256": "x",
             "audio_suggestions": sugg, "audio_transcript": tx}
    rp = str(tmp_path / "r.json")
    openscrub.write_report(rp, args, state)
    with open(rp, encoding="utf-8") as f:
        doc = json.load(f)
    assert doc["audio_transcript"] == tx
    assert doc["audio_suggestions"] == sugg

    class Q(openscrub.Callbacks):
        def log(self, m):
            pass
    out = openscrub.transcribe_audio_pii(
        str(tmp_path / "missing.mp4"), {"address"}, Q())
    assert out == ([], []), "failure paths must keep the tuple shape"


def test_categories_none_manual_only(tmp_path):
    """--categories none = manual-only job: no detectors, no OCR, but a
    valid report with render_state so review can add tracked objects."""
    v = make_video(str(tmp_path / "n.mp4"), [(150, "Patient: John Smith")])
    res, dets = run(v, "--categories", "none")
    assert dets == []
    doc = json.load(open(v.replace(".mp4", "_aud.json")))
    assert doc["render_state"]["fps"] > 0


def test_scan_window_fast_skip_and_output_trim(tmp_path):
    """Pre-scan scoping: the detection window SKIPS decode work outside it
    (seek past the head, stop at the end) when scroll tracking is off, and
    --clip-start/--clip-end trim the output — with audio redaction spans
    shifted into the trimmed timeline."""
    src = str(tmp_path / "s.mp4")
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error",
                    "-f", "lavfi", "-i", "testsrc2=s=320x240:d=10:r=30",
                    "-f", "lavfi", "-i", "sine=frequency=440:duration=10",
                    "-c:v", "libx264", "-c:a", "aac", src], check=True)
    parser = openscrub.build_parser()
    args = parser.parse_args(
        [src, "--categories", "face", "--skip-start", "3", "--skip-end", "4",
         "--clip-start", "2.5", "--clip-end", "6.5", "--audio-redact", "4-5",
         "-o", str(tmp_path / "out.mp4"),
         "--report", str(tmp_path / "r.json")])
    args = openscrub._prep_args(args, parser)
    logs = []

    class Q(openscrub.Callbacks):
        def log(self, m):
            logs.append(m)
    openscrub.run_pipeline(args, Q())
    joined = "\n".join(logs)
    assert "fast-skip" in joined, "head frames must not be decoded"
    assert "fast-stop" in joined, "tail frames must not be decoded"
    assert "output trim" in joined
    dur = float(subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration",
         "-of", "csv=p=0", str(tmp_path / "out.mp4")],
        capture_output=True, text=True).stdout.strip())
    assert 3.5 < dur < 4.6, "output must be trimmed to the keep window"
    # the 4-5s mute (original time) lands at 1.5-2.5s of the trimmed output
    raw = subprocess.run(
        ["ffmpeg", "-loglevel", "error", "-i", str(tmp_path / "out.mp4"),
         "-f", "f32le", "-ac", "1", "-ar", "8000", "-"],
        capture_output=True).stdout
    a = np.frombuffer(raw, np.float32)
    sr = 8000

    def rms(x):
        return float(np.sqrt(np.mean(x ** 2))) if len(x) else 0.0
    assert rms(a[int(1.7 * sr):int(2.3 * sr)]) < 0.01, \
        "audio span must shift with the trim"
    assert rms(a[int(0.2 * sr):int(1.2 * sr)]) > 0.02


def test_per_window_zones(tmp_path):
    """Window-specific zones: the same spatial location is gated differently
    depending on which detection window (and its zones) covers that time.
    The whole-clip default (no windows) keeps today's global-zone behavior,
    verified by the existing zone tests."""
    v = str(tmp_path / "z.mp4")
    w = cv2.VideoWriter(v, cv2.VideoWriter_fourcc(*"mp4v"), 10, (640, 480))
    for i in range(100):
        fr = np.full((480, 640, 3), 255, np.uint8)
        pos = (20, 60) if i < 50 else (380, 440)   # top-left then bottom-right
        cv2.putText(fr, "CLM-1234567", pos, cv2.FONT_HERSHEY_SIMPLEX,
                    1.2, (0, 0, 0), 3)
        w.write(fr)
    w.release()
    wf = str(tmp_path / "w.json")
    # both windows zoned to the BOTTOM-RIGHT quadrant. In 0-5s the token is
    # top-left (outside the zone -> dropped); in 5-10s it's bottom-right
    # (inside -> kept). Proves the zone gate is applied per window/time.
    json.dump({"windows": [
        {"t0": 0.0, "t1": 0.5, "zones": {"mrn": [[0.5, 0.5, 1.0, 1.0]]}},
        {"t0": 0.5, "t1": 1.0, "zones": {"mrn": [[0.5, 0.5, 1.0, 1.0]]}}]},
        open(wf, "w"))
    parser = openscrub.build_parser()
    args = parser.parse_args(
        [v, "--categories", "mrn", "--mrn-regex", r"CLM-\d{7}",
         "--engine", "tesseract", "--windows", wf,
         "-o", str(tmp_path / "o.mp4"), "--report", str(tmp_path / "r.json")])
    args = openscrub._prep_args(args, parser)

    class Q(openscrub.Callbacks):
        def log(self, m):
            pass
    openscrub.run_pipeline(args, Q())
    doc = json.load(open(str(tmp_path / "r.json")))

    def enabled(rng):
        return [x for x in doc["detections"]
                if rng(x["t_start"]) and x.get("enabled", True)
                and not x.get("zone_dropped")]
    assert len(enabled(lambda t: t < 5)) == 0, \
        "top-left token is outside window A's bottom-right zone -> dropped"
    assert len(enabled(lambda t: t >= 5)) > 0, \
        "bottom-right token is inside window B's zone -> kept"
    assert doc["provenance"].get("windows"), "windows recorded in report"


def test_stacked_windows_union_and_per_window_cats(tmp_path):
    """Overlapping (stacked) windows: at any time t the scope is the UNION
    of every covering window — and each window carries its own categories,
    so 'faces the whole clip, names only 5-7s' works as two stacked
    windows."""
    v = str(tmp_path / "z.mp4")
    w = cv2.VideoWriter(v, cv2.VideoWriter_fourcc(*"mp4v"), 10, (640, 480))
    for i in range(100):
        fr = np.full((480, 640, 3), 255, np.uint8)
        pos = (20, 60) if i < 50 else (380, 440)
        cv2.putText(fr, "CLM-1234567", pos, cv2.FONT_HERSHEY_SIMPLEX,
                    1.2, (0, 0, 0), 3)
        w.write(fr)
    w.release()

    def run(windows, cats):
        wf = str(tmp_path / "w.json")
        json.dump({"windows": windows}, open(wf, "w"))
        parser = openscrub.build_parser()
        args = parser.parse_args(
            [v, "--categories", cats, "--mrn-regex", r"CLM-\d{7}",
             "--engine", "tesseract", "--windows", wf,
             "-o", str(tmp_path / "o.mp4"),
             "--report", str(tmp_path / "r.json")])
        args = openscrub._prep_args(args, parser)

        class Q(openscrub.Callbacks):
            def log(self, m):
                pass
        openscrub.run_pipeline(args, Q())
        doc = json.load(open(str(tmp_path / "r.json")))
        return [x for x in doc["detections"]
                if x.get("enabled", True) and not x.get("zone_dropped")]

    # W1 all-time zoned TOP-LEFT stacked with W2 (second half) zoned
    # BOTTOM-RIGHT: both token positions survive via the union
    en = run([
        {"t0": 0.0, "t1": 1.0, "cats": ["mrn"],
         "zones": {"mrn": [[0.0, 0.0, 0.5, 0.5]]}},
        {"t0": 0.5, "t1": 1.0, "cats": ["mrn"],
         "zones": {"mrn": [[0.5, 0.5, 1.0, 1.0]]}}], "mrn")
    assert [x for x in en if x["t_start"] < 5], "TL kept via W1"
    assert [x for x in en if x["t_start"] >= 5], "BR kept via W2 (union)"

    # per-window cats: mrn requested ONLY by the second-half window — the
    # engine still loads it (union) but it fires only inside that window
    en = run([{"t0": 0.0, "t1": 1.0, "cats": ["face"]},
              {"t0": 0.5, "t1": 1.0, "cats": ["mrn"]}], "face")
    mrn = [x for x in en if x["category"] == "mrn"]
    assert mrn and all(x["t_start"] >= 5 for x in mrn), \
        "mrn fires only during the window that declares it"


def test_fraction_windows_resolve_against_server_duration(tmp_path):
    """The web UI sends detection windows and output trim as FRACTIONS of
    the duration (not seconds) so an iPhone's browser-reported length can't
    desync from the server's. The server resolves them against its OWN
    measured duration."""
    src = str(tmp_path / "s.mp4")
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error",
                    "-f", "lavfi", "-i", "testsrc2=s=320x240:d=10:r=30",
                    "-f", "lavfi", "-i", "sine=frequency=440:duration=10",
                    "-c:v", "libx264", "-c:a", "aac", src], check=True)
    assert 9.5 < openscrub._probe_duration(src) < 10.5
    parser = openscrub.build_parser()
    args = parser.parse_args(
        [src, "--categories", "face",
         "--detect-windows-frac", "0.1-0.2,0.7-0.8",
         "--clip-frac", "0.25-0.65",
         "-o", str(tmp_path / "out.mp4"),
         "--report", str(tmp_path / "r.json")])
    args = openscrub._prep_args(args, parser)
    logs = []

    class Q(openscrub.Callbacks):
        def log(self, m):
            logs.append(m)
    openscrub.run_pipeline(args, Q())
    joined = "\n".join(logs)
    assert "detection windows: 1.0-2.0s, 7.0-8.0s" in joined, \
        "0.1-0.2 of a 10s video must resolve to 1-2s"
    dur = float(subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration",
         "-of", "csv=p=0", str(tmp_path / "out.mp4")],
        capture_output=True, text=True).stdout.strip())
    assert 3.5 < dur < 4.6, "clip 0.25-0.65 of 10s must trim to ~4s"


def test_multi_window_scan_and_track_mute(tmp_path):
    """Multiple detection windows scan only their ranges (seeking across the
    gaps), and per-track audio mute removes exactly the chosen track."""
    src = str(tmp_path / "mt.mp4")
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error",
                    "-f", "lavfi", "-i", "testsrc2=s=320x240:d=10:r=30",
                    "-f", "lavfi", "-i", "sine=frequency=440:duration=10",
                    "-f", "lavfi", "-i", "sine=frequency=880:duration=10",
                    "-map", "0:v", "-map", "1:a", "-map", "2:a",
                    "-c:v", "libx264", "-c:a", "aac", src], check=True)
    assert openscrub.probe_audio_streams(src) == 2
    parser = openscrub.build_parser()
    args = parser.parse_args(
        [src, "--categories", "face", "--detect-windows", "1-2,7-8",
         "--mute-audio-tracks", "1",
         "-o", str(tmp_path / "out.mp4"),
         "--report", str(tmp_path / "r.json")])
    args = openscrub._prep_args(args, parser)
    logs = []

    class Q(openscrub.Callbacks):
        def log(self, m):
            logs.append(m)
    openscrub.run_pipeline(args, Q())
    joined = "\n".join(logs)
    assert "detection windows: 1.0-2.0s, 7.0-8.0s" in joined
    assert "fast-skip: jumped 2.0" in joined, "gap between windows must seek"
    assert "fast-stop" in joined
    out = str(tmp_path / "out.mp4")
    assert openscrub.probe_audio_streams(out) == 1, \
        "muted track removed, other kept"
    raw = subprocess.run(["ffmpeg", "-loglevel", "error", "-i", out,
                          "-f", "f32le", "-ac", "1", "-ar", "8000", "-"],
                         capture_output=True).stdout
    a = np.frombuffer(raw, np.float32)
    sr = 8000
    seg = a[int(2 * sr):int(6 * sr)]
    freqs = np.fft.rfftfreq(len(seg), 1 / sr)
    peak = freqs[int(np.argmax(np.abs(np.fft.rfft(seg))))]
    assert abs(peak - 880) < 30, "the KEPT track must be the 880Hz one"


def test_plate_decode_output_formats():
    """PlateDetector._decode must parse all three ONNX plate-model output
    conventions. The 7-column end2end layout (current open-image-models YOLOv9)
    used to fall through to the raw-head branch and IndexError on row[4],
    crashing the whole scan; regression-guard every layout here.

    A no-model PlateDetector still has thresh/expand/nms set, so _decode is
    exercisable without loading anything."""
    det = openscrub.PlateDetector(thresh=0.5, expand=0.0, input_size=640)
    assert not det.available()          # no model resolved -> inert
    s, w, h = 1.0, 640, 640             # s=1 so box coords map 1:1

    # (C) 7-col end2end: batch,x1,y1,x2,y2,class,score  (the bug's format)
    out7 = np.array([[0, 100, 50, 200, 90, 0, 0.9],
                     [0, 10, 10, 20, 20, 0, 0.1]], np.float32)   # 2nd filtered
    r = det._decode(out7, s, w, h)
    assert len(r) == 1
    assert tuple(round(v) for v in r[0][:4]) == (100, 50, 200, 90)
    assert abs(r[0][4] - 0.9) < 1e-3

    # 7-col with a leading batch axis (1,N,7), as some runtimes emit
    assert len(det._decode(out7[None], s, w, h)) == 1

    # (B) 6-col end2end: x1,y1,x2,y2,score,class
    out6 = np.array([[100, 50, 200, 90, 0.9, 0]], np.float32)
    r = det._decode(out6, s, w, h)
    assert len(r) == 1
    assert tuple(round(v) for v in r[0][:4]) == (100, 50, 200, 90)

    # (A) raw YOLOv8 head: (5, N) cx,cy,w,h,score — one live anchor, rest zero
    raw = np.zeros((5, 10), np.float32)
    raw[:, 0] = [150, 70, 100, 40, 0.9]      # -> box (100,50,200,90)
    r = det._decode(raw, s, w, h)
    assert len(r) == 1
    assert tuple(round(v) for v in r[0][:4]) == (100, 50, 200, 90)

    # empty / degenerate outputs must return [] cleanly, never raise
    assert det._decode(np.zeros((0, 7), np.float32), s, w, h) == []
    assert det._decode(np.zeros((7,), np.float32), s, w, h) == []


def test_face_only_steady_camera_no_bands_no_giant_boxes(tmp_path):
    """The boat-video failure: a steady-camera video with a moving person,
    face-only job. Scan-cadence merging used to union the face's positions
    into a body-sized box, and the scroll tracker painted blur bands along
    the frame edges. Now: faces are dense on every video, and tracking/
    bands are off without text categories."""
    # synthesizing a reliably-detectable face is flaky in CI; assert the
    # MODE decisions directly on a textured video with a moving object
    rng = np.random.default_rng(3)
    bg = np.clip(rng.normal(150, 18, (360, 640, 3)), 0, 255).astype(np.uint8)
    path = str(tmp_path / "steady.mp4")
    out = cv2.VideoWriter(path, cv2.VideoWriter_fourcc(*"mp4v"), 30,
                          (640, 360))
    sq = rng.integers(0, 255, (60, 60, 3)).astype(np.uint8)
    for i in range(90):
        fr = bg.copy()
        x = 50 + i * 4
        fr[150:210, x:x+60] = sq          # moving object (not a face)
        out.write(fr)
    out.release()
    parser = openscrub.build_parser()
    args = parser.parse_args([path, "--engine", "tesseract",
                              "-o", str(tmp_path / "s_red.mp4"),
                              "--categories", "face", "--encoder", "x264"])
    args = openscrub._prep_args(args, parser)
    logs = []

    class CB(openscrub.Callbacks):
        def log(self, m):
            logs.append(m)
    state = openscrub.run_scan(args, CB())
    assert any("scroll tracking + safety bands off" in l for l in logs)
    assert any("dense faces: detecting" in l for l in logs)
    assert all(b == (0.0, 0.0) for b in state["bands"]), \
        "face-only jobs must never emit safety bands"
    assert all(c == (0.0, 0.0) for c in state["cum"]), \
        "face-only jobs must never accumulate scroll offsets"


def test_face_model_unions_with_yunet(tmp_path):
    """An optional face model must AUGMENT the built-in YuNet, never
    replace it: the union guarantees a model upgrade can only add faces.
    (SCRFD through a squeezed 640x640 input detected FEWER faces than the
    built-in — the v1.0.30 'upgrade made it worse' report.)"""
    logs = []

    class CB(openscrub.Callbacks):
        def log(self, m):
            logs.append(m)
    # a fake ONNX path fails to load -> falls back, yunet still active
    fd = openscrub.FaceDetector(CB(), model_path=str(tmp_path / "x.onnx"))
    assert fd.yunet is not None or fd.haar is not None
    # when a real model IS loaded, yunet must be loaded alongside it — the
    # union log line is the contract
    class FakeNet:
        def getUnconnectedOutLayersNames(self):
            return ("a", "b", "c", "d")
    import unittest.mock as mock
    with mock.patch.object(openscrub.cv2.dnn, "readNet",
                           return_value=FakeNet()):
        p = tmp_path / "cf.onnx"
        p.write_bytes(b"x" * 20000)
        logs.clear()
        fd2 = openscrub.FaceDetector(CB(), model_path=str(p))
    assert fd2.net is not None and fd2.arch == "centerface"
    assert fd2.yunet is not None, "built-in must run alongside the model"
    assert any("UNIONED" in l for l in logs)


def test_cuda_dnn_gating_cpu_fallback():
    """On a CPU OpenCV build (CI, the CPU Docker image), cuda_dnn_available()
    must be False and the detector factories must still return working
    detectors — the GPU path is purely additive."""
    assert openscrub.cuda_dnn_available() is False
    y = openscrub._model_dir() + "/face_detection_yunet_2023mar.onnx"
    if os.path.exists(y):
        det = openscrub._make_yunet(y, (320, 320), 0.6)
        assert det is not None
    # env override is honored (forces CPU even if a GPU were present)
    openscrub._CUDA_DNN = None
    os.environ["OPENSCRUB_CPU_DNN"] = "1"
    try:
        assert openscrub.cuda_dnn_available() is False
    finally:
        del os.environ["OPENSCRUB_CPU_DNN"]
        openscrub._CUDA_DNN = None


def test_person_detector_class_filter_and_registry():
    """The person category rides PlateDetector's machinery with a COCO class
    filter (WANT_CLASS=0). A multi-class end2end output must keep ONLY person
    rows; PlateDetector (single-class, WANT_CLASS=None) must keep every row
    above threshold regardless of the class column — plate models put their
    only class there and its value is meaningless to filter on."""
    pdet = openscrub.PersonDetector(thresh=0.5, expand=0.0, input_size=640)
    assert not pdet.available()          # no model resolved -> inert
    assert pdet.find(np.zeros((64, 64, 3), np.uint8)) == []   # fail closed
    s, w, h = 1.0, 640, 640

    # 6-col end2end (YOLOv10 layout): x1,y1,x2,y2,score,class — one person
    # (cls 0), one skateboard (cls 36) above threshold, one weak person
    out6 = np.array([[100, 50, 200, 90, 0.9, 0],
                     [300, 60, 400, 99, 0.8, 36],
                     [10, 10, 20, 20, 0.2, 0]], np.float32)
    r = pdet._decode(out6, s, w, h)
    assert len(r) == 1
    assert tuple(round(v) for v in r[0][:4]) == (100, 50, 200, 90)

    # 7-col end2end: batch,x1,y1,x2,y2,class,score — same class filtering
    out7 = np.array([[0, 100, 50, 200, 90, 0, 0.9],
                     [0, 300, 60, 400, 99, 2, 0.9]], np.float32)
    assert len(pdet._decode(out7, s, w, h)) == 1

    # PlateDetector ignores the class column entirely (single-class models)
    plat = openscrub.PlateDetector(thresh=0.5, expand=0.0, input_size=640)
    assert len(plat._decode(out6[:2], s, w, h)) == 2

    # raw multi-class YOLOv8 head (84, N): person score lives at row 4+0 —
    # identical channel to the single-class head, so plate decode is unchanged
    raw = np.zeros((84, 100), np.float32)
    raw[0, 3], raw[1, 3], raw[2, 3], raw[3, 3] = 320, 240, 100, 200   # cx,cy,w,h
    raw[4, 3] = 0.9                                   # person class channel
    r = pdet._decode(raw, s, w, h)
    assert len(r) == 1
    x1, y1, x2, y2 = (round(v) for v in r[0][:4])
    assert (x1, y1, x2, y2) == (270, 140, 370, 340)

    # registry: the person kind resolves to person_models.json with pinned
    # hashes (never TOFU for these — they were validated at authoring time)
    assert openscrub.model_registry_path("person").endswith("person_models.json")
    reg = openscrub.load_model_registry("person")
    assert reg and all(m.get("sha256") for m in reg)
    assert any(m.get("recommended") for m in reg)

    # the category alignment rule: person is in, mrn is retired from the
    # defaults (CLI-only via --categories mrn + --mrn-regex)
    parser = openscrub.build_parser()
    cats = parser.get_default("categories").split(",")
    assert "person" in cats and "mrn" not in cats and len(cats) == 14
    assert "qrcode" in cats and "screen" in cats


def test_person_silhouette_decode_and_render(tmp_path):
    """Segmentation path: YOLO-seg output pairs decode into silhouette
    polygons, blur_silhouette masks ONLY inside them (dilated by pad), and
    poly survives the report round trip. All pure — no model needed."""
    det = openscrub.PersonDetector(thresh=0.5, expand=0.0, input_size=640)

    # synthetic seg output: one person row whose box covers a known square;
    # proto channel 0 is strongly positive inside x[100:200), y[25:50) of the
    # 160x160 proto grid (=> x[400:800)->clipped, y[100:200) at 640 input)
    N = 200
    raw = np.zeros((116, N), np.float32)
    raw[0, 7], raw[1, 7] = 300, 150        # cx, cy
    raw[2, 7], raw[3, 7] = 300, 200        # w, h -> box x[150,450) y[50,250)
    raw[4, 7] = 0.9                        # person score
    raw[84, 7] = 1.0                       # coeff for proto channel 0
    proto = np.full((1, 32, 160, 160), -10.0, np.float32)
    proto[0, 0, 25:50, 50:100] = 10.0      # y[100:200) x[200:400) at 640
    rows = det._decode_seg(raw, proto, 1.0, 640, 640)
    assert len(rows) == 1
    x1, y1, x2, y2, conf, polys = rows[0]
    assert (round(x1), round(y1), round(x2), round(y2)) == (150, 50, 450, 250)
    assert polys and all(0.0 <= v <= 1.0 for p in polys for pt in p for v in pt)

    # non-person class rows must be ignored even with a strong score
    raw2 = raw.copy()
    raw2[4, 7] = 0.0
    raw2[7, 7] = 0.95                      # class 3 (car), not person
    assert det._decode_seg(raw2, proto, 1.0, 640, 640) == []

    # blur_silhouette: only pixels inside the polygon change
    frame = np.full((100, 100, 3), 200, np.uint8)
    sq = ((0.0, 0.0), (0.5, 0.0), (0.5, 1.0), (0.0, 1.0))   # left half of box
    openscrub.blur_silhouette(frame, 20, 20, 80, 80, "box", (sq,),
                              (20, 20, 80, 80), pad_px=0)
    assert frame[50, 30].tolist() == [0, 0, 0]        # inside poly: filled
    assert frame[50, 70].tolist() == [200, 200, 200]  # right half untouched
    assert frame[10, 10].tolist() == [200, 200, 200]  # outside box untouched

    # pad dilates the mask outward (fail closed)
    frame2 = np.full((100, 100, 3), 200, np.uint8)
    openscrub.blur_silhouette(frame2, 20, 20, 80, 80, "box", (sq,),
                              (20, 20, 80, 80), pad_px=6)
    assert frame2[50, 53].tolist() == [0, 0, 0]       # beyond 0.5 edge: padded

    # empty/degenerate polys fall back to the whole box, never to nothing
    frame3 = np.full((100, 100, 3), 200, np.uint8)
    openscrub.blur_silhouette(frame3, 20, 20, 80, 80, "box", (),
                              (20, 20, 80, 80))
    assert frame3[50, 70].tolist() == [0, 0, 0]

    # report round trip preserves poly
    d = openscrub.Detection(0.0, 1.0, (10, 10, 50, 50), "person", "person",
                            0.9, (0, 0), dense=True, track=0, poly=(sq,))
    args = openscrub.build_parser().parse_args(["dummy.mp4"])
    state = {"fps": 30.0, "cum": [(0.0, 0.0)], "bands": [(0.0, 0.0)],
             "detections": [d], "input_sha256": "x"}
    path = str(tmp_path / "r.json")
    openscrub.write_report(path, args, state)
    back, _, _ = openscrub.load_report(path)
    assert back and back[0].poly and len(back[0].poly[0]) == 4


def test_person_seg_forward_crash_degrades_to_boxes():
    """OpenCV DNN's layer fusion can assert AT INFERENCE TIME on multi-output
    (segmentation) graphs — 'biasLayerData->outputBlobsWrappers.size() == 1
    in fuseLayers' on the 4.10 CUDA build — which the load-time probe cannot
    catch and which used to kill the whole scan. A forward failure must
    degrade LOUDLY to box detection and keep the scan alive. (Seg models are
    also moved onto onnxruntime at load; this guards any remaining cv2 path.)"""
    class BoomNet:
        def getUnconnectedOutLayersNames(self):
            return ("output0", "output1")

        def setInput(self, b):
            pass

        def forward(self, names=None):
            if names is not None:
                raise cv2.error("biasLayerData->outputBlobsWrappers.size()"
                                " == 1 in function 'fuseLayers'")
            out = np.zeros((1, 116, 300), np.float32)
            out[0, 0, 5], out[0, 1, 5] = 320, 240
            out[0, 2, 5], out[0, 3, 5] = 100, 200
            out[0, 4, 5] = 0.9
            return out

    det = openscrub.PersonDetector(thresh=0.5)
    det.net, det.ort, det.seg = BoomNet(), None, True
    rows = det.find(np.zeros((480, 854, 3), np.uint8))
    assert det.seg is False, "must drop out of seg mode after the failure"
    assert len(rows) == 1 and len(rows[0]) == 5, \
        "box fallback must still return detections"


def test_dense_tracks_never_merge_cotemporal_objects():
    """Track association hardening (the boat-video bug): three people side
    by side collapsed into one track — enabling one review card blurred
    everyone. Two detections in the SAME frame are different physical
    objects and must NEVER share a track, and person-sized boxes need a
    tighter association radius than faces (1.6x a full-body box spans most
    of the frame)."""
    dets = []
    for f in range(10):
        t = f / 30.0
        for p in range(3):                    # 3 people, 220px apart
            x = 100 + p * 220 + f * 2
            dets.append(openscrub.Detection(t, t + 0.01,
                                            (x, 100, x + 200, 500),
                                            "person", "person", 0.9, (0, 0),
                                            dense=True))
    n = openscrub.assign_dense_tracks(dets)
    assert n == 3, "3 co-visible people must yield 3 tracks, got %d" % n
    per_track = {}
    for d in dets:
        per_track.setdefault(d.track, []).append(d)
    for samples in per_track.values():
        ts = [round(x.t_start, 3) for x in samples]
        assert len(set(ts)) == len(ts), \
            "a track absorbed two samples from the same frame"
        xs = {x.cbox[0] - i * 2 for i, x in
              enumerate(sorted(samples, key=lambda z: z.t_start))}
        assert len(xs) == 1, "a track jumped between different people"

    # faces benefit from the same cannot-link: two adjacent faces in the
    # same frame stay separate tracks
    fd = []
    for f in range(6):
        t = f / 30.0
        for p in range(2):
            x = 100 + p * 90
            fd.append(openscrub.Detection(t, t + 0.01, (x, 100, x + 60, 160),
                                          "face", "face", 0.9, (0, 0),
                                          dense=True))
    assert openscrub.assign_dense_tracks(fd) == 2


def test_prescan_tracked_object(tmp_path):
    """Scan Setup pre-scan object tracking: a box drawn ON an object (with
    the frame time it was drawn at) rides the --windows JSON as
    track:[[nx1,ny1,nx2,ny2,tref_frac]], and the scan template-tracks it
    through the window — dense "manual" samples on one track, following
    the object, blurred at render."""
    import numpy as _np
    src = str(tmp_path / "mv.mp4")
    W, H, fps = 320, 240, 30
    vw = cv2.VideoWriter(src, cv2.VideoWriter_fourcc(*"mp4v"), fps, (W, H))
    rng = _np.random.RandomState(7)
    patch = rng.randint(0, 255, (48, 48, 3), _np.uint8)   # high-texture object
    for i in range(90):                                    # 3 s
        fr = _np.full((H, W, 3), 30, _np.uint8)
        x = 20 + i * 2                                     # slides right
        fr[96:144, x:x + 48] = patch
        vw.write(fr)
    vw.release()

    # box drawn on the object at t=1.5s (fraction 0.5): x = 20+45*2 = 110
    wj = str(tmp_path / "w.json")
    with open(wj, "w", encoding="utf-8") as f:
        json.dump({"windows": [{
            "t0": 0.0, "t1": 1.0, "cats": [],
            "track": [[110 / W, 96 / H, 158 / W, 144 / H, 0.5]]}]}, f)
    parser = openscrub.build_parser()
    args = parser.parse_args(
        [src, "--categories", "none", "--windows", wj,
         "-o", str(tmp_path / "out.mp4"),
         "--report", str(tmp_path / "r.json")])
    args = openscrub._prep_args(args, parser)
    openscrub.run_pipeline(args, openscrub.Callbacks())

    doc = json.load(open(str(tmp_path / "r.json")))
    man = [d for d in doc["detections"] if d["category"] == "manual"]
    assert man, "tracked object must produce manual detections"
    assert {d["track"] for d in man} == {man[0]["track"]}, "one track id"
    assert len(man) > 20, "should follow the object across most frames"
    # the track must FOLLOW the moving object: early samples left of late
    man.sort(key=lambda d: d["t_start"])
    assert man[-1]["cbox"][0] - man[0]["cbox"][0] > 60, \
        "track must move with the object"
    # spot-check the render at t=2s: the object region must be SMOOTHED
    # (blur kills the random patch's local variance) and the background
    # stays untouched
    cap = cv2.VideoCapture(str(tmp_path / "out.mp4"))
    cap.set(cv2.CAP_PROP_POS_MSEC, 2000)
    ok, fr = cap.read()
    cap.release()
    assert ok
    x = 20 + 60 * 2                       # object x at frame 60 (t=2s)
    obj = fr[100:140, x + 6:x + 42]
    assert float(obj.std()) < float(patch.std()) * 0.6, \
        "tracked object region must be blurred at render time"
    assert fr[10, 10].astype(int).sum() < 120, "background stays untouched"


def test_fetch_model_verifies_and_fails_closed(tmp_path):
    """_fetch_model must reject pointer-sized files and hash mismatches
    (never trusting them as models), succeed on the authentic bytes, and
    leave no .part debris behind on failure."""
    good = tmp_path / "good.onnx"
    good.write_bytes(b"\x08\x01" * 10000)          # 20 KB "model"
    dest = str(tmp_path / "out.onnx")
    sha = openscrub._sha256_file(str(good))
    openscrub._fetch_model("file://" + str(good), dest, sha256=sha,
                           tries=1, delay=0)
    assert os.path.getsize(dest) == 20000

    # a Git-LFS pointer (~131 bytes) must never masquerade as a model
    ptr = tmp_path / "pointer.onnx"
    ptr.write_bytes(b"version https://git-lfs.github.com/spec/v1\n"
                    b"oid sha256:deadbeef\nsize 38696353\n")
    dest2 = str(tmp_path / "out2.onnx")
    with pytest.raises(Exception):
        openscrub._fetch_model("file://" + str(ptr), dest2, tries=2, delay=0)
    assert not os.path.exists(dest2) and not os.path.exists(dest2 + ".part")

    # wrong hash: rejected loudly even though the size looks plausible
    dest3 = str(tmp_path / "out3.onnx")
    with pytest.raises(Exception):
        openscrub._fetch_model("file://" + str(good), dest3,
                               sha256="0" * 64, tries=1, delay=0)
    assert not os.path.exists(dest3) and not os.path.exists(dest3 + ".part")


def test_track_fail_closed_hold(tmp_path, monkeypatch):
    """When the tracker loses an object mid-frame, coverage FREEZES in
    place and continues to the window edge instead of silently
    un-blurring the subject (real-footage regression: the blur followed
    a person for a while, then vanished entirely)."""
    path = str(tmp_path / "vanish.mp4")
    rng = np.random.default_rng(7)
    patch = rng.integers(0, 255, (60, 60, 3)).astype(np.uint8)
    out = cv2.VideoWriter(path, cv2.VideoWriter_fourcc(*"mp4v"), 30,
                          (640, 360))
    for i in range(180):                 # 6s: visible 3s, then GONE
        fr = np.full((360, 640, 3), 60, np.uint8)
        if i < 90:
            fr[150:210, 290:350] = patch
        out.write(fr)
    out.release()
    monkeypatch.setattr(openscrub, "_vittrack_factory", lambda log: None)
    s = openscrub.track_manual_region(path, (290, 150, 350, 210),
                                      1.0, 0.0, 6.0)
    assert s and max(x[0] for x in s) > 5.5, \
        "coverage must reach the window edge, not end at the loss"
    late = [x for x in s if x[0] > 4.0]
    assert late and all(x[2] == 0.0 for x in late), \
        "held samples must carry score 0 (visible in review)"
    for _, b, _ in late:                 # frozen where it last saw it
        assert abs(b[0] - 290) < 40 and abs(b[1] - 150) < 40


def test_track_person_detector_path(tmp_path):
    """A drawn box containing a person switches to detector-driven
    tracking: body-tight boxes + silhouettes that follow the SEEDED
    person and never jump to a decoy detection standing elsewhere."""
    v = _moving_square_video(str(tmp_path / "move.mp4"))
    SQ = (((0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0)),)

    class StubDet:
        def find(self, frame):
            g = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            ys, xs = np.where(g > 120)          # the moving "person"
            dets = [(500.0, 20.0, 560.0, 80.0, 0.9, SQ)]   # static decoy
            if len(xs):
                dets.append((float(xs.min()), float(ys.min()),
                             float(xs.max()), float(ys.max()), 0.95, SQ))
            return dets

    s = openscrub.track_manual_region(v, (218, 148, 282, 212), 2.0,
                                      1.0, 4.0, person_det=StubDet())
    assert s and len(s[0]) >= 4 and s[0][3], \
        "detector path must return silhouette-bearing samples"
    mid = min(s, key=lambda q: abs(q[0] - 3.0))  # true x at t=3.0 is 310
    assert abs(mid[1][0] - 310) < 20, "must follow the seeded person"
    for q in s:
        assert q[1][0] < 450, "must never jump to the decoy detection"


def test_render_dedupes_overlapping_dense_samples():
    """Manual-track samples carry a grace overlap, so every other frame
    was covered by TWO snapshots of the same track and got blurred twice
    — the output pulsed at half the frame rate (visible flicker on real
    footage). A frame must apply only the latest snapshot per track."""
    mk = lambda t: openscrub.Detection(t, t + 0.08, (10, 10, 50, 50),
                                       "manual", "x", 0.9, (0, 0),
                                       last_seen=t, dense=True, track=3)
    a, b = mk(0.0), mk(1 / 15)          # both cover frame t = 2/30
    act = [d for d in (a, b)
           if d.t_start - 0.01 <= 2 / 30 <= d.t_end + 0.01]
    assert len(act) == 2, "sanity: the overlap frame sees both snapshots"
    assert openscrub._dedupe_dense(act) == [b], \
        "only the latest snapshot may blur the frame"
    # non-dense detections (text regions etc.) are never deduped
    n1 = openscrub.Detection(0, 1, (0, 0, 5, 5), "name", "x", 0.9)
    n2 = openscrub.Detection(0, 1, (8, 8, 12, 12), "name", "y", 0.9)
    assert openscrub._dedupe_dense([n1, n2]) == [n1, n2]


def test_grab_frame_survives_broken_random_seek():
    """Some codec/build combos (h264_nvenc HDR copies in the CUDA image)
    fail POS_MSEC random-access seeks to deep timestamps, silently killing
    a tracking window's seed. _grab_frame must fall back to sequential
    decode (what the renderer always does) and return the CORRECT frame."""
    class BrokenSeekCap:
        def __init__(self, n):
            self.n = n; self.pos = 0; self.msec = False
        def set(self, prop, val):
            if prop == cv2.CAP_PROP_POS_MSEC:
                self.msec = True; return True
            if prop == cv2.CAP_PROP_POS_FRAMES:
                self.pos = int(val); self.msec = False; return True
            return False
        def read(self):
            if self.msec:                       # random seek → broken
                return (False, None)
            if self.pos >= self.n:
                return (False, None)
            fr = np.full((4, 4, 3), self.pos % 251, np.uint8)
            self.pos += 1
            return (True, fr)

    cap = BrokenSeekCap(816)
    fr = openscrub._grab_frame(cap, 19.9, 30.0)
    assert fr is not None, "must recover a frame via sequential fallback"
    assert int(fr[0, 0, 0]) == int(round(19.9 * 30.0)) % 251, \
        "fallback must return the frame at the requested time"

    # a totally dead capture returns None, never raises
    class DeadCap:
        def set(self, prop, val): return True
        def read(self): return (False, None)
    assert openscrub._grab_frame(DeadCap(), 5.0, 30.0) is None


def test_scan_copy_frame_verification(tmp_path):
    """A tone-mapped scan copy is read by frame INDEX, so a copy that
    dropped frames (a real GPU box's NVENC copy did) silently shifts
    every detection onto the wrong output frames. The verifier must
    count frames exactly and flag any mismatch beyond the tolerance."""
    import subprocess
    src = str(tmp_path / "src.mp4")
    short = str(tmp_path / "short.mp4")
    subprocess.run(["ffmpeg", "-loglevel", "error", "-f", "lavfi",
                    "-i", "testsrc=size=64x64:rate=30:duration=2",
                    "-pix_fmt", "yuv420p", src], check=True)
    subprocess.run(["ffmpeg", "-loglevel", "error", "-i", src,
                    "-frames:v", "50", "-pix_fmt", "yuv420p", short],
                   check=True)
    assert openscrub._count_video_frames(src) == 60
    assert openscrub._count_video_frames(short) == 50

    ok, n_ref, n_cp = openscrub._scan_copy_matches(src, src)
    assert ok and n_ref == n_cp == 60
    ok, n_ref, n_cp = openscrub._scan_copy_matches(src, short)
    assert not ok, "a 10-frame-short copy must be rejected"
    # unmeasurable inputs never block the pipeline (fail open here would
    # mean refusing every scan on a box without ffprobe — the guard only
    # acts on a MEASURED mismatch)
    ok, _, _ = openscrub._scan_copy_matches(src, str(tmp_path / "nope.mp4"))
    assert ok


def test_grab_frame_repairs_keyframe_snapped_seek():
    """A real box's OpenCV landed a 20.3s seek at an earlier keyframe and
    the read SUCCEEDED — the tracker then followed the wrong moment of
    the video with full confidence (samples 16s off; the blur 'flew
    away'). _grab_frame must detect the wrong landing via the decoded
    packet's PTS and walk forward to the exact requested frame."""
    class SnapCap:
        GOP = 250
        def __init__(self, n):
            self.n = n; self.pos = 0
        def set(self, prop, val):
            if prop == cv2.CAP_PROP_POS_MSEC:
                want = int(round(val / 1000.0 * 30.0))
            elif prop == cv2.CAP_PROP_POS_FRAMES:
                want = int(val)
            else:
                return False
            self.pos = (min(max(want, 0), self.n - 1) // self.GOP) * self.GOP
            return True
        def get(self, prop):
            if prop == cv2.CAP_PROP_POS_MSEC:
                return self.pos / 30.0 * 1000.0      # next frame's PTS
            if prop == cv2.CAP_PROP_FPS:
                return 30.0
            return 0.0
        def read(self):
            if self.pos >= self.n:
                return (False, None)
            fr = np.full((4, 4, 3), self.pos % 251, np.uint8)
            self.pos += 1
            return (True, fr)

    cap = SnapCap(816)
    fr = openscrub._grab_frame(cap, 20.3, 30.0)
    assert fr is not None
    assert int(fr[0, 0, 0]) == int(round(20.3 * 30.0)) % 251, \
        "must repair a keyframe-snapped landing to the exact frame"

    # _seek_cap must leave the NEXT read at the requested index (this is
    # what the scan's fast-skip and the trimmed render rely on)
    cap = SnapCap(816)
    assert openscrub._seek_cap(cap, 609, 30.0)
    ok, fr = cap.read()
    assert ok and int(fr[0, 0, 0]) == 609 % 251


def test_track_dormant_reacquisition(tmp_path):
    """A subject hidden longer than the 0.8s grace no longer ends the
    track: it goes DORMANT (no samples — nothing visible to blur) and
    re-acquires the SAME object when it reappears. A look-alike that
    stayed visible while ours was hidden (a bystander) must never
    inherit the track — the cannot-link rule."""
    # video with the frame index encoded in a top strip so the stub
    # detector derives time from the FRAME, not from call count
    path = str(tmp_path / "hide.mp4")
    w = cv2.VideoWriter(path, cv2.VideoWriter_fourcc(*"mp4v"), 30,
                        (640, 360))
    rng = np.random.default_rng(7)
    bg = rng.integers(0, 60, (360, 640, 3), np.uint8)
    for i in range(240):
        fr = bg.copy()
        fr[0:12, :, :] = i
        w.write(fr)
    w.release()
    SQ = (((0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0)),)

    class StubDet:
        def find(self, frame):
            t = float(np.median(frame[2:10, :, 0])) / 30.0
            dets = [(500.0, 20.0, 560.0, 80.0, 0.9, SQ)]  # bystander
            if not 3.0 <= t <= 5.0:                 # hidden for 2s
                x = 100.0 + t * 30.0
                dets.append((x, 150.0, x + 60.0, 210.0, 0.95, SQ))
            return dets

    s = openscrub._track_person_dense(path, (100, 148, 200, 212), 1.0,
                                      1.0, 7.5, StubDet(),
                                      lambda m: None, step_frames=1)
    assert s, "track must produce samples"
    # 3.0-3.8s is the freeze grace (box held, by design); after it the
    # track must go dormant and paint NOTHING while the subject is gone
    gap = [q for q in s if 4.0 <= q[0] <= 4.8]
    assert not gap, "no blur may be painted while the subject is hidden"
    late = [q for q in s if q[0] >= 5.6]
    assert late, "coverage must RESUME when the subject reappears"
    for q in late:
        assert q[1][0] > 200, "must re-acquire the subject, not freeze"
        assert q[1][0] < 450, "the bystander must never inherit the track"


def test_track_person_lookalike_veto(tmp_path):
    """A PERSON track must not be stolen by a differently-dressed
    look-alike who crosses in front — the exact reported failure (a
    tracked child in blue, a child in a pink two-piece walked past, and
    the blur jumped to the wrong child). The torso-band clothing
    histogram is the identity cue: the seeded subject is BLUE, the
    look-alike RED, and the look-alike overlaps the subject's frozen box
    with high IoU while the subject is briefly occluded — geometry alone
    would grab it, so only the appearance veto keeps the track honest.
    The veto is PERSON-ONLY, so a re-render on an animal is unaffected
    (test_track_dormant_reacquisition covers the geometry-only path)."""
    path = str(tmp_path / "cross.mp4")
    w = cv2.VideoWriter(path, cv2.VideoWriter_fourcc(*"mp4v"), 30,
                        (640, 360))
    rng = np.random.default_rng(3)
    bg = rng.integers(0, 40, (360, 360, 3), np.uint8)  # dark, low-sat
    SQ = (((0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0)),)
    BLUE = (255, 0, 0)          # BGR — the seeded subject's clothing
    RED = (0, 0, 255)           # BGR — the look-alike's clothing

    def xB(t):                  # look-alike sweeps right -> left
        return int(260 - 137.5 * (t - 2.0))

    for i in range(240):
        t = i / 30.0
        fr = np.zeros((360, 640, 3), np.uint8)
        fr[:, :360] = bg
        fr[0:12, :, :] = i      # frame-index strip -> stub derives time
        if not 2.5 <= t <= 3.1:                 # subject hidden 0.6s
            cv2.rectangle(fr, (150, 150), (210, 310), BLUE, -1)
        if 2.0 <= t <= 3.6:                     # look-alike crossing
            x = xB(t)
            cv2.rectangle(fr, (x, 150), (x + 60, 310), RED, -1)
        w.write(fr)
    w.release()

    class StubDet:
        def find(self, frame):
            t = float(np.median(frame[2:10, 20, 0])) / 30.0
            dets = []
            if not 2.5 <= t <= 3.1:
                dets.append((150.0, 150.0, 210.0, 310.0, 0.95, SQ))
            if 2.0 <= t <= 3.6:
                x = float(xB(t))
                dets.append((x, 150.0, x + 60.0, 310.0, 0.92, SQ))
            return dets

    logs = []
    s = openscrub._track_person_dense(path, (150, 148, 210, 312), 1.0,
                                      1.0, 5.0, StubDet(),
                                      logs.append, step_frames=1)
    assert s, "track must produce samples"
    # the veto must actually FIRE at the crossing (proves the mechanism,
    # not just that geometry happened to hold)
    assert any("rejected a look-alike" in m for m in logs), \
        "the appearance veto should reject the crossing look-alike"
    # the look-alike exits to the far left (x -> ~40); the track must
    # NEVER follow it there
    for q in s:
        if q[0] >= 2.5:
            cx = (q[1][0] + q[1][2]) / 2.0
            assert cx > 110, (
                "the track followed the look-alike left to x=%.0f at "
                "t=%.2fs — identity was stolen" % (cx, q[0]))
    # and coverage must RESUME on the real (blue) subject after it
    # reappears at x~150
    back = [q for q in s if q[0] >= 3.3
            and 140 <= (q[1][0] + q[1][2]) / 2.0 <= 220 and q[2] > 0.05]
    assert back, "coverage must resume on the real subject after the pass"


def test_track_person_size_jump_handoff(tmp_path):
    """A LARGER foreground look-alike whose box ENGULFS the small tracked
    person must not steal the track — the reported end-of-clip swap. The
    real failure: a pink-suited child stepped in front, her detection was
    2.67x the tracked box in ONE frame (IoU 0.37), and her skin-heavy
    torso scraped PAST the 0.65 appearance veto at 0.71, so appearance
    alone let her through. The size-jump guard is the backstop — a jump
    that big needs a same-PERSON-grade match (>= 0.80), which the
    look-alike fails. Here the look-alike's torso is tuned to correlate
    ~0.70 with the subject: enough to pass the base veto, not the 0.80
    gate, so this test FAILS if the size guard is removed."""
    path = str(tmp_path / "engulf.mp4")
    w = cv2.VideoWriter(path, cv2.VideoWriter_fourcc(*"mp4v"), 30,
                        (640, 360))
    SQ = (((0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0)),)
    BLUE = (255, 0, 0)
    RED = (0, 0, 255)
    A = (300, 200, 360, 320)                # small subject (60x120)
    B = (280, 160, 380, 355)                # engulfing look-alike (2.7x)

    def paint_lookalike(fr):
        cv2.rectangle(fr, (B[0], B[1]), (B[2], B[3]), BLUE, -1)
        h = B[3] - B[1]
        b0, b1 = int(B[1] + 0.15 * h), int(B[1] + 0.55 * h)
        # lower half of the torso band red -> torso hist ~0.70 vs the
        # all-blue subject (passes 0.65, fails 0.80)
        cv2.rectangle(fr, (B[0], int(b0 + 0.5 * (b1 - b0))),
                      (B[2], b1), RED, -1)

    for i in range(150):
        t = i / 30.0
        fr = np.zeros((360, 640, 3), np.uint8)
        fr[0:12, :, :] = i
        if 2.5 <= t <= 4.0:                 # look-alike present late
            paint_lookalike(fr)
        if t < 2.9:                         # subject visible, then hidden
            cv2.rectangle(fr, (A[0], A[1]), (A[2], A[3]), BLUE, -1)
        w.write(fr)
    w.release()

    class StubDet:
        def find(self, frame):
            t = float(np.median(frame[2:10, 20, 0])) / 30.0
            dets = []
            if t < 2.9:
                dets.append((float(A[0]), float(A[1]), float(A[2]),
                             float(A[3]), 0.95, SQ))
            if 2.5 <= t <= 4.0:
                dets.append((float(B[0]), float(B[1]), float(B[2]),
                             float(B[3]), 0.95, SQ))
            return dets

    logs = []
    s = openscrub._track_person_dense(path, A, 1.0, 1.0, 4.5,
                                      StubDet(), logs.append,
                                      step_frames=1)
    assert s, "track must produce samples"
    assert any(q[0] >= 3.0 for q in s), \
        "track must retain post-occlusion samples"
    a_area = (A[2] - A[0]) * (A[3] - A[1])
    b_area = (B[2] - B[0]) * (B[3] - B[1])
    # once the subject is hidden the track must FREEZE near the subject's
    # box, never adopt the 2.7x look-alike box
    for q in s:
        if q[0] >= 3.0:
            area = (q[1][2] - q[1][0]) * (q[1][3] - q[1][1])
            assert area < 0.5 * (a_area + b_area), (
                "track grew to the look-alike's box (area=%.0f) at "
                "t=%.2fs — the larger person was grabbed" % (area, q[0]))


def test_encoder_ladder_prefers_nvenc_then_qsv(monkeypatch):
    """The encoder pick is a pre-flight-tested ladder: NVENC first, QSV
    (the :intel image) second, libx264 as the CPU floor. Every GPU rung
    must pass a real test encode before being trusted."""
    class R:
        def __init__(self, out="", rc=0):
            self.stdout, self.stderr, self.returncode = out, "", rc

    def fake_run(cmd, **kw):
        if "-encoders" in cmd:
            return R(out="h264_qsv hevc_qsv libx264 libx265")
        return R(rc=0)          # every test encode succeeds

    logs = []
    class CB:
        def log(self, m): logs.append(m)

    monkeypatch.setattr(openscrub.subprocess, "run", fake_run)
    monkeypatch.setattr(openscrub.shutil, "which", lambda n: "/usr/bin/" + n)
    # no NVENC in the build -> QSV wins on auto
    assert openscrub.nvenc_available("auto", CB()) == "h264_qsv"
    # explicit CPU preference skips the GPU entirely
    assert openscrub.nvenc_available("x264", CB()) == "libx264"
    # nvenc preference with no nvenc present -> CPU, with a loud note
    assert openscrub.nvenc_available("nvenc", CB()) == "libx264"
    assert any("no GPU encoder" in m for m in logs)

    # a QSV rung that FAILS its test encode must fall through to CPU
    def fake_run_fail(cmd, **kw):
        if "-encoders" in cmd:
            return R(out="h264_qsv libx264")
        return R(rc=1)
    monkeypatch.setattr(openscrub.subprocess, "run", fake_run_fail)
    assert openscrub.nvenc_available("auto", CB()) == "libx264"

    # 10-bit HEVC ladder honours the qsv preference and caches per-order
    openscrub._HEVC10.clear()
    monkeypatch.setattr(openscrub.subprocess, "run", fake_run)
    assert openscrub.hevc10_encoder("qsv", CB()) == "hevc_qsv"
    openscrub._HEVC10.clear()


def test_coverage_levels_box_and_concealed():
    """'tight' keeps silhouettes; 'box' drops them (full-box blur hides
    body shape); 'concealed' additionally replaces each track's box with
    the padded union of its ±0.6s neighbours so the cover glides instead
    of bobbing — gait recognizers consume exactly the silhouette
    sequences 'tight' produces, so witness-grade jobs must be able to
    destroy that signal. Originals must stay untouched (the report keeps
    tight samples so a re-render can change coverage)."""
    SQ = (((0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0)),)
    dets = []
    for i in range(10):
        t = i / 10.0
        x = 100 + i * 20                     # walking right, box bobbing
        y = 100 + (10 if i % 2 else 0)
        dets.append(openscrub.Detection(
            t, t + 0.08, (x, y, x + 60, y + 160), "person", "p", 0.9,
            (0, 0), last_seen=t, dense=True, track=5, poly=SQ))
    txt = openscrub.Detection(0, 1, (5, 5, 50, 20), "name", "x", 0.9)
    dets.append(txt)

    tight = openscrub.apply_coverage(dets, "tight")
    assert tight is dets, "tight must be a no-op"

    boxed = openscrub.apply_coverage(dets, "box")
    assert all(not d.poly for d in boxed if d.category == "person")
    assert dets[0].poly, "originals must keep their silhouettes"
    assert boxed[0].cbox == dets[0].cbox, "box mode keeps positions"

    conc = openscrub.apply_coverage(dets, "concealed")
    person = [d for d in conc if d.category == "person"]
    assert all(not d.poly for d in person)
    # each concealed box must contain every neighbour box within 0.6s
    for i, d in enumerate(person):
        for j, e in enumerate(dets[:10]):
            if abs(e.t_start - d.t_start) <= 0.6:
                assert (d.cbox[0] <= e.cbox[0] and d.cbox[1] <= e.cbox[1]
                        and d.cbox[2] >= e.cbox[2]
                        and d.cbox[3] >= e.cbox[3]), \
                    "concealed box must cover all ±0.6s neighbours"
    # the vertical bob (10px) must vanish: consecutive concealed boxes
    # share the same top edge through the middle of the track
    tops = {d.cbox[1] for d in person[3:7]}
    assert len(tops) == 1, "concealed cover must glide, not bob"
    # non-dense text detections pass through untouched
    assert any(d is txt for d in conc)


def test_render_strips_source_metadata(tmp_path):
    """A redacted file must not carry the source's GPS position, capture
    time, or device identifiers — the render strips ALL container and
    stream metadata (only explicit color signalling survives on HDR)."""
    import subprocess
    src = str(tmp_path / "meta.mp4")
    subprocess.run(["ffmpeg", "-loglevel", "error", "-f", "lavfi",
                    "-i", "testsrc=size=128x128:rate=30:duration=1",
                    "-pix_fmt", "yuv420p",
                    "-metadata", "creation_time=2026-01-02T03:04:05Z",
                    "-metadata", "location=+37.7749-122.4194/",
                    "-metadata", "com.apple.quicktime.location.ISO6709="
                                 "+37.7749-122.4194/",
                    "-metadata", "make=TestCam", src], check=True)
    probe = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format_tags",
         "-of", "json", src], capture_output=True, text=True).stdout
    assert "37.7749" in probe or "TestCam" in probe, \
        "sanity: the source must actually carry metadata"

    dst = str(tmp_path / "out.mp4")
    openscrub.render(src, dst, [], [(0.0, 0.0)] * 30, [(0.0, 0.0)] * 30,
                     30.0, pad=8, mode="blur", preview=False,
                     encoder="x264")
    assert os.path.exists(dst)
    out = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries",
         "format_tags:stream_tags", "-of", "json", dst],
        capture_output=True, text=True).stdout
    for leak in ("37.7749", "TestCam", "2026-01-02"):
        assert leak not in out, f"metadata leaked into the output: {leak}"


def test_qrcode_detection_and_category():
    """A QR code in frame can encode URLs/credentials — the qrcode
    category detects the REGION (never decodes the payload) and it must
    be found on a clean synthetic frame."""
    try:
        import qrcode as qrlib                     # test-only dependency
        img = np.array(qrlib.make("https://example.com/secret").convert(
            "RGB"))[:, :, ::-1]
    except ImportError:
        # build a QR with OpenCV's own encoder if the lib is absent
        enc = cv2.QRCodeEncoder.create()
        img = enc.encode("https://example.com/secret")
        img = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
    qr = cv2.resize(img, (240, 240), interpolation=cv2.INTER_NEAREST)
    frame = np.full((720, 1280, 3), 200, np.uint8)
    frame[100:340, 400:640] = qr

    det = openscrub.QRDetector()
    found = det.find(frame)
    assert found, "must detect the QR region"
    x1, y1, x2, y2 = found[0][:4]
    assert x1 < 640 and x2 > 400 and y1 < 340 and y2 > 100, \
        "detection must overlap the QR placement"
    # category wiring: qrcode is a default, immediate, non-text category
    assert "qrcode" in openscrub.PhiMemory.IMMEDIATE


def test_person_detector_find_classes_filter():
    """find_classes must return only the requested COCO classes (the
    'screen' category = tv/laptop/phone from the same person model) and
    restore the detector's person-only mode afterwards."""
    class Stub(openscrub.PersonDetector):
        def __init__(self):                 # no model load
            self.want_any = False
            self.seg = False
        def find(self, frame, scale=1.0):
            assert self.want_any, "find_classes must decode every class"
            return [(0, 0, 10, 10, 0.9, (), 62),      # tv
                    (20, 0, 30, 10, 0.9, (), 0),      # person
                    (40, 0, 50, 10, 0.8, (), 67)]     # cell phone
    s = Stub()
    rows = s.find_classes(None)
    assert len(rows) == 2 and all(len(r) == 6 for r in rows)
    assert s.want_any is False, "person-only mode must be restored"


def test_inpaint_mode_and_mosaic_floor():
    """'inpaint' reconstructs the region from its surroundings — the
    output must retain nothing of the original content (unlike blur,
    it cannot be attacked with deconvolution). Mosaic tiles now floor
    at 6px: 2px tiles barely pixelate and are the depixelation
    attack's favourite input."""
    rng = np.random.default_rng(3)
    frame = np.full((240, 320, 3), 90, np.uint8)
    frame += rng.integers(0, 12, frame.shape, np.uint8)   # textured bg
    secret = rng.integers(0, 255, (60, 100, 3), np.uint8)
    frame[90:150, 110:210] = secret
    before = frame[90:150, 110:210].copy()
    openscrub.blur_region(frame, 110, 90, 210, 150, "inpaint")
    after = frame[90:150, 110:210]
    diff = float(np.abs(after.astype(int) - before.astype(int)).mean())
    assert diff > 30, "inpaint must replace the content entirely"
    corr = float(np.corrcoef(after.mean(2).ravel(),
                             before.mean(2).ravel())[0, 1])
    assert abs(corr) < 0.35, "no structural trace of the original"

    # 10-bit planar path accepts inpaint too (HDR)
    y = np.full((64, 64), 512, np.uint16)
    y[20:40, 20:40] = rng.integers(0, 1023, (20, 20)).astype(np.uint16)
    u = np.full((32, 32), 512, np.uint16)
    v = np.full((32, 32), 512, np.uint16)
    openscrub._blur_yuv10(y, u, v, 20, 20, 40, 40, "inpaint")
    assert int(y[30, 30]) != int(rng.integers(0, 1023))  # smoke: no crash
    assert y.dtype == np.uint16

    # mosaic floor: a small region must still get >=6px tiles
    small = np.zeros((20, 28, 3), np.uint8)
    small[:, ::2] = 255                        # 1px stripes
    f2 = small.copy()
    openscrub.blur_region(f2, 0, 0, 28, 20, "mosaic")
    cols = f2[10, :, 0].astype(int)
    runs = sum(1 for i in range(1, 28) if cols[i] != cols[i - 1])
    assert runs <= 6, "6px+ tiles must destroy 1px stripes"


def test_head_box_from_person_detection():
    """--face-heads derives a head region from person detections so a
    TURNED head (invisible to face detectors) is still covered. With a
    silhouette the head comes from the contour's top; without one, from
    the top-centre of the box."""
    # silhouette: a person whose head is offset to the right of the box
    poly = ((( .55, .00), (.75, .00), (.75, .18), (.62, .30),
             (.20, .35), (.10, 1.0), (.90, 1.0), (.80, .40)),)
    hb = openscrub._head_box((100, 100, 300, 500, 0.9, poly))
    assert hb is not None
    hx1, hy1, hx2, hy2 = hb
    assert hx1 >= 100 + 0.15 * 200, "head bbox must follow the contour"
    assert hy1 <= 102 and hy2 < 350
    # box-only fallback: top-centre slice
    hb2 = openscrub._head_box((100, 100, 300, 500, 0.9))
    assert hb2 == (100 + .22 * 200, 100, 300 - .22 * 200, 100 + .24 * 400)
    # degenerate input
    assert openscrub._head_box((0, 0, 8, 10, 0.9)) is None


def test_tiled_find_adds_small_detections():
    """On high-res frames, tiling runs the detector on overlapping
    slices in ADDITION to the full frame: boxes come back offset to
    frame coordinates, tails (poly/cls) survive, duplicates NMS-merge,
    and a low ratio or mode 'off' skips slicing entirely."""
    frame = np.zeros((2160, 3840, 3), np.uint8)
    calls = []

    def find(img):
        calls.append(img.shape[:2])
        if img.shape[0] == 2160:                 # full frame: sees nothing
            return []
        # each tile call "detects" a tiny object at tile-local (10,10)
        return [(10.0, 10.0, 40.0, 40.0, 0.9, ((0.1, 0.1),), 7)]

    rows = openscrub._maybe_tiled(find, frame, 640, "auto")
    assert len(calls) >= 5, "full frame + a tile grid must run"
    assert rows, "tile detections must surface"
    assert any(r[0] > 1000 for r in rows), \
        "tile boxes must be offset back to frame coordinates"
    assert rows[0][5] == ((0.1, 0.1),) and rows[0][6] == 7, \
        "row tails (poly, cls) must survive tiling"

    calls.clear()
    small = np.zeros((720, 1280, 3), np.uint8)
    openscrub._maybe_tiled(find, small, 640, "auto")
    assert calls == [(720, 1280)], "low ratio must skip slicing"
    calls.clear()
    openscrub._maybe_tiled(find, frame, 640, "off")
    assert calls == [(2160, 3840)], "mode off must skip slicing"


def test_decode_db_text_regions():
    """Pure DB decode: contours on the thresholded probability map,
    scored by mean probability, unclipped outward (DB trains on shrunk
    kernels — the pad restores full glyph coverage)."""
    prob = np.zeros((96, 160), np.float32)
    prob[20:28, 10:60] = 0.9              # a confident text line
    prob[60:64, 100:120] = 0.35           # low-score noise blob
    out = openscrub._decode_db(prob, w=1600, h=960, nw=160, nh=96)
    assert len(out) == 1, "low-score blobs must be rejected"
    x1, y1, x2, y2, sc = out[0]
    assert sc > 0.85
    assert x1 < 100 and x2 > 600, "box must scale to frame coords"
    assert y1 < 200 and y2 > 280, "unclip pad must expand the region"


def test_ctc_greedy_decode():
    """PP-OCR recognizer CTC decode (the correctness-critical step of the
    ONNX OCR engine): collapse consecutive repeats, drop blank (index 0),
    map through the charmap, average confidence. A wrong index map or a
    missed repeat-collapse turns recognized text into garbage."""
    charmap = ["", "A", "B", "C", " "]        # 0=blank, 4=space
    def step(i, n=5, p=0.9):
        # off-target mass stays at 0.001 — the measured within-word
        # ceiling of the real model. Spreading (1-p) evenly put 0.025 on
        # the space class at every step, which no real frame does, and
        # tripped the space-recovery threshold (a fixture bug, not an
        # engine bug).
        v = np.full(n, 0.001)
        v[i] = p
        return v
    # A A blank B  -> "AB": the repeated A collapses, the blank drops
    logits = np.array([step(1), step(1), step(0), step(2)])
    txt, conf = openscrub._ctc_greedy_decode(logits, charmap)
    assert txt == "AB", txt
    assert conf > 0.85
    # space is its own class (index 4) and must render as ' '
    logits2 = np.array([step(1), step(4), step(3)])
    assert openscrub._ctc_greedy_decode(logits2, charmap)[0] == "A C"
    # all-blank -> empty string, zero confidence (no false text)
    assert openscrub._ctc_greedy_decode(
        np.array([step(0), step(0)]), charmap) == ("", 0.0)


def test_gauss_big_fast_path_stays_strong():
    """_gauss_big's large-kernel fast path (downscale -> small blur ->
    upscale) must destroy essentially all recoverable detail, like the
    direct giant-kernel blur it replaces — the 4K render-speed fix must
    never weaken redaction. Also pins dtype/shape for the 10-bit HDR
    planes."""
    rng = np.random.default_rng(7)
    roi = rng.integers(0, 255, (1900, 1300, 3)).astype(np.uint8)
    k = 433                       # real 4K tracked-person kernel size
    direct = cv2.GaussianBlur(roi, (k, k), 0)
    fast = openscrub._gauss_big(roi, k)

    def detail(img):
        g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        return cv2.Laplacian(g, cv2.CV_64F).var()

    orig = detail(roi)
    assert detail(fast) < orig * 0.001, "fast path left recoverable detail"
    assert detail(fast) < detail(direct) * 5 + 1.0   # same class of blur
    assert fast.shape == roi.shape and fast.dtype == roi.dtype
    # small kernels take the direct path unchanged
    small = openscrub._gauss_big(roi[:100, :100], 31)
    assert np.array_equal(small, cv2.GaussianBlur(roi[:100, :100],
                                                  (31, 31), 0))
    # 10-bit single-channel plane (HDR path): dtype and shape survive
    p10 = rng.integers(64, 940, (500, 400)).astype(np.uint16)
    out10 = openscrub._gauss_big(p10, 133)
    assert out10.dtype == np.uint16 and out10.shape == p10.shape


def test_docker_prefetch_matches_engine_pins():
    """docker/prefetch_models.py bakes models into the Docker images from
    its OWN (url, sha256, filename) table — standalone by design, so the
    prefetch layer caches across releases instead of re-downloading ~60MB
    per version. That table must stay byte-identical to the engine's
    pinned constants, or the images would ship a model the engine
    re-downloads (or worse, one that fails its hash check at runtime)."""
    import importlib.util
    spec = importlib.util.spec_from_file_location(
        "prefetch_models",
        os.path.join(os.path.dirname(os.path.abspath(__file__)),
                     "docker", "prefetch_models.py"))
    pf = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(pf)
    expect = {
        "yunet": (openscrub.YUNET_URL, openscrub.YUNET_SHA256,
                  "face_detection_yunet_2023mar.onnx"),
        "sface": (openscrub.SFACE_URL, openscrub.SFACE_SHA256,
                  "face_recognition_sface_2021dec.onnx"),
        "vittrack": (openscrub.VITTRACK_URL, openscrub.VITTRACK_SHA256,
                     "object_tracking_vittrack_2023sep.onnx"),
        "ppdet": (openscrub.PPDET_URL, openscrub.PPDET_SHA256,
                  "text_detection_ppocrv5_mobile.onnx"),
        "pprec": (openscrub.PPREC_URL, openscrub.PPREC_SHA256,
                  "text_recognition_ppocrv5_mobile.onnx"),
        "pprec_yml": (openscrub.PPREC_YML_URL, openscrub.PPREC_YML_SHA256,
                      "text_recognition_ppocrv5_mobile.yml"),
    }
    # the baked plate model (issue #18) is pinned to the RECOMMENDED
    # plate_models.json entry instead of an engine constant: url + sha256
    # must match the registry, the filename must be the registry id (how
    # PlateDetector.resolve_model finds it in the cache), and the entry
    # must stay permissively licensed with a REAL pin (unattended
    # fetch/bake must never ride on TOFU or a restrictive license).
    rec = next(m for m in openscrub.load_model_registry("plate")
               if m.get("recommended"))
    assert rec.get("sha256"), "recommended plate model must be hash-pinned"
    assert str(rec.get("license", "")).lower().startswith(
        ("mit", "apache", "bsd"))
    expect["plate_t640"] = (rec["download_url"], rec["sha256"],
                            "%s.onnx" % rec["id"])
    assert pf.MODELS == expect


def test_ocr_space_recovery_and_ascii_forms():
    """Two PP-OCRv5 quirks that silently broke PII detection on the
    ONNX OCR backend — the DEFAULT on CPU/Intel/Windows since 1.0.69 —
    found by the benchmark harness:

    1. The space class routinely loses the argmax to blank at real word
       gaps, welding "SSN 123-45-6789" into "SSN123-45-6789" and
       "4210 Kestrel Hollow Road" into one token, so every multi-token
       regex (address/phone/ssn) stopped matching. The space signal is
       still present in the blank run and must be recovered.
    2. Its Chinese-first vocabulary returns FULL-WIDTH punctuation:
       "（555）013-8842" matches no phone pattern even though it is
       visually identical to the ASCII form."""
    # --- full-width normalization
    assert openscrub._ascii_forms("（555）013-8842") == "(555)013-8842"
    assert openscrub._ascii_forms("１２３－４５－６７８９") == "123-45-6789"
    assert openscrub._ascii_forms("already ascii 1-2") == "already ascii 1-2"

    # --- space recovery: charmap[-1] is the space class
    charmap = [""] + list("AB") + [" "]          # blank, A, B, space
    SP = len(charmap) - 1
    n = len(charmap)

    def step(i, space_p=0.0):
        v = np.full(n, 0.001, np.float32)
        v[i] = 1.0 - space_p
        v[SP] = max(v[SP], space_p)
        return v

    # "A" <blank run carrying space probability> "B"  ->  "A B"
    hi = np.array([step(1), step(0, 0.4), step(0, 0.4), step(2)])
    assert openscrub._ctc_greedy_decode(hi, charmap)[0] == "A B"
    # same shape, but the blank run has NO space probability -> "AB"
    lo = np.array([step(1), step(0), step(0), step(2)])
    assert openscrub._ctc_greedy_decode(lo, charmap)[0] == "AB"
    # a ONE-step gap still carries a space when its space probability is
    # clear — tight det crops compress real word gaps to single steps
    # (space_p stays below blank's argmax share, the case this exists for)
    short = np.array([step(1), step(0, 0.4), step(2)])
    assert openscrub._ctc_greedy_decode(short, charmap)[0] == "A B"
    # ...but a one-step gap with a flat space signal is not a word break
    short_lo = np.array([step(1), step(0, 0.001), step(2)])
    assert openscrub._ctc_greedy_decode(short_lo, charmap)[0] == "AB"
    # no leading space, and repeats still collapse
    lead = np.array([step(0, 0.4), step(0, 0.4), step(1), step(1)])
    assert openscrub._ctc_greedy_decode(lead, charmap)[0] == "A"
    # with_pos: timesteps come back aligned with the emitted characters
    txt, conf, pos = openscrub._ctc_greedy_decode(hi, charmap, with_pos=True)
    assert txt == "A B" and pos == [0, 1, 3]


def test_merge_tail_extends_through_supporting_scans():
    """A span ends `hold` after its last full detection, but heavily
    compressed footage keeps showing the string while OCR reads only
    fragments — the benchmark's compressed card was exposed for its last
    0.7s exactly this way. Scans whose region words fuzzy-match the span
    text extend coverage; a scan reading different text stops the walk."""
    from rapidfuzz import fuzz
    def mk():
        return openscrub.Detection(t_start=0.0, t_end=0.0,
                                   cbox=(100, 100, 300, 120),
                                   category="card", text="4111111111111111",
                                   confidence=0.9)
    frag = lambda t, txt: (t, 0.0, [(txt, (110, 102, 220, 118), 0.9)])
    scans = [frag(1.0, "4111."), frag(2.0, "1111-1111"),
             frag(3.0, "TOTALLY DIFFERENT")]
    m = openscrub.merge_detections([mk()], hold=0.8, scans=scans,
                                   fuzz=fuzz)[0]
    assert m.t_end == pytest.approx(2.8), m.t_end   # 2.0 + hold, stopped at 3.0
    # no supporting scans -> tail stays at plain hold
    m = openscrub.merge_detections([mk()], hold=0.8,
                                   scans=[frag(1.0, "UNRELATED")],
                                   fuzz=fuzz)[0]
    assert m.t_end == pytest.approx(0.8), m.t_end


def test_face_detector_edge_assist_geometry():
    """Detection runs on a mirror-padded frame so a face clipped by the
    frame border (half out of frame — undetectable to every backend on
    real benchmark footage) is completed by its own reflection. Boxes
    map back by subtracting the pad; a detection living mostly IN the
    pad is a mirror phantom of an interior face and must be dropped."""
    class CB(openscrub.Callbacks):
        def log(self, msg):
            pass
    fd = openscrub.FaceDetector(CB())
    frame = np.full((400, 600, 3), 90, np.uint8)
    pad = fd._edge_pad(600, 400)

    class _Stub:
        def __init__(self, faces):
            self.faces = faces
        def setInputSize(self, sz):
            pass
        def detect(self, img):
            return None, np.array(self.faces, np.float32)

    # a border-straddling detection (half real, half mirror) survives,
    # clamped to the frame; a detection fully inside the pad is dropped
    fd.yunet = _Stub([
        [pad + 570, pad + 100, 60, 80, 0.9],   # face half off the right edge
        [5, pad + 200, 40, 40, 0.9],           # phantom fully in the left pad
    ])
    fd.net = fd.ort = None
    fd.size = None
    boxes = [tuple(round(v) for v in b[:4]) for b in fd.find(frame)]
    assert len(boxes) == 1, boxes
    x1, y1, x2, y2 = boxes[0]
    assert x2 == 600 and x1 >= 560, boxes    # clamped at the right border
    # an interior detection maps back to its exact position
    fd.yunet = _Stub([[pad + 100, pad + 120, 50, 60, 0.9]])
    fd.size = None
    (x1, y1, x2, y2, _c), = fd.find(frame)
    assert abs(x1 - (100 - 50 * fd.expand)) < 1.5
    assert abs(y1 - (120 - 60 * fd.expand)) < 1.5


def test_closeup_faces_get_a_larger_blur_margin():
    """Re-id benchmark (public-domain interview clip): one fully-blurred
    close-up face was re-identified at 0.63 from the neck and uniform
    insignia just below the blur, and --coverage concealed can't help (a
    frame-filling close-up yields no person detection). The face margin
    now ramps from the user's Face expand (faces <= 15% of the frame) up
    to 0.45 (>= 30%) — never below the user's own setting."""
    f = openscrub.face_expand_for
    ap = pytest.approx
    assert f(0.15, 50, 60, 600, 400) == ap(0.15)        # 15% of height
    assert f(0.15, 100, 100, 600, 400) == ap(0.35)      # 25%: ramping
    assert f(0.15, 160, 180, 600, 400) == ap(0.45)      # 45%: close-up
    assert f(0.05, 40, 40, 600, 400) == ap(0.05)        # user's lower value kept
    assert f(0.60, 160, 180, 600, 400) == ap(0.60)      # never below the user's
    assert f(0.15, 250, 300, 1080, 1920) > 0.15          # portrait: width share counts

    class CB(openscrub.Callbacks):
        def log(self, msg):
            pass
    fd = openscrub.FaceDetector(CB())
    frame = np.full((400, 600, 3), 90, np.uint8)
    pad = fd._edge_pad(600, 400)

    class _Stub:
        def __init__(self, faces):
            self.faces = faces

        def setInputSize(self, sz):
            pass

        def detect(self, img):
            return None, np.array(self.faces, np.float32)
    fd.net = fd.ort = None
    # a close-up face (180px of a 400px frame) gets the 0.45 margin
    fd.yunet, fd.size = _Stub([[pad + 200, pad + 60, 160, 180, 0.9]]), None
    (x1, y1, x2, y2, _c), = fd.find(frame)
    assert abs(y2 - min(400, 240 + 180 * 0.45)) < 1.5   # neck/collar covered
    assert abs(x1 - (200 - 160 * 0.45)) < 1.5
    # an ordinary face keeps exactly the 0.15 margin it always had
    fd.yunet, fd.size = _Stub([[pad + 100, pad + 120, 50, 60, 0.9]]), None
    (x1, y1, x2, y2, _c), = fd.find(frame)
    assert abs(y2 - (180 + 60 * 0.15)) < 1.5
    # measurement code (the re-id benchmark's attacker) keeps a FIXED
    # margin, so a stronger redaction can't move the attack's crops
    fd.closeup_margin = False
    fd.yunet, fd.size = _Stub([[pad + 200, pad + 60, 160, 180, 0.9]]), None
    (x1, y1, x2, y2, _c), = fd.find(frame)
    assert abs(y2 - (240 + 180 * 0.15)) < 1.5
    src = open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            "benchmark", "reid.py"), encoding="utf-8").read()
    assert src.count("closeup_margin=False") == 3


def test_blur_kernel_is_two_thirds_region():
    """Re-identification benchmark, close-up faces (200-750px): a
    1/3-width Gaussian left SFace similarity at 0.57-0.69 — above the
    0.55 same-person bar, so 11/133 faces re-identified through the
    blur. 2/3 width measures 0.11-0.23 on the same faces, at or below
    cross-person chance. Pin the kernel so a 'cosmetic' weakening of the
    blur can't silently reopen the leak."""
    seen = []
    orig = openscrub._gauss_big
    openscrub._gauss_big = lambda roi, k: (seen.append(k), orig(roi, k))[1]
    try:
        frame = np.full((400, 400, 3), 128, np.uint8)
        openscrub.blur_region(frame, 50, 50, 350, 350, "blur")
        # narrow-but-tall frame-border sliver: the kernel must scale with
        # the LONG side — width-scaled it hit the k=31 floor and border
        # half-faces re-identified at 0.55-0.71 through the blur
        openscrub.blur_region(frame, 0, 50, 40, 250, "blur")
    finally:
        openscrub._gauss_big = orig
    assert seen and seen[0] >= (2 * 300 // 3) | 1, seen
    assert len(seen) == 2 and seen[1] >= (2 * 200 // 3) | 1, seen


def test_group_lines_splits_columns():
    """Two-column layouts share a y-band; a merged line made the address
    detection's line box (and spaCy's NER context) span BOTH columns, so
    the blur swallowed unrelated right-column text ('Priority normal' sat
    on the address row and was over-blurred in 7 of 8 benchmark
    scenarios). A gap wider than 2.5x line height is a column boundary."""
    def w(txt, x, y=100):
        return (txt, (x, y, x + 12 * len(txt), y + 120 - 100 + y), 0.9)
    words = [("4210", (100, 100, 148, 120), 0.9),
             ("Kestrel", (160, 100, 244, 120), 0.9),
             ("Road", (256, 100, 304, 120), 0.9),
             ("Priority", (820, 100, 916, 120), 0.9),
             ("normal", (928, 100, 1000, 120), 0.9)]
    lines = openscrub.group_lines(words)
    texts = [ln["text"] for ln in lines]
    assert "4210 Kestrel Road" in texts and "Priority normal" in texts, texts
    # normal word gaps must NOT split
    lines = openscrub.group_lines(words[:3])
    assert [ln["text"] for ln in lines] == ["4210 Kestrel Road"]


def test_shredded_card_fragment_join():
    """OCR can fragment a spaced PAN into arbitrary digit chunks
    ("41 11 11 11 1 1 11 11 11" — a real read of a highlighted card row
    under video compression) or attach stray punctuation ("1111." from
    motion blur). Both defeated the fixed 3/4-group join and the card
    leaked. Any same-row run of digit tokens whose 13-16 digit
    concatenation has a card prefix AND passes Luhn must fire."""
    def w(txt, x):
        return (txt, (x, 100, x + 12 * max(1, len(txt)), 120), 0.9)
    shredded = [w(t, 60 + i * 40) for i, t in enumerate(
        ["41", "11", "11", "11", "1", "1", "11", "11", "11"])]
    dets = openscrub.detect_phi(shredded, [], 0.0, (0, 0), None, None)
    assert any(d.category == "card" and d.text == "4111111111111111"
               for d in dets), [(d.category, d.text) for d in dets]
    dotted = [w("4111", 60), w("1111", 130), w("1111.", 200), w("1111", 270)]
    dets = openscrub.detect_phi(dotted, [], 0.0, (0, 0), None, None)
    assert any(d.category == "card" for d in dets)
    # dark/noisy footage welds neighbouring groups into one big token
    # ("4111" ".1111." "1111.1111" — the exact PP-OCRv5 read of the
    # dark-mode benchmark card row that leaked in 1.0.78 dev): tokens up
    # to a full welded PAN must still join
    welded = [w("4111", 60), w(".1111.", 130), w("1111.1111", 210)]
    dets = openscrub.detect_phi(welded, [], 0.0, (0, 0), None, None)
    assert any(d.category == "card" and d.text == "4111111111111111"
               for d in dets), [(d.category, d.text) for d in dets]
    # and a single fully-welded punctuated PAN fires on its own
    solo = [w("4111.1111.1111.1111", 60)]
    dets = openscrub.detect_phi(solo, [], 0.0, (0, 0), None, None)
    assert any(d.category == "card" for d in dets)
    # welded junk that fails Luhn stays silent
    wj = [w("1234", 60), w("5678.9012", 130), w("3456", 240)]
    dets = openscrub.detect_phi(wj, [], 0.0, (0, 0), None, None)
    assert not any(d.category == "card" for d in dets)
    # a random digit run that fails Luhn must NOT fire
    junk = [w("4111", 60), w("1111", 130), w("1111", 200), w("1112", 270)]
    dets = openscrub.detect_phi(junk, [], 0.0, (0, 0), None, None)
    assert not any(d.category == "card" for d in dets)
    # SHREDDED fragments on different rows never join (the fragment
    # join is noise-driven, so it stays same-row; the classic 4-group
    # join may still bridge a wrapped PAN — that one is Luhn-gated)
    split_rows = ([w(t, 60 + i * 30) for i, t in enumerate(
                      ["41", "11", "11", "11"])]
                  + [("1", (60 + i * 30, 300, 80 + i * 30, 320), 0.9)
                     for i in range(8)])
    dets = openscrub.detect_phi(split_rows, [], 0.0, (0, 0), None, None)
    assert not any(d.category == "card" for d in dets)


def test_name_pair_heuristic_union_and_adjacency():
    """The capitalized-pair name heuristic is a UNION with NER, not a
    fallback: spaCy's small model returned zero entities for a real
    two-token name on a records screen, and NER availability silently
    disabled the heuristic that would have caught it. In strict (union)
    mode ALLCAPS headers stay exempt, and pairs glued together from
    different COLUMNS by line reconstruction (big x gap) never pair —
    that fake adjacency blurred benign text two columns away."""
    class FakeDoc:
        ents = ()

    class FakeNLP:
        def __call__(self, text):
            return FakeDoc()

    nd = openscrub.NameDetector(use_ner=False)
    nd.nlp = FakeNLP()                       # NER "available", finds nothing
    nd.heuristic = False                     # auto-mode: heuristic off pre-fix

    def line(pairs):
        words, text, x = [], "", None
        entries = []
        for wtxt, bx in pairs:
            s = len(text) + (1 if text else 0)
            text = (text + " " + wtxt) if text else wtxt
            entries.append((wtxt, bx, 0.9, s, s + len(wtxt)))
        return [{"text": text, "words": entries}]

    # adjacent Titlecase pair -> caught even though NER found nothing
    hits = nd.find(line([("Marguerite", (100, 50, 220, 70)),
                         ("Vandersloot", (228, 50, 360, 70))]))
    assert {h[1] for h in hits} == {"Marguerite", "Vandersloot"}
    # ALLCAPS header exempt in strict mode
    assert nd.find(line([("PATIENT", (100, 50, 200, 70)),
                         ("RECORD", (208, 50, 300, 70))])) == []
    # cross-column fake pair (huge x gap) never pairs
    assert nd.find(line([("Vandersloot", (100, 50, 220, 70)),
                         ("Ward", (600, 50, 660, 70))])) == []


def test_container_update_notice_is_inform_only(monkeypatch):
    """Inside Docker the in-place updater writes into the ephemeral
    container filesystem — the "update" would vanish on the next recreate
    while the UI claimed success (a real CUDA-image user saw the footer
    offer an update it could not deliver). In a container the API must
    say can_update=false (footer shows "pull the new image") and
    update_run must refuse with the pull instruction."""
    import openscrub_web
    monkeypatch.setenv("OPENSCRUB_IN_DOCKER", "1")
    assert openscrub_web._in_container() is True
    client = openscrub_web.app.test_client()
    d = client.get("/api/update_check").get_json()
    assert d["can_update"] is False
    r = client.post("/api/update_run")
    assert r.status_code == 400
    assert b"pulling the new image" in r.data
    # env cleared -> the env-var gate no longer forces container mode
    monkeypatch.delenv("OPENSCRUB_IN_DOCKER", raising=False)
    import os as _os
    if not (_os.path.exists("/.dockerenv")
            or _os.path.exists("/run/.containerenv")):
        assert openscrub_web._in_container() is False
        assert client.get("/api/update_check").get_json()["can_update"] is True


def test_quality_tiers_align_with_registries():
    """Every model id a Detection-quality tier selects must exist in its
    registry with a real download_url — a tier pointing at a missing or
    undownloadable model would error at apply time in the UI. ("" = the
    built-in face default and needs no registry entry.)"""
    import openscrub_web
    for tier, kinds in openscrub_web.QUALITY_TIERS.items():
        assert set(kinds) == {"face", "plate", "person"}, tier
        for kind, mid in kinds.items():
            if mid == "":
                continue
            entry = next((m for m in openscrub.load_model_registry(kind)
                          if m.get("id") == mid), None)
            assert entry is not None, f"{tier}: {kind}/{mid} not in registry"
            assert entry.get("download_url") not in (None, "", "TODO_VERIFY"), \
                f"{tier}: {kind}/{mid} has no download URL"


def test_ort_gpu_gate(monkeypatch):
    """The face-model GPU routing gate. OPENSCRUB_CPU_DNN=1 forces it OFF
    (a user can pin CPU); otherwise it reflects whether onnxruntime exposes
    a GPU provider (OpenVINO on Intel, CUDA on NVIDIA, DirectML on the
    Windows installer). This gate — together with cuda_dnn_available() — is
    what routes ONNX face models onto the GPU on the Intel and Windows
    builds while leaving the CUDA image on its OpenCV path."""
    monkeypatch.setenv("OPENSCRUB_CPU_DNN", "1")
    assert openscrub._ort_gpu_available() is False
    monkeypatch.delenv("OPENSCRUB_CPU_DNN", raising=False)
    import onnxruntime as ort
    gpu_provs = {"OpenVINOExecutionProvider", "CUDAExecutionProvider",
                 "DmlExecutionProvider"}
    expect = bool(set(ort.get_available_providers()) & gpu_provs)
    assert openscrub._ort_gpu_available() is expect

    # DirectML must count as a GPU provider (the Windows-installer path):
    # simulate onnxruntime exposing it and confirm the gate opens.
    real = ort.get_available_providers
    monkeypatch.setattr(ort, "get_available_providers",
                        lambda: ["DmlExecutionProvider", "CPUExecutionProvider"])
    assert openscrub._ort_gpu_available() is True
    monkeypatch.setattr(ort, "get_available_providers", real)


def test_structured_recognizers_checksums():
    """bank/crypto/passport recognizers are CHECKSUM-gated: a match must
    verify (IBAN mod-97, ABA weights, Base58Check) — patterns alone
    would flood text with false positives."""
    assert openscrub._iban_ok("GB82WEST12345698765432")
    assert not openscrub._iban_ok("GB82WEST12345698765431")
    assert openscrub._aba_ok("021000021")          # real Fed routing
    assert not openscrub._aba_ok("021000022")
    assert openscrub._btc_ok("1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa")
    assert not openscrub._btc_ok("1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNb")
    assert openscrub._mrz_ok("P<UTOERIKSSON<<ANNA<MARIA<<<<<<<<<<<<<<<<<<<")
    assert not openscrub._mrz_ok("HELLOWORLDHELLOWORLD")

    words = [
        ("GB82WEST12345698765432", (0, 0, 100, 10), 0.9),
        ("021000021", (0, 20, 100, 30), 0.9),
        ("0x52908400098527886E0F7030069857D2E4169EE7", (0, 40, 100, 50), 0.9),
        ("1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa", (0, 60, 100, 70), 0.9),
        ("P<UTOERIKSSON<<ANNA<MARIA<<<<<<<<<<<<<<<<<<<", (0, 80, 100, 90), 0.9),
        ("armadillo", (0, 100, 100, 110), 0.9),
        ("123456789", (0, 120, 100, 130), 0.9),   # fails ABA checksum
    ]
    dets = openscrub.detect_phi(words, [], 0.0, (0, 0), None, None)
    cats = sorted(d.category for d in dets)
    assert cats.count("bank") == 2, cats       # IBAN + routing
    assert cats.count("crypto") == 2, cats     # ETH + BTC
    assert cats.count("passport") == 1, cats


def test_speech_suggestions_from_word_stream():
    """Pure spoken-PII mapping: whisper words -> suggestion spans with
    padded timestamps, category filtering, and same-category merging.
    Suggestions only exist for the job's selected categories."""
    words = [(0.0, 0.3, " call"), (0.35, 0.5, " me"), (0.55, 0.7, " at"),
             (0.75, 1.6, " 555-867-5309"), (2.0, 2.2, " thanks"),
             (3.0, 3.4, " SSN"), (3.5, 4.4, " 123-45-6789")]
    sugg = openscrub._speech_suggestions(words, {"phone", "ssn"})
    cats = sorted(s["category"] for s in sugg)
    assert cats == ["phone", "ssn"], sugg
    ph = next(s for s in sugg if s["category"] == "phone")
    assert ph["t0"] <= 0.75 - 0.3 and ph["t1"] >= 1.6 + 0.3, \
        "span must pad the matched words"
    assert "555" in ph["text"]
    # unselected categories yield nothing
    assert openscrub._speech_suggestions(words, {"email"}) == []
    assert openscrub._speech_suggestions([], {"phone"}) == []

    # spoken names via NER (stub nlp shaped like spaCy's API)
    class Ent:
        label_ = "PERSON"
        def __init__(self, s, e, t):
            self.start_char, self.end_char, self.text = s, e, t
    class Doc:
        def __init__(self, text):
            i = text.find("Maria Gonzalez")
            self.ents = [Ent(i, i + 14, "Maria Gonzalez")] if i >= 0 else []
    nwords = [(0.0, 0.4, " ask"), (0.5, 0.8, " for"),
              (0.9, 1.4, " Maria"), (1.45, 2.1, " Gonzalez")]
    ns = openscrub._speech_suggestions(nwords, {"name"}, nlp=Doc)
    assert len(ns) == 1 and ns[0]["category"] == "name"
    assert ns[0]["t0"] <= 0.6 and ns[0]["t1"] >= 2.4


def test_speech_suggestions_spoken_address():
    """Spoken addresses. The address category was MISSING from
    _SPEECH_CHECKS entirely — an address-only spoken-PII job could never
    suggest anything (a real user hit exactly that on a clip saying
    'My address is <number> <street>, <city> <state> <zip>'). Pins the
    three speech-address behaviors: RE_STREET on the street line, the
    spoken city/state/ZIP tail (full state name, no comma — the written
    RE_CITYSTATEZIP form cannot match it), and the pause-tolerant merge
    that joins both halves across a natural mid-address pause into ONE
    span, so review never shows a half-address."""
    words = [(0.7, 1.3, " My"), (1.3, 1.9, " address"), (1.9, 2.6, " is"),
             (2.6, 4.0, " 1200"), (4.0, 5.1, " Oak"), (5.1, 5.7, " Street,"),
             # natural ~1.5s pause before the city/state/ZIP tail
             (7.2, 8.6, " Springfield"), (8.6, 9.1, " Illinois"),
             (9.1, 10.8, " 62704.")]
    sugg = openscrub._speech_suggestions(words, {"address"})
    assert len(sugg) == 1, sugg          # ONE merged span, not two halves
    s = sugg[0]
    assert s["category"] == "address"
    assert s["t0"] <= 2.6 - 0.3 and s["t1"] >= 10.8 + 0.3, s
    assert "1200" in s["text"] and "62704" in s["text"]
    # tail alone (no street line) still suggests — state name + ZIP is a
    # strong signal by itself
    tail = openscrub._speech_suggestions(
        [(0.0, 0.5, " Springfield"), (0.5, 1.0, " Illinois"),
         (1.0, 1.6, " 62704")], {"address"})
    assert len(tail) == 1 and tail[0]["category"] == "address"
    # unselected category: nothing (gating unchanged)
    assert openscrub._speech_suggestions(words, {"ssn"}) == []

    # ASR formatting variance (all three leaked a real address between
    # whisper builds): thousands-comma ZIP ("62,704"), spaced-digit ZIP,
    # and a word-number house ("one thirteen Main Street" — RE_STREET's
    # digit head can never match it)
    assert openscrub.RE_SPOKEN_STATEZIP.search("Springfield Illinois 62,704")
    assert openscrub.RE_SPOKEN_STATEZIP.search("Springfield Illinois 6 2 7 0 4")
    assert openscrub.RE_SPOKEN_STREET.search("one thirteen Main Street")
    assert openscrub.RE_SPOKEN_STREET.search(
        "eleven twenty two West Elm Avenue apartment 4B")
    # ordinary prose stays clean — no false positives from the widening
    for clean in ("I walked down the street yesterday",
                  "the meeting is in room 12",
                  "turn left in five hundred feet"):
        assert not openscrub.RE_SPOKEN_STREET.search(clean), clean
        assert not openscrub.RE_SPOKEN_STATEZIP.search(clean), clean


def test_person_seg_migration_lives_in_init():
    """The seg-to-onnxruntime migration must run at LOAD TIME as the
    tail of PersonDetector.__init__. In v1.0.65 a method insertion
    orphaned it into dead code after another method's return —
    syntactically valid, never executed — and on the CUDA image's
    OpenCV 4.10 (whose multi-output forward asserts in fuseLayers)
    silhouettes silently degraded to boxes and the tracked-object
    detector path failed over to the generic tracker."""
    import inspect
    src = inspect.getsource(openscrub.PersonDetector.__init__)
    assert "moved " in src and "onnxruntime" in src, \
        "the seg migration block must live inside __init__"
    # and behaviourally: a 2-output model must come out ort-backed
    sp = os.environ.get("OPENSCRUB_TEST_SEG_MODEL")
    if sp and os.path.exists(sp):
        det = openscrub.PersonDetector(model_path=sp, thresh=0.5)
        if det.seg:
            assert det.ort is not None and det.net is None, \
                "seg models must ALWAYS run on onnxruntime"


def test_upload_cap_configurable_and_413_explains_the_way_out(monkeypatch):
    """A real 18 GB plate-removal upload died as a bare '413 Request
    Entity Too Large' with no path forward. The cap is a dial now
    (--max-upload-gb / OPENSCRUB_MAX_UPLOAD_GB, 0 = unlimited) and the
    413 body is JSON that names BOTH remedies — raising the cap and the
    'path on the server' box, which is the right route for huge files."""
    import openscrub_web
    mb = openscrub_web._max_upload_bytes
    monkeypatch.delenv("OPENSCRUB_MAX_UPLOAD_GB", raising=False)
    assert mb() == 8 * 1024 ** 3                 # default unchanged
    assert mb("40") == 40 * 1024 ** 3            # CLI value wins
    assert mb("0") is None                       # explicit 0 = unlimited
    assert mb("garbage") == 8 * 1024 ** 3        # junk falls back, closed
    monkeypatch.setenv("OPENSCRUB_MAX_UPLOAD_GB", "20")
    assert mb() == 20 * 1024 ** 3                # env honored
    assert mb("40") == 40 * 1024 ** 3            # CLI still beats env
    old = openscrub_web.app.config["MAX_CONTENT_LENGTH"]
    try:
        openscrub_web.app.config["MAX_CONTENT_LENGTH"] = 1024
        client = openscrub_web.app.test_client()
        r = client.post("/api/jobs", data=b"x" * 4096,
                        content_type="application/octet-stream")
        assert r.status_code == 413
        j = r.get_json()
        assert j and "path on the server" in j["error"]
        assert "max-upload-gb" in j["error"]
    finally:
        openscrub_web.app.config["MAX_CONTENT_LENGTH"] = old


def test_index_injects_upload_cap_for_preflight():
    """The editor refuses an over-cap file BEFORE uploading (an 18 GB
    upload must not run for an hour just to bounce): index() replaces
    the %%MAXUP%% placeholder with the live byte cap."""
    import openscrub_web
    client = openscrub_web.app.test_client()
    html = client.get("/").data.decode()
    assert "%%MAXUP%%" not in html
    cap = openscrub_web.app.config["MAX_CONTENT_LENGTH"] or 0
    assert f'const MAXUP=+"{cap}"||0' in html
    # same mechanism for free disk: the editor refuses an upload that
    # cannot fit before hours of transfer (issue #16)
    assert "%%FREEDISK%%" not in html
    assert 'const FREEDISK=+"' in html


class _FakeOrtTensor:
    def __init__(self, name):
        self.name = name


class _FakeOrtSession:
    """Stands in for an onnxruntime InferenceSession in backend tests."""
    def __init__(self, out=None):
        self._out = out if out is not None else np.zeros((1, 5, 8400),
                                                         np.float32)

    def get_inputs(self):
        return [_FakeOrtTensor("images")]

    def get_outputs(self):
        return [_FakeOrtTensor("output0")]

    def get_providers(self):
        return ["CPUExecutionProvider"]

    def run(self, outs, feed):
        return [self._out]


def test_plate_cv2_backend_must_prove_inference_at_load(tmp_path,
                                                        monkeypatch):
    """Issue #16: OpenCV 5.0.0's ONNX importer ACCEPTS the end2end YOLOv9
    plate models that 4.x rejected at readNetFromONNX — and then dies at
    the FIRST forward ('gather2_layer ... (-211) some of indices are
    outside of range'), killing the whole scan. A load that only proves
    readNetFromONNX is therefore worthless: the cv2 backend must survive
    a real blob->forward->decode before being trusted, and a model that
    can't moves to onnxruntime (which is field-proven on these exports)."""
    mp = tmp_path / "plate.onnx"
    mp.write_bytes(b"fake")

    class _Cv2LoadsButCannotRun:
        def setInput(self, blob):
            pass

        def forward(self, *a):
            raise RuntimeError("(-211:One of the arguments' values is out "
                               "of range) some of indices are outside of "
                               "range in function 'cv::dnn::gather'")

    monkeypatch.setattr(openscrub, "_apply_cuda_dnn", lambda n: n)
    monkeypatch.setattr(openscrub.cv2.dnn, "readNetFromONNX",
                        lambda p: _Cv2LoadsButCannotRun())
    monkeypatch.setattr(openscrub, "_ort_session",
                        lambda p: _FakeOrtSession())
    det = openscrub.PlateDetector(model_path=str(mp), thresh=0.5)
    assert det.net is None, "a net that cannot run a forward is NOT loaded"
    assert det.ort is not None and det.available()
    assert det.find(np.zeros((480, 640, 3), np.uint8)) == []


def test_plate_cv2_midscan_failure_rescues_onto_onnxruntime(tmp_path,
                                                            monkeypatch):
    """Belt and braces for the same class of failure: a cv2 net that
    passes the load-time self-test but dies on a real frame mid-scan must
    move to onnxruntime and keep scanning — and when onnxruntime cannot
    take over, the scan must die LOUDLY (fail closed) rather than quietly
    continue without the category."""
    mp = tmp_path / "plate.onnx"
    mp.write_bytes(b"fake")

    class _Cv2DiesOnSecondForward:
        def __init__(self):
            self.calls = 0

        def setInput(self, blob):
            pass

        def forward(self, *a):
            self.calls += 1
            if self.calls > 1:
                raise RuntimeError("gather: index out of range mid-scan")
            return np.zeros((1, 5, 8400), np.float32)

    monkeypatch.setattr(openscrub, "_apply_cuda_dnn", lambda n: n)
    monkeypatch.setattr(openscrub.cv2.dnn, "readNetFromONNX",
                        lambda p: _Cv2DiesOnSecondForward())
    monkeypatch.setattr(openscrub, "_ort_session",
                        lambda p: _FakeOrtSession())
    det = openscrub.PlateDetector(model_path=str(mp), thresh=0.5)
    assert det.net is not None          # load self-test passed
    frame = np.zeros((480, 640, 3), np.uint8)
    assert det.find(frame) == []        # forward #2 dies -> rescued
    assert det.ort is not None and det.net is None
    assert det.find(frame) == []        # and it keeps working

    # no rescue available -> the failure must surface, never go silent
    def _no_ort(p):
        raise RuntimeError("onnxruntime not installed")
    monkeypatch.setattr(openscrub, "_ort_session", _no_ort)
    monkeypatch.setattr(openscrub.cv2.dnn, "readNetFromONNX",
                        lambda p: _Cv2DiesOnSecondForward())
    det2 = openscrub.PlateDetector(model_path=str(mp), thresh=0.5)
    assert det2.net is not None
    with pytest.raises(RuntimeError):
        det2.find(frame)


def test_job_retry_reuses_upload_without_a_new_job():
    """Issue #16, part two: after a failed scan the only path forward was
    Start scan, which re-uploaded the same multi-GB file into a FRESH job
    dir on every attempt until the disk filled. Retry re-queues the same
    job on the file already on the server."""
    import shutil
    import openscrub_web as w
    job = w.new_job("", {}, "clip.mp4")
    client = w.app.test_client()
    try:
        path = os.path.join(job["dir"], "input.mp4")
        with open(path, "wb") as f:
            f.write(b"\x00" * 1024)
        job["video"], job["size"] = path, 1024
        job["phase"], job["error"] = "error", "boom"
        n0 = len(w.JOBS)
        r = client.post(f"/api/jobs/{job['id']}/retry")
        assert r.status_code == 200
        assert len(w.JOBS) == n0, "retry must reuse the job, not add one"
        assert job["phase"] == "queued" and job["error"] is None
        # guards: a running job can't be retried; a reaped file can't either
        job["phase"] = "scanning"
        assert client.post(f"/api/jobs/{job['id']}/retry").status_code == 409
        job["phase"] = "error"
        os.remove(path)
        assert client.post(f"/api/jobs/{job['id']}/retry").status_code == 410
        # the jobs list exposes name+size so the editor can warn before
        # uploading a byte-identical duplicate
        js = client.get("/api/jobs").get_json()
        mine = next(j for j in js if j["id"] == job["id"])
        assert mine["size"] == 1024
    finally:
        try:
            w.WORK_Q.get_nowait()
            w.WORK_Q.task_done()
        except Exception:
            pass
        shutil.rmtree(job["dir"], ignore_errors=True)
        w.JOBS.pop(job["id"], None)


def test_upload_refused_when_disk_cannot_fit_it(monkeypatch):
    """Issue #16, part three: an upload the disk cannot hold must be
    refused from the Content-Length header — BEFORE werkzeug spools the
    body to the temp dir — with JSON naming the way out. Unmeasurable
    free space never blocks (the guard acts only on a measured
    certainty, the scan-copy verifier's rule)."""
    import openscrub_web as w
    assert w._upload_disk_error(0) is None
    monkeypatch.setattr(w, "_disk_free", lambda p: 10 * 1024 ** 2)
    err = w._upload_disk_error(50 * 1024 ** 2)
    assert err and "path on the server" in err and "disk space" in err
    monkeypatch.setattr(w, "_disk_free", lambda p: 1 << 60)
    assert w._upload_disk_error(50 * 1024 ** 2) is None

    def _unmeasurable(p):
        raise OSError("no statvfs here")
    monkeypatch.setattr(w, "_disk_free", _unmeasurable)
    assert w._upload_disk_error(50 * 1024 ** 2) is None
    # the request path: refused before the view, as JSON, status 507
    monkeypatch.setattr(w, "_disk_free", lambda p: 10 * 1024 ** 2)
    client = w.app.test_client()
    r = client.post("/api/jobs", data=b"x" * 4096,
                    content_type="application/octet-stream")
    assert r.status_code == 507
    j = r.get_json()
    assert j and "disk space" in j["error"]


def test_plate_autofetch_gates(monkeypatch, tmp_path):
    """Issue #18: the plate category self-heals by fetching the
    RECOMMENDED registry model unattended — but ONLY when that entry is
    permissively licensed AND already sha256-pinned. TOFU pinning and
    AGPL downloads remain explicit user decisions, and failures degrade
    to None (the inert-category guard), never an exception."""
    monkeypatch.delenv("OPENSCRUB_NO_AUTOFETCH", raising=False)
    calls = []

    def fake_download(entry, kind="plate", **kw):
        calls.append(entry["id"])
        p = tmp_path / ("%s.onnx" % entry["id"])
        p.write_bytes(b"model")
        return str(p)

    monkeypatch.setattr(openscrub, "download_model", fake_download)

    def reg(entries):
        monkeypatch.setattr(openscrub, "load_model_registry",
                            lambda kind="plate": entries)

    good = {"id": "m1", "recommended": True, "license": "MIT",
            "sha256": "ab" * 32, "download_url": "https://x/m1.onnx"}
    reg([good])
    assert openscrub.autofetch_plate_model() == str(tmp_path / "m1.onnx")
    assert calls == ["m1"]
    # no pin -> no unattended fetch (TOFU is a user decision)
    reg([dict(good, sha256="")])
    assert openscrub.autofetch_plate_model() is None
    # restrictive license -> no unattended fetch
    reg([dict(good, license="AGPL-3.0")])
    assert openscrub.autofetch_plate_model() is None
    # nothing recommended -> None
    reg([dict(good, recommended=False)])
    assert openscrub.autofetch_plate_model() is None
    assert calls == ["m1"], "gated entries must never reach download_model"
    # a download failure returns None instead of raising

    def boom(entry, kind="plate", **kw):
        raise RuntimeError("offline")
    monkeypatch.setattr(openscrub, "download_model", boom)
    reg([good])
    assert openscrub.autofetch_plate_model() is None


def test_resolve_model_searches_autofetch_cache(monkeypatch, tmp_path):
    """The Docker images bake the recommended plate model into the
    auto-download cache (~/.openscrub/models) — the resolution ladder
    must search it (LAST, so explicit picks win) or the baked model is
    invisible and plates stay inert in containers (issue #18)."""
    cache = tmp_path / "cache"
    cache.mkdir()
    monkeypatch.setattr(openscrub, "_model_dir", lambda: str(cache))
    monkeypatch.delenv("OPENSCRUB_PLATE_MODEL", raising=False)
    # a synthetic registry id, so a real model downloaded on this machine
    # (repo models/, user data dir) can never satisfy the ladder early
    monkeypatch.setattr(
        openscrub, "load_model_registry",
        lambda kind="plate": [{"id": "zz-test-plate-999",
                               "recommended": True, "input_size": 416}])
    found, size = openscrub.PlateDetector.resolve_model()
    assert (found is None
            or os.path.basename(found) == "plate_yolov8.onnx"), \
        "only a conventional local file may resolve without the cache"
    mf = cache / "zz-test-plate-999.onnx"
    mf.write_bytes(b"model")
    found, size = openscrub.PlateDetector.resolve_model()
    if os.path.basename(found) != "plate_yolov8.onnx":   # no local override
        assert found == str(mf)
        assert size == 416      # input size adopted from the registry
    # an explicit pick beats the cache
    explicit = tmp_path / "mine.onnx"
    explicit.write_bytes(b"model")
    found, _ = openscrub.PlateDetector.resolve_model(str(explicit))
    assert found == str(explicit)


def test_scan_refuses_when_every_selected_category_is_inert(monkeypatch,
                                                            tmp_path):
    """Issue #18's real harm: a plate-only job with no plate model ran to
    completion having detected nothing — fail OPEN. With no model
    resolvable and autofetch unavailable, the scan must REFUSE loudly."""
    monkeypatch.setattr(openscrub, "autofetch_plate_model",
                        lambda cb=None: None)
    monkeypatch.setattr(openscrub.PlateDetector, "resolve_model",
                        classmethod(lambda cls, mp=None: (None, None)))
    v = str(tmp_path / "clip.mp4")
    make_video(v, [(300, "hello world")], seconds=0.5)
    with pytest.raises(RuntimeError, match="nothing to detect"):
        run(v, "--categories", "plate")


def test_model_status_endpoint():
    """The editor's 'will detect nothing' warnings ask the server which
    detectors would find a model — same resolution ladder as the engine —
    and whether a missing plate model self-heals."""
    import openscrub_web as w
    d = w.app.test_client().get("/api/model_status").get_json()
    assert set(d) >= {"plate", "person", "plate_autofetch"}
    assert all(isinstance(v, bool) for v in d.values())
    # the shipped registry's recommended plate entry is MIT + pinned, so
    # autofetch must be reported available
    assert d["plate_autofetch"] is True


def test_editor_warns_when_models_missing():
    """The page must carry the issue-#18 warnings: a live model-status
    fetch, inline amber notes on model-less checked categories, and
    startScan confirms for person/screen."""
    import zones_ui
    page = zones_ui.ZONES_PAGE
    assert "api/model_status" in page
    assert "plate_autofetch" in page
    assert "detect NOTHING" in page


def test_editor_overlay_releases_video_controls():
    """Issue #17: the zone overlay swallowed every click in both modes, so
    a freshly loaded video could not even be played and the default draw
    tool looked impossible to close. Play is a real mode now — the overlay
    passes pointer events through to the native video controls — and it is
    the DEFAULT; drawing is opt-in."""
    import zones_ui
    page = zones_ui.ZONES_PAGE
    assert 'id="mplay"' in page                       # the ▶ Play button
    assert 'setMode("play");loadCustomList' in page   # play is the default
    assert 'pointerEvents=m==="play"?"none":"auto"' in page
    assert "Esc closes the draw tool" in page         # Escape exits draw
    # picking a zone class flips into draw mode by itself (play default
    # must not make the first zone a two-click mystery)
    assert 'if(S.mode!=="draw")setMode("draw")' in page


def test_box_editor_has_playback():
    """Issue #17 part two: 'you cannot play review and see hits' — the
    review box editor was scrub-only. It now streams the job video with
    the boxes repainted live."""
    import openscrub_web
    page = openscrub_web.PAGE
    assert "beTogglePlay" in page and 'id="beVid"' in page
    assert "api/jobs/${CUR}/video" in page


def test_job_video_stream_supports_range():
    """The playback route must stream the job's scan video with Range
    support (browsers refuse to seek a <video> without it) and 404 once
    the file is gone instead of erroring."""
    import shutil
    import openscrub_web as w
    job = w.new_job("", {}, "clip.mp4")
    client = w.app.test_client()
    try:
        path = os.path.join(job["dir"], "input.mp4")
        with open(path, "wb") as f:
            f.write(bytes(range(256)) * 16)
        job["video"] = path
        r = client.get(f"/api/jobs/{job['id']}/video")
        assert r.status_code == 200
        assert r.headers.get("Accept-Ranges") == "bytes"
        r2 = client.get(f"/api/jobs/{job['id']}/video",
                        headers={"Range": "bytes=0-99"})
        assert r2.status_code == 206 and len(r2.data) == 100
        os.remove(path)
        assert client.get(f"/api/jobs/{job['id']}/video").status_code == 404
    finally:
        shutil.rmtree(job["dir"], ignore_errors=True)
        w.JOBS.pop(job["id"], None)


def test_bad_web_settings_fall_back_and_never_exit(tmp_path, monkeypatch):
    """A real iPhone job hung forever: Safari submitted engine:"" (a select
    reporting no selection), argparse rejected `--engine ''` with
    sys.exit, and the SystemExit silently killed the server's only job
    worker. Invalid choices / non-numbers now fall back to the engine's own
    defaults with a log NOTE, and any remaining parser error is a normal
    exception (fails the job) — never a SystemExit."""
    import openscrub_web as w
    job = {"video": str(tmp_path / "x.mp4"), "dir": str(tmp_path), "log": [],
           "options": {"engine": "", "device": None, "mode": "smudge",
                       "pad": None, "detect_scale": "nan",
                       "face_threshold": "", "scan_speed": "fastest"}}
    a = w.build_args(job)
    assert (a.engine, a.device, a.mode) == ("auto", "auto", "blur")
    assert a.pad == 8 and a.detect_scale == 0.5     # fastest still applies
    assert a.face_threshold == 0.6
    assert any("--engine" in l and "not valid" in l for l in job["log"])
    # good values pass through untouched
    job["options"] = {"engine": "tesseract", "pad": 3, "mode": "box"}
    a = w.build_args(job)
    assert (a.engine, a.pad, a.mode) == ("tesseract", 3, "box")

    def boom(args, parser):
        parser.error("synthetic rejection")
    monkeypatch.setattr(openscrub, "_prep_args", boom)
    with pytest.raises(ValueError, match="invalid job settings"):
        w.build_args(job)


def test_web_worker_survives_a_dying_job_and_cancel_clears_the_queue(
        monkeypatch):
    """One job raising SystemExit must fail THAT job loudly while the worker
    carries on with the next one. A job cancelled while still queued is
    cancelled at once (Cancel used to wait for a worker that never came)
    and its queue entry is voided, so a Retry runs the scan exactly once."""
    import shutil
    import openscrub_web as w
    while True:                        # start from an empty queue
        try:
            w.WORK_Q.get_nowait()
            w.WORK_Q.task_done()
        except Exception:
            break
    ran = []

    def fake_build_args(job, for_render=False):
        ran.append(job["id"])
        if job["name"] == "dies.mov":
            raise SystemExit(2)
        raise RuntimeError("second job ran")
    monkeypatch.setattr(w, "build_args", fake_build_args)
    a = w.new_job("", {"engine": ""}, "dies.mov")
    b = w.new_job("", {}, "next.mov")
    c = w.new_job("", {}, "cancelled.mov")
    client = w.app.test_client()
    saved = dict(w.WORKER)
    try:
        for j in (a, b, c):
            w.enqueue(j, "scan")
        r = client.post(f"/api/jobs/{c['id']}/cancel")
        assert r.status_code == 200
        assert c["phase"] == "cancelled", \
            "a queued job must be cancelled immediately"
        # retry after cancel: requeued once; the voided entry is skipped
        c["video"] = os.path.join(c["dir"], "input.mp4")
        with open(c["video"], "wb") as f:
            f.write(b"\x00" * 16)
        assert client.post(f"/api/jobs/{c['id']}/retry").status_code == 200
        w.WORK_Q.put(None)             # stop marker: worker exits after
        t = threading.Thread(target=w.worker, daemon=True)
        t.start()
        t.join(10)
        assert not t.is_alive()
        assert a["phase"] == "error" and "stopped unexpectedly" in a["error"]
        assert any(l.startswith("ERROR:") for l in a["log"])
        assert b["phase"] == "error" and b["error"] == "second job ran", \
            "the worker must survive job A and run job B"
        assert ran.count(c["id"]) == 1, "retried job must run exactly once"
        assert ran == [a["id"], b["id"], c["id"]]
    finally:
        w.WORKER.update(saved)
        for j in (a, b, c):
            shutil.rmtree(j["dir"], ignore_errors=True)
            w.JOBS.pop(j["id"], None)


def test_worker_watchdog_fails_orphan_and_restarts(monkeypatch):
    """If the worker thread is ever gone, the job it was running can never
    finish: the watchdog fails it (so Cancel/Delete/Retry work) and starts
    a fresh worker so the queue moves again."""
    import shutil
    import openscrub_web as w
    started = []
    monkeypatch.setattr(w, "start_worker", lambda: started.append(1))
    job = w.new_job("", {}, "orphan.mov")
    job["phase"] = "scanning"
    dead = threading.Thread(target=lambda: None)
    dead.start()
    dead.join()
    saved = dict(w.WORKER)
    try:
        w.WORKER.update(thread=dead, current=job["id"])
        assert w.check_worker() is True
        assert job["phase"] == "error" and "Retry" in job["error"]
        assert started == [1]
        live = threading.Thread(target=time.sleep, args=(2,))
        live.start()
        w.WORKER.update(thread=live, current=None)
        assert w.check_worker() is False and started == [1]
    finally:
        w.WORKER.update(saved)
        shutil.rmtree(job["dir"], ignore_errors=True)
        w.JOBS.pop(job["id"], None)


def test_job_options_survive_restart_for_retry():
    """A scan that never finished has no report to recover settings from;
    Retry after a restart used to run with DEFAULTS (every category) instead
    of what the user chose. Options are now saved with the upload."""
    import shutil
    import openscrub_web as w
    opts = {"categories": "face", "scan_speed": "fastest"}
    job = w.new_job("", opts, "clip.mov")
    jid, jdir = job["id"], job["dir"]
    try:
        with open(os.path.join(jdir, "input.mov"), "wb") as f:
            f.write(b"\x00" * 64)
        assert os.path.exists(os.path.join(jdir, w.OPTIONS_FILE))
        w.JOBS.pop(jid)                # simulate the restart
        w.rehydrate_jobs()
        back = w.JOBS[jid]
        assert back["phase"] == "error" and back["options"] == opts
        assert "original settings" in back["error"]
    finally:
        w.JOBS.pop(jid, None)
        shutil.rmtree(jdir, ignore_errors=True)


def test_editor_repairs_unselected_selects_before_submit():
    """Client half of the engine:"" hang: startScan puts any <select> left
    with no selection back on its page default before building options."""
    import zones_ui
    page = zones_ui.ZONES_PAGE
    i = page.index("async function startScan")
    body = page[i:page.index("const o={", i)]
    assert "selectedIndex<0" in body and "defaultSelected" in body


def test_rehydrate_surfaces_reportless_upload_as_failed_job():
    """A job that crashed before writing a report used to vanish from the
    UI at the next restart while its multi-GB upload stayed on disk — an
    orphan the user could neither retry nor delete. It now rehydrates as
    a failed job with its upload attached."""
    import shutil
    import openscrub_web as w
    jid = "deadbeef16aa"
    jdir = os.path.join(w.JOBS_DIR, jid)
    os.makedirs(jdir, exist_ok=True)
    try:
        up = os.path.join(jdir, "input.mp4")
        with open(up, "wb") as f:
            f.write(b"\x00" * 2048)
        w.rehydrate_jobs()
        job = w.JOBS.get(jid)
        assert job is not None, "report-less upload dirs must be recovered"
        assert job["phase"] == "error" and job["video"] == up
        assert job["size"] == 2048
        assert "Retry" in job["error"] and "Delete" in job["error"]
    finally:
        w.JOBS.pop(jid, None)
        shutil.rmtree(jdir, ignore_errors=True)


def test_dense_merge_skips_pairwise_comparisons(monkeypatch):
    """Per-frame detections must never enter the generic merge search."""
    def forbidden(*args):
        raise AssertionError(
            "Dense detections must not require box comparisons"
        )

    monkeypatch.setattr(openscrub, "boxes_overlap", forbidden)

    dets = [
        openscrub.Detection(
            i / 60, i / 60 + 0.005,
            (100, 100, 160, 160),
            "face", "face", 0.9,
            dense=True
        )
        for i in range(1000)
    ]

    result = openscrub.merge_detections(dets, hold=0.8)

    assert len(result) == len(dets)
    assert all(a is b for a, b in zip(result, dets))
    assert all(d.t_end - d.t_start < 0.01 for d in result)


def test_mixed_merge_excludes_dense_candidates(monkeypatch):
    """Sparse detections still merge, without searching dense samples."""
    original_overlap = openscrub.boxes_overlap
    calls = []

    def counted_overlap(a, b):
        calls.append((a, b))
        return original_overlap(a, b)

    monkeypatch.setattr(
        openscrub, "boxes_overlap", counted_overlap
    )

    def make(t, dense):
        return openscrub.Detection(
            t, t + 0.01,
            (100, 100, 160, 160),
            "face", "face", 0.9,
            dense=dense
        )

    sparse1 = make(0.0, False)
    dense1 = make(0.1, True)
    sparse2 = make(0.2, False)
    dense2 = make(0.3, True)

    result = openscrub.merge_detections(
        [sparse1, dense1, sparse2, dense2],
        hold=0.8
    )

    assert len(result) == 3
    assert result[0] is sparse1
    assert result[1] is dense1
    assert result[2] is dense2
    assert len(calls) == 1
    assert abs(sparse1.t_end - 1.0) < 1e-9


def test_third_party_notices_cover_every_baked_model():
    """Every model file the Docker images redistribute (the prefetch
    table) must have its notice — license + copyright — in
    THIRD_PARTY_NOTICES.md, identified by filename AND sha256, and the
    notices file must ship everywhere: all three images, the sdist, the
    wheel, and the Windows installer. Adding a model to the prefetch
    without a notice fails here, not in a license audit."""
    import importlib.util
    here = os.path.dirname(os.path.abspath(__file__))
    spec = importlib.util.spec_from_file_location(
        "prefetch_models", os.path.join(here, "docker", "prefetch_models.py"))
    pf = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(pf)
    notes = open(os.path.join(here, "THIRD_PARTY_NOTICES.md"),
                 encoding="utf-8").read()
    for key, (url, sha, fname) in pf.MODELS.items():
        assert fname in notes, f"{key}: {fname} has no notice"
        assert sha in notes, f"{key}: notice not tied to the shipped file"
    assert "{{" not in notes, "unfilled license-text placeholder"
    assert notes.count("Permission is hereby granted, free of charge") == 2
    assert "TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION" \
        in notes
    for df in ("Dockerfile", "Dockerfile.intel", "Dockerfile.cuda"):
        src = open(os.path.join(here, df), encoding="utf-8").read()
        assert any(l.startswith("COPY ") and "THIRD_PARTY_NOTICES.md" in l
                   for l in src.splitlines()), f"{df} must ship the notices"
    py = open(os.path.join(here, "pyproject.toml"), encoding="utf-8").read()
    sdist = py.split("[tool.hatch.build.targets.sdist]", 1)[1]
    assert '"THIRD_PARTY_NOTICES.md",' in sdist      # wheel builds FROM it
    assert '"THIRD_PARTY_NOTICES.md" = "openscrub_THIRD_PARTY_NOTICES.md"' \
        in py
    spec_src = open(os.path.join(here, "windows", "openscrub.spec"),
                    encoding="utf-8").read()
    assert '"THIRD_PARTY_NOTICES.md"' in spec_src


def test_registry_doc_fields_refresh_but_pins_stay(monkeypatch, tmp_path):
    """Read-only installs keep a per-user registry copy. A release that
    corrects an entry's documentation (a wrong training-data attribution
    once shipped) must reach existing copies — but a user's sha256 pin,
    download_url, input_size and recommended flag are never touched."""
    monkeypatch.setattr(openscrub, "install_is_readonly", lambda: True)
    monkeypatch.setattr(openscrub, "user_data_dir", lambda: str(tmp_path))
    shipped = json.load(open(os.path.join(
        os.path.dirname(os.path.abspath(openscrub.__file__)),
        "plate_models.json"), encoding="utf-8"))
    mine = json.loads(json.dumps(shipped))
    m0 = mine["models"][0]
    m0["attribution"] = "stale text"
    m0["notes"] = "stale notes"
    m0["sha256"] = "ab" * 32                 # the user's own TOFU pin
    m0["download_url"] = "https://example.com/pinned.onnx"
    m0["recommended"] = not m0.get("recommended", False)
    (tmp_path / "plate_models.json").write_text(json.dumps(mine),
                                                encoding="utf-8")
    p = openscrub.model_registry_path("plate")
    got = json.load(open(p, encoding="utf-8"))["models"][0]
    s0 = shipped["models"][0]
    assert got["attribution"] == s0["attribution"]
    assert got["notes"] == s0["notes"]
    assert got["sha256"] == "ab" * 32
    assert got["download_url"] == "https://example.com/pinned.onnx"
    assert got["recommended"] == m0["recommended"]


def test_server_path_intake_guard_precedes_size_lookup(monkeypatch, tmp_path):
    """Code-scanning #21 (py/path-injection): create_job's server-path
    branch calls os.path.getsize on the request path (the duplicate-upload
    size, v1.0.83). server_path_error confines the path first, but CodeQL's
    barrier analysis is function-local, so the single-startswith
    containment guard must ALSO sit inline in create_job, before the sink
    — the same convention server_video and waveform follow. Pin both the
    behavior and that ordering."""
    import inspect
    import shutil
    import openscrub_web as w
    src = inspect.getsource(w.create_job)
    guard = src.find("if not p.startswith(r.rstrip(os.sep) + os.sep):")
    sink = src.find("os.path.getsize(p)")
    assert guard != -1, "inline containment guard missing from create_job"
    assert sink != -1 and guard < sink, "guard must precede the getsize sink"

    media = tmp_path / "media"
    media.mkdir()
    inside = media / "clip.mp4"
    inside.write_bytes(b"\x00" * 512)
    outside = tmp_path / "elsewhere.mp4"
    outside.write_bytes(b"\x00" * 64)
    monkeypatch.setenv("OPENSCRUB_MEDIA_ROOT", str(media))
    client = w.app.test_client()
    n0 = len(w.JOBS)
    r = client.post("/api/jobs", data={"server_path": str(outside),
                                       "options": "{}"})
    assert r.status_code == 400 and len(w.JOBS) == n0, \
        "a path outside the media root must be refused, no job created"
    r = client.post("/api/jobs", data={"server_path": str(inside),
                                       "options": "{}"})
    assert r.status_code == 200
    jid = r.get_json()["jobs"][0]
    try:
        assert w.JOBS[jid]["size"] == 512
    finally:
        try:
            w.WORK_Q.get_nowait()
            w.WORK_Q.task_done()
        except Exception:
            pass
        job = w.JOBS.pop(jid, None)
        if job:
            shutil.rmtree(job["dir"], ignore_errors=True)


def _apac_clip(path, apac_first=False):
    """Synthetic iPhone-style .mov: H.264 video + an AAC track + a track
    tagged 'apac' (Apple spatial audio) that FFmpeg cannot identify or
    decode. Built by retagging a second AAC sample entry 'mp4a' -> 'apac'
    and hiding its esds config box — exactly how a real APAC entry reads
    (ffprobe: codec_name=unknown, codec_tag_string=apac)."""
    import struct
    tmp = path + ".src.mov"
    subprocess.run(["ffmpeg", "-v", "error", "-y",
                    "-f", "lavfi", "-i", "testsrc2=duration=2:size=320x240:rate=30",
                    "-f", "lavfi", "-i", "sine=frequency=440:duration=2",
                    "-f", "lavfi", "-i", "sine=frequency=880:duration=2",
                    "-map", "0:v", "-map", "1:a", "-map", "2:a",
                    "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac",
                    "-shortest", tmp], check=True)
    b = bytearray(open(tmp, "rb").read())
    hits = [i for i in range(4, len(b) - 4) if b[i:i + 4] == b"mp4a"
            and 16 <= struct.unpack(">I", b[i - 4:i])[0] < 4096]
    assert len(hits) == 2, hits
    k = hits[0] if apac_first else hits[1]
    b[k:k + 4] = b"apac"
    j = b.find(b"esds", k)
    assert 0 < j - k < 200
    b[j:j + 4] = b"dapa"
    open(path, "wb").write(b)
    os.remove(tmp)


def _audio_codecs(path):
    out = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "a",
                          "-show_entries", "stream=codec_name,codec_tag_string",
                          "-of", "csv=p=0", path],
                         capture_output=True, text=True).stdout
    return [ln.strip() for ln in out.splitlines() if ln.strip()]


def test_render_survives_iphone_spatial_audio_track(tmp_path):
    """A real iPhone clip with a spatial-audio (APAC) track crashed the
    render: every audio track was stream-copied into the MP4, ffmpeg
    can't identify APAC ('Could not find tag for codec none'), quit at
    the first frame, and the job died as '[Errno 32] Broken pipe'.
    Undecodable tracks are now dropped loudly; the AAC track (the same
    sound) survives — with and without audio redaction, in either
    track order (some iPhones put the spatial track first)."""
    for apac_first in (False, True):
        src = str(tmp_path / f"iphone_{int(apac_first)}.mp4")
        mov = src.replace(".mp4", ".mov")
        _apac_clip(mov, apac_first=apac_first)
        assert any("apac" in c for c in _audio_codecs(mov))
        os.replace(mov, src)                 # run() derives names from .mp4
        res, _ = run(src, "--categories", "face", "--encoder", "x264")
        out = src.replace(".mp4", "_red.mp4")
        assert _audio_codecs(out) == ["aac,mp4a"], _audio_codecs(out)
        # redaction must also work, and actually silence the span — the
        # undecodable track must NOT ride along unredacted
        os.remove(out)
        res, _ = run(src, "--categories", "face", "--encoder", "x264",
                     "--audio-redact", "0.5-1.5")
        assert _audio_codecs(out) == ["aac,mp4a"]
        raw = subprocess.run(["ffmpeg", "-v", "error", "-i", out,
                              "-map", "0:a:0", "-ac", "1", "-ar", "8000",
                              "-f", "s16le", "-"],
                             capture_output=True).stdout
        a = np.abs(np.frombuffer(raw, np.int16).astype(int))
        assert a[int(0.7 * 8000):int(1.3 * 8000)].max() == 0, "span not muted"
        assert a[:int(0.4 * 8000)].max() > 1000, "kept audio lost"


def test_audio_lane_mapping_fails_closed(monkeypatch):
    """The editor numbers audio lanes from what the BROWSER lists, which
    hides undecodable tracks. Mute numbers map onto whichever numbering
    the lane count fits; an ambiguous mapping removes ALL audio (muting
    the wrong track would keep the one the user asked to silence), and
    an undecodable track never appears in any map."""
    tracks = [{"codec": "unknown", "tag": "apac"},       # 1: APAC first
              {"codec": "aac", "tag": "mp4a"},           # 2
              {"codec": "aac", "tag": "mp4a"}]           # 3
    monkeypatch.setattr(openscrub, "probe_audio_tracks", lambda s: tracks)
    monkeypatch.setattr(openscrub, "_audio_track_usable",
                        lambda s, i, c: c != "unknown")
    f = openscrub.audio_ffmpeg_args
    logs = []

    def maps(**kw):
        m, c = f("x.mov", [], log=logs.append, **kw)
        return [m[i + 1] for i in range(0, len(m), 2) if m[i] == "-map"]
    # browser hid APAC: 2 lanes = the 2 decodable tracks; lane 1 = file #2
    assert maps(mute_tracks=(1,), lane_count=2) == ["1:a:2"]
    # browser listed all 3: lane 1 = the APAC track (dropped anyway)
    assert maps(mute_tracks=(1,), lane_count=3) == ["1:a:1", "1:a:2"]
    # nothing muted: APAC never mapped, both AAC tracks kept
    assert maps(lane_count=2) == ["1:a:1", "1:a:2"]
    # ambiguous: 1 lane shown for a file with 3 tracks / 2 decodable
    logs.clear()
    assert f("x.mov", [], mute_tracks=(1,), lane_count=1,
             log=logs.append) == ([], [])
    assert any("removing ALL audio" in m for m in logs)
    # a lane number out of range is also ambiguous -> all audio removed
    assert f("x.mov", [], mute_tracks=(5,), lane_count=2) == ([], [])
    # redaction path: filters only ever read decodable tracks
    m, c = f("x.mov", [(0.0, 1.0, "mute")], lane_count=2)
    graph = m[m.index("-filter_complex") + 1]
    assert "[1:a:0]" not in graph and "[1:a:1]" in graph
    assert "-c:a" in c and "aac" in c


def test_audio_copy_respects_the_output_container(monkeypatch):
    """Decodable tracks stream-copy only when the container can hold the
    codec; otherwise they re-encode to AAC instead of failing the mux.
    MKV takes anything decodable."""
    tracks = [{"codec": "aac", "tag": "mp4a"},
              {"codec": "opus", "tag": "Opus"}]
    monkeypatch.setattr(openscrub, "probe_audio_tracks", lambda s: tracks)
    monkeypatch.setattr(openscrub, "_audio_track_usable", lambda s, i, c: True)
    m, c = openscrub.audio_ffmpeg_args("x", [], container=".mp4")
    assert c == ["-c:a:0", "copy", "-c:a:1", "aac", "-b:a:1", "192k"]
    m, c = openscrub.audio_ffmpeg_args("x", [], container=".mkv")
    assert (m, c) == (["-map", "1:a?"], ["-c:a", "copy"])


def test_encoder_failure_reports_ffmpegs_own_error(tmp_path, monkeypatch):
    """When ffmpeg dies mid-render, the job must show ffmpeg's real
    message, not the '[Errno 32] Broken pipe' Python sees writing to a
    dead encoder (which is all a real failing iPhone job ever said)."""
    src = str(tmp_path / "plain.mp4")
    make_video(src, [(300, "hello")], seconds=1.0)
    monkeypatch.setattr(openscrub, "audio_ffmpeg_args",
                        lambda *a, **k: (["-map", "1:a:7"], ["-c:a", "copy"]))
    with pytest.raises(RuntimeError) as ei:
        run(src, "--categories", "face", "--encoder", "x264")
    msg = str(ei.value)
    assert "Broken pipe" not in msg
    assert "matches no streams" in msg or "1:a:7" in msg, msg
